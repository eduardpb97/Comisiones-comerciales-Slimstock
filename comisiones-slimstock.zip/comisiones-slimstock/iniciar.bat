@echo off
title Portal de comisiones Slimstock
cd /d "%~dp0"
if "%PORT%"=="" set PORT=3000
rem Limita la memoria del portal para no competir con el resto de la maquina.
if "%NODE_OPTIONS%"=="" set NODE_OPTIONS=--max-old-space-size=512
if not exist ".next" (
  echo El portal no esta instalado todavia. Ejecuta primero instalar.bat
  pause
  exit /b 1
)
echo Portal de comisiones en marcha en http://localhost:%PORT%
echo Deja esta ventana abierta. Para pararlo, cierrala o pulsa Ctrl+C.
call npm start
