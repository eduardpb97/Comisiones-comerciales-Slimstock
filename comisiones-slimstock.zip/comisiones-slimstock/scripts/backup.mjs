// Copia de seguridad de la base de datos, sin parar el portal.
// Uso: npm run backup  → crea copias/comisiones-AAAA-MM-DD-HHMMSS.db y conserva las 30 últimas.
// Local: copia el fichero de datos. Vercel (con TURSO_DATABASE_URL y TURSO_AUTH_TOKEN definidas):
// descarga todas las tablas a un fichero SQLite en este equipo.
import { DatabaseSync } from 'node:sqlite';
import fs from 'node:fs';
import path from 'node:path';
import { connect } from './dbtool.mjs';

const dir = process.env.BACKUP_DIR || path.join(process.cwd(), 'copias');
fs.mkdirSync(dir, { recursive: true });
const d = new Date();
const p = (n) => String(n).padStart(2, '0');
const stamp = `${d.getFullYear()}-${p(d.getMonth() + 1)}-${p(d.getDate())}-${p(d.getHours())}${p(d.getMinutes())}${p(d.getSeconds())}`;
const target = path.join(dir, `comisiones-${stamp}.db`);
const src = await connect();
if (!src.cloud) {
  // VACUUM INTO escribe una copia íntegra y coherente aunque el portal esté en uso.
  await src.run('VACUUM INTO ?', [target]);
} else {
  const out = new DatabaseSync(target);
  const objects = await src.all("SELECT type, name, sql FROM sqlite_master WHERE sql IS NOT NULL AND name NOT LIKE 'sqlite_%' AND name NOT LIKE '_litestream%' AND name NOT LIKE 'libsql_%' ORDER BY CASE type WHEN 'table' THEN 0 ELSE 1 END");
  for (const o of objects.filter((x) => x.type === 'table')) out.exec(o.sql);
  out.exec('BEGIN');
  for (const t of objects.filter((x) => x.type === 'table')) {
    if (t.name === 'sessions' || t.name === 'login_attempts') continue; // no hacen falta en una copia
    const rows = await src.all(`SELECT * FROM "${t.name}"`);
    if (!rows.length) continue;
    const cols = Object.keys(rows[0]);
    const ins = out.prepare(`INSERT INTO "${t.name}" (${cols.map((c) => `"${c}"`).join(',')}) VALUES (${cols.map(() => '?').join(',')})`);
    for (const r of rows) ins.run(...cols.map((c) => r[c]));
  }
  out.exec('COMMIT');
  for (const o of objects.filter((x) => x.type === 'index')) out.exec(o.sql);
  out.close();
}
src.close();
const old = fs.readdirSync(dir).filter((f) => /^comisiones-.*\.db$/.test(f)).sort().reverse().slice(30);
for (const f of old) fs.unlinkSync(path.join(dir, f));
console.log(`Copia creada: ${target}`);
