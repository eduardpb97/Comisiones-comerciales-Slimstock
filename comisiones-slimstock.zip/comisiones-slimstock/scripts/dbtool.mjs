// Conexión común de los scripts: base local (node:sqlite) o Turso si hay TURSO_DATABASE_URL.
import fs from 'node:fs';
import path from 'node:path';

export async function connect() {
  const url = process.env.TURSO_DATABASE_URL;
  if (url) {
    const { createClient } = await import(url.startsWith('file:') ? '@libsql/client' : '@libsql/client/web');
    const c = createClient({ url, authToken: process.env.TURSO_AUTH_TOKEN });
    const rows = (r) => r.rows.map((row) => Object.fromEntries(r.columns.map((col, i) => [col, row[i]])));
    return {
      cloud: true, where: url.replace(/\?.*$/, ''),
      all: async (sql, p = []) => rows(await c.execute({ sql, args: p })),
      run: async (sql, p = []) => { await c.execute({ sql, args: p }); },
      close: () => c.close(),
    };
  }
  const { DatabaseSync } = await import('node:sqlite');
  const file = process.env.DATABASE_PATH || path.join(process.cwd(), 'data', 'comisiones.db');
  if (!fs.existsSync(file)) { console.error(`No existe la base de datos: ${file}`); process.exit(1); }
  const db = new DatabaseSync(file);
  db.exec('PRAGMA busy_timeout = 5000');
  return {
    cloud: false, where: file, file,
    all: async (sql, p = []) => db.prepare(sql).all(...p),
    run: async (sql, p = []) => { db.prepare(sql).run(...p); },
    close: () => db.close(),
  };
}
