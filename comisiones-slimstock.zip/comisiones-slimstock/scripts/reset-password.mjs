// Restablece la contraseña de un usuario cuando nadie de Finanzas puede entrar.
// Local:  npm run reset-password -- correo@slimstock.com
// Vercel: con TURSO_DATABASE_URL y TURSO_AUTH_TOKEN definidas en la terminal, el mismo comando.
import bcrypt from 'bcryptjs';
import crypto from 'node:crypto';
import { connect } from './dbtool.mjs';

const email = (process.argv[2] || '').trim().toLowerCase();
if (!email) { console.error('Indica el correo del usuario: npm run reset-password -- correo@slimstock.com'); process.exit(1); }
const db = await connect();
const user = (await db.all('SELECT id, name FROM users WHERE email = ? COLLATE NOCASE', [email]))[0];
if (!user) { console.error(`No hay ningún usuario con el correo ${email}.`); process.exit(1); }
const alphabet = 'ABCDEFGHJKLMNPQRSTUVWXYZabcdefghijkmnpqrstuvwxyz23456789';
const password = Array.from(crypto.randomBytes(12), (b) => alphabet[b % alphabet.length]).join('');
await db.run('UPDATE users SET password_hash = ?, must_change_password = 1, active = 1 WHERE id = ?', [bcrypt.hashSync(password, 10), user.id]);
await db.run('DELETE FROM sessions WHERE user_id = ?', [user.id]);
await db.run('DELETE FROM login_attempts WHERE key = ?', [email]);
db.close();
console.log(`Contraseña provisional de ${user.name} (${email}): ${password}`);
console.log('Tendrá que cambiarla al entrar.');
