#!/usr/bin/env bash
cd "$(dirname "$0")"
export PORT="${PORT:-3000}"
export NODE_OPTIONS="${NODE_OPTIONS:---max-old-space-size=512}"
[ -d .next ] || { echo "El portal no está instalado todavía. Ejecuta primero ./instalar.sh"; exit 1; }
echo "Portal de comisiones en marcha en http://localhost:$PORT"
exec npm start
