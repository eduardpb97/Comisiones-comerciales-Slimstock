@echo off
setlocal
title Instalador - Portal de comisiones Slimstock
cd /d "%~dp0"
echo.
echo  ============================================
echo   Portal de comisiones Slimstock - Instalador
echo  ============================================
echo.

where node >nul 2>nul
if errorlevel 1 (
  echo  [X] No se ha encontrado Node.js.
  echo      Instala Node.js 22 LTS desde https://nodejs.org y vuelve a ejecutar este instalador.
  goto :fin_error
)
for /f "tokens=1 delims=." %%v in ('node -p "process.versions.node"') do set NODE_MAJOR=%%v
if %NODE_MAJOR% LSS 22 (
  echo  [X] La version de Node.js instalada es antigua. Hace falta Node.js 22 LTS o superior.
  goto :fin_error
)
echo  [1/3] Node.js detectado.

echo  [2/3] Descargando dependencias ^(puede tardar unos minutos^)...
call npm ci --no-audit --no-fund
if errorlevel 1 (
  echo  [X] No se han podido instalar las dependencias. Comprueba la conexion a internet.
  goto :fin_error
)

echo  [3/3] Preparando el portal...
call npm run build
if errorlevel 1 (
  echo  [X] Ha fallado la preparacion del portal.
  goto :fin_error
)

echo.
echo  Instalacion completada.
echo.
echo   - Para arrancarlo ahora:            iniciar.bat
echo   - Para que arranque con Windows:    inicio-automatico.bat  ^(como administrador^)
echo   - Para abrir el puerto en la red:   abrir-puerto.bat       ^(como administrador^)
echo.
pause
exit /b 0

:fin_error
echo.
pause
exit /b 1
