// Contrasta el motor con los ejemplos de los contratos y del Excel
// "Ejemplos_comisiones_fijo_escalado". Ejecutar con: npm test
import test from 'node:test';
import assert from 'node:assert/strict';
import { allocate, computeBases, tiersFor, invoiceLine, progress, round2, equalShares } from '../src/lib/commission.ts';

/** Registra una serie de deals y devuelve la comisión acumulada. */
function run(planId: 1 | 2 | 3, deals: number[], quota?: number) {
  const tiers = tiersFor(planId, quota);
  let acc = 0;
  let total = 0;
  for (const base of deals) {
    total += allocate(tiers, acc, base).commission;
    acc += base;
  }
  return round2(total);
}

test('Excel ejemplos · 1 comercial · 9 deals de 75.000 € (dos con 7.500 € a terceros) = 57.490,50 €', () => {
  const deals = [75000, 75000, 75000, 75000, 75000, 67500, 75000, 75000, 67500];
  assert.equal(run(2, deals), 57490.5);
});

test('Excel ejemplos · 2 comerciales · comisión acumulada 53.491,50 €', () => {
  const half = (fee = 0) => (75000 - fee) / 2;
  const deals = [...Array(10).fill(half()), half(7500), ...Array(4).fill(half()), half(7500), half()];
  // El Excel arrastra medios céntimos (33.750 € × 13,33 % = 4.498,875 €) en dos deals;
  // el portal redondea cada deal al céntimo, de ahí la diferencia de 0,01 €.
  assert.ok(Math.abs(run(2, deals) - 53491.5) < 0.011);
});

test('Excel ejemplos · 3 comerciales · comisión acumulada 51.492,00 €', () => {
  const third = (fee = 0) => (75000 - fee) / 3;
  const fees = [0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 7500, 0, 7500, 0, 0, 7500, 0, 7500, 0, 0];
  assert.equal(run(2, fees.map(third)), 51492);
});

test('Plan 2 · un deal que cruza 225.000 € se reparte entre tramos', () => {
  // Excel real (COMISIONES LUI, García de Pou): 31.025 € al 2 % y 12.575 € al 10 %.
  const a = allocate(tiersFor(2), 225000 - 31025, 43600);
  assert.deepEqual(a.slices.map((s) => [s.rate, s.amount]), [[0.02, 31025], [0.1, 12575]]);
  assert.equal(a.commission, round2(31025 * 0.02 + 12575 * 0.1));
});

test('Plan 3 · tramos para Q = 360.000 € como en el contrato', () => {
  assert.deepEqual(tiersFor(3, 360000).map((t) => t.upTo), [120000, 180000, 360000, null]);
});

test('Plan 3 · 400.000 € de ARR con Q = 360.000 €', () => {
  // 120.000×5 % + 60.000×10 % + 180.000×25 % + 40.000×35 % = 6.000 + 6.000 + 45.000 + 14.000
  assert.equal(run(3, [400000], 360000), 71000);
  assert.equal(run(3, [100000, 100000, 100000, 100000], 360000), 71000);
});

test('Plan 1 · 6,50 % fijo', () => {
  assert.equal(run(1, [82000]), 5330);
});

test('Contrato nuevo · ARR con partner al 10 %: 21.600 €', () => {
  const b = computeBases({ cuotaLicencias: 2000, cuotaUsuarios: 0, cuotaHosting: 0, licenciasCompra: 0, implantacion: 0, partnerFeePct: 10 });
  assert.equal(b.partnerFee, 5000);
  assert.equal(b.arr, 21600);
});

test('Contrato antiguo · base de escalado con partner: 80.000 € (10 %) y 77.500 € (15 %)', () => {
  const c = { cuotaLicencias: 2000, cuotaUsuarios: 0, cuotaHosting: 0, licenciasCompra: 0, implantacion: 35000 };
  assert.equal(computeBases({ ...c, partnerFeePct: 10 }).ventas, 80000);
  assert.equal(computeBases({ ...c, partnerFeePct: 15 }).ventas, 77500);
});

test('Contrato antiguo · compra compartida entre 2: 60.000 € por comercial', () => {
  const b = computeBases({ cuotaLicencias: 0, cuotaUsuarios: 200, cuotaHosting: 0, licenciasCompra: 80000, implantacion: 35000, partnerFeePct: 0 });
  assert.equal(b.ventas, 120000);
  assert.equal(round2(b.ventas * equalShares(2)[0] / 100), 60000);
});

test('Contrato antiguo · alquiler compartido entre 3: 28.333,33 € por comercial', () => {
  const b = computeBases({ cuotaLicencias: 2000, cuotaUsuarios: 0, cuotaHosting: 0, licenciasCompra: 0, implantacion: 35000, partnerFeePct: 0 });
  assert.equal(round2(b.ventas / 3), 28333.33);
});

test('Contrato nuevo · ARR compartido: 12.000 € entre 2 y 8.000 € entre 3', () => {
  const b = computeBases({ cuotaLicencias: 2000, cuotaUsuarios: 0, cuotaHosting: 0, licenciasCompra: 0, implantacion: 0, partnerFeePct: 0 });
  assert.equal(b.arr, 24000);
  assert.equal(b.arr / 2, 12000);
  assert.equal(b.arr / 3, 8000);
});

test('Anexo director · 6 % de 1.084.449 € = 65.066,94 €', () => {
  assert.equal(allocate(tiersFor(4), 0, 1084449).commission, 65066.94);
});

test('Anexo director · ARR: alquiler ×12, mantenimiento 43,75 % de licencias y hosting ×12', () => {
  const b = computeBases({ cuotaLicencias: 2000, cuotaUsuarios: 300, cuotaHosting: 500, licenciasCompra: 80000, implantacion: 35000, partnerFeePct: 0 });
  assert.equal(b.arrDireccion, 12 * 2300 + 35000 + 6000);
});

test('Facturas · la suma de comisiones de las facturas coincide con la comisión del deal', () => {
  const a = allocate(tiersFor(2), 200000, 85000); // cruza el umbral de 225.000 €
  let alreadyBase = 0;
  let alreadyCommission = 0;
  const invoices = [35000, ...Array(25).fill(2000), 2000]; // la última ya no cabe en la base
  for (const inv of invoices) {
    const l = invoiceLine({
      invoiceAmount: inv, factor: 1, sharePct: 100, participantBase: 85000,
      participantCommission: a.commission, effectiveRate: a.effectiveRate, alreadyBase, alreadyCommission,
    });
    alreadyBase = round2(alreadyBase + l.base);
    alreadyCommission = round2(alreadyCommission + l.amount);
  }
  assert.equal(alreadyBase, 85000);
  assert.equal(alreadyCommission, a.commission);
});

test('Progreso · cuánto falta para el siguiente tramo', () => {
  const p = progress(tiersFor(2), 300000);
  assert.equal(p.current.rate, 0.1);
  assert.equal(p.toNext, 75000);
  assert.equal(progress(tiersFor(2), 500000).toNext, null);
});
