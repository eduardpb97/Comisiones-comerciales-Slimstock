@echo off
title Inicio automatico - Portal de comisiones Slimstock
cd /d "%~dp0"
net session >nul 2>nul
if errorlevel 1 (
  echo Ejecuta este fichero como administrador: boton derecho ^> Ejecutar como administrador.
  pause
  exit /b 1
)
schtasks /Create /TN "Portal Comisiones Slimstock" /TR "\"%~dp0servicio.bat\"" /SC ONSTART /RU SYSTEM /RL HIGHEST /F
if errorlevel 1 (
  echo No se ha podido crear la tarea de inicio automatico.
  pause
  exit /b 1
)
schtasks /Run /TN "Portal Comisiones Slimstock"
echo.
echo El portal arrancara solo cada vez que se encienda esta maquina, sin que nadie inicie sesion.
echo Ya esta en marcha. El registro queda en la carpeta logs.
echo Para quitarlo: schtasks /Delete /TN "Portal Comisiones Slimstock" /F
echo.
pause
