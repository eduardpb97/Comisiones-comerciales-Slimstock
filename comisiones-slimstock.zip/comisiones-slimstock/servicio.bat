@echo off
rem Lo ejecuta la tarea programada de Windows al encender la maquina.
cd /d "%~dp0"
if "%PORT%"=="" set PORT=3000
rem Limita la memoria del portal para no competir con el resto de la maquina.
if "%NODE_OPTIONS%"=="" set NODE_OPTIONS=--max-old-space-size=512
if not exist "logs" mkdir logs
call npm start >> "logs\portal.log" 2>&1
