# Portal de comisiones · Slimstock

Portal interno para que Finanzas gestione deals, facturas, cobros y la liquidación mensual
de comisiones, y para que cada comercial o consultor consulte las suyas.

## Instalación rápida

Requiere **Node.js 22 LTS** o superior. No hay nada que compilar: la base de datos es el
SQLite que trae Node.js.

| | Windows | Linux |
|---|---|---|
| Instalar | doble clic en `instalar.bat` | `./instalar.sh` |
| Arrancar | `iniciar.bat` | `./iniciar.sh` |
| Arranque automático | `inicio-automatico.bat` (como administrador) | `sudo ./inicio-automatico.sh` |
| Abrir el puerto 3000 | `abrir-puerto.bat` (como administrador) | según el cortafuegos (`sudo ufw allow 3000/tcp`) |
| Copia de seguridad | `copia-seguridad.bat` | `npm run backup` |

El portal queda en `http://<nombre-o-IP-de-la-máquina>:3000`. Se instala **una sola vez** en una
máquina siempre encendida; todos entran con el navegador a esa dirección.

Usuarios iniciales (se crean solos la primera vez):

| Rol | Correo | Contraseña inicial |
|---|---|---|
| Finanzas (administrador) | e.pinteno@slimstock.com | 1234 |
| Comercial (Plan 2) | e.abellan@slimstock.com | 1234 |

La contraseña inicial es provisional: el portal obliga a cambiarla en el primer acceso
(mínimo 8 caracteres). Lo mismo ocurre con las contraseñas que Finanzas crea o restablece.

Para formación o pruebas se puede arrancar con la variable `DEMO_DATA=1`: con el portal vacío,
el Resumen ofrece entonces cargar un juego de datos ficticio. En una instalación normal ese
botón no existe.

## Publicación en Vercel (alternativa a la máquina propia)

El mismo proyecto se publica en Vercel desde un repositorio **privado** de GitHub. En Vercel no hay
disco donde guardar el fichero de datos, así que la base de datos es Turso (un SQLite alojado):
el portal la usa en cuanto existen las variables `TURSO_DATABASE_URL` y `TURSO_AUTH_TOKEN`.

1. Sube esta carpeta a un repositorio privado de GitHub (sin `node_modules`, `.next` ni `data`;
   el `.gitignore` ya los excluye).
2. En Vercel: **Add New → Project**, importa el repositorio.
3. En el proyecto: **Storage → Create Database → Turso**, región de Europa, y conéctala al proyecto.
   Eso crea solas `TURSO_DATABASE_URL` y `TURSO_AUTH_TOKEN`.
4. En **Settings → Environment Variables** añade `ADMIN_EMAIL` y `ADMIN_PASSWORD` (12 caracteres o
   más): son el primer administrador. En la nube no existen los usuarios con contraseña 1234.
5. **Redeploy**. Entra con ese correo y esa contraseña; el portal obliga a cambiarla.

`vercel.json` fija la región de las funciones en Dublín (`dub1`); cámbiala si la base de datos está
en otra región. Copias de seguridad y recuperación de contraseña: los mismos `npm run backup` y
`npm run reset-password`, ejecutados en un equipo con las dos variables de Turso definidas.

Publicado en Vercel el portal queda **accesible desde internet** (con HTTPS). Ver «Seguridad».

## Arquitectura

- **Next.js 15 (App Router) + React 19 + TypeScript.** Una sola aplicación: páginas y API.
- **Base de datos**: en una máquina propia, el SQLite integrado en Node.js (`node:sqlite`), en el fichero
  `data/comisiones.db`; en Vercel, Turso. `src/lib/db.ts` elige una u otra y el resto del código es el mismo.
- **Sesiones** con cookie `httpOnly` y contraseñas con hash bcrypt. El rol se comprueba en
  servidor en cada petición: un comercial no puede leer datos de otro ni llamando a la API a mano.
- **Excel real** (`exceljs`) generado en servidor.
- **Marca**: Manrope y Covered By Your Grace (licencia OFL, en `public/fonts`), paleta y logos
  del brandbook en `src/app/globals.css` y `public/`.

```
src/lib/commission.ts   Reglas de cálculo (planes, tramos, bases, facturas). Sin base de datos.
src/lib/actions.ts      Operaciones de negocio y permisos por rol.
src/lib/db.ts           Esquema SQLite, migraciones y usuarios iniciales.
src/lib/auth.ts         Acceso, sesiones y contraseñas.
src/lib/excel.ts        Exportaciones .xlsx.
src/app/admin/*         Pantallas de Finanzas.
src/app/portal/*        Portal del comercial / consultor.
scripts/backup.mjs      Copia de seguridad en caliente.
tests/commission.test.ts  Ejemplos de los contratos y del Excel, como pruebas (npm test).
```

## Reglas de cálculo

Todo está en `src/lib/commission.ts`. Si cambia un contrato, se cambia ahí y se ejecuta `npm test`.

| Plan | Base | Escala |
|---|---|---|
| 1 · Fijo | Ventas | 6,50 % |
| 2 · Escalado | Ventas acumuladas en el año | 2 % hasta 225.000 € · 10 % hasta 375.000 € · 13,33 % en adelante |
| 3 · ARR | ARR acumulado en el año, con cuota Q | 5 % hasta Q/3 · 10 % hasta Q/2 · 25 % hasta Q · 35 % por encima |
| 4 · Director Comercial | Todo el ARR del año | 6 %, liquidación única anual |

**Bases de un deal** (se calculan a partir de los importes del contrato; se pueden ajustar a mano):

- Ventas (planes 1 y 2) = licencias en compra + implantación + 25 cuotas de pago por uso
  (licencias y usuarios) + 25 % de 25 cuotas de hosting − fee del partner.
- ARR comercial (plan 3) = 12 cuotas de pago por uso + 25 % de 12 cuotas de hosting − fee
  del partner anualizado (× 12/25).
- ARR dirección (plan 4) = 12 cuotas de alquiler + 43,75 % de las licencias en compra
  (mantenimiento) + 12 cuotas de hosting.

**Reparto.** Un deal admite hasta 3 comerciales. Por defecto se divide a partes iguales
(50 % con dos, un tercio con tres); el % es editable en el alta.

**Tramos.** Al dar de alta el deal se toma el acumulado anual del comercial y se posiciona su
base en la escala. Si cruza un umbral se reparte entre los dos tramos y el deal queda con un
**% efectivo** fijo, que heredan todas sus facturas. Los contadores empiezan en 0 € cada ejercicio.

**Facturas.** Cada factura genera una línea de comisión por comercial: importe × parte
comisionable × reparto × % efectivo. La parte comisionable depende del concepto (hosting 25 %;
implantación y licencias en compra no computan en el plan ARR; mantenimiento y gastos, nunca).
La base facturada nunca supera la base del deal y la última factura ajusta los céntimos.

**Cobros.** Giro bancario: cobrada automáticamente al vencimiento. Transferencia: pendiente
hasta pulsar «Marcar como cobrada». Al cobrarse, la comisión pasa a la bolsa por liquidar.

**Director Comercial.** No se asigna a deals: devenga el 6 % del ARR de todos los deals del
ejercicio. Una vez cerrado el ejercicio, Finanzas genera el incentivo en
«Liquidación mensual» y lo incluye en la nómina que corresponda (abril).

**Objetivo anual de ARR.** Cada comercial tiene un objetivo (en Usuarios; en el plan ARR, si se
deja vacío, es su cuota Q). La consecución es su parte del ARR comercial de los deals firmados
en el ejercicio. Finanzas y el Director Comercial ven la consecución de todo el equipo, el
total y qué aporta cada persona; el resto de comerciales solo ve la suya.

**Ejercicios.** Cada ejercicio se abre y se cierra en la pantalla «Ejercicios». Un deal acumula
en el ejercicio que se elige al darlo de alta (por defecto, el año de la firma), y solo en
ejercicios abiertos. Al cerrar un ejercicio deja de admitir deals, quedan fijados el plan, la
cuota y el objetivo de cada persona en ese año, y se abre el siguiente con los contadores a 0 €.
Las facturas de sus deals se siguen cobrando y liquidando. El incentivo del Director Comercial
solo puede generarse con el ejercicio cerrado. Un ejercicio cerrado se puede reabrir.

## Seguridad

Lo que el portal hace por sí mismo:

- Contraseñas con hash bcrypt; las iniciales y las restablecidas obligan a cambiarse al entrar.
- Sesiones de 7 días en cookie `httpOnly` y `SameSite=Lax`; en la base de datos solo se guarda su huella.
  Cambiar o restablecer una contraseña, o desactivar un usuario, cierra sus otras sesiones.
- Permisos comprobados en servidor en cada petición. Un comercial solo recibe sus propios datos.
- Bloqueo de 15 minutos tras 5 contraseñas erróneas para un mismo correo.
- Las peticiones deben ser JSON y venir del propio portal (protección CSRF); cabeceras que impiden
  incrustarlo en otra web.
- Todas las consultas SQL son parametrizadas.
- Registro de actividad (quién hizo qué y cuándo), exportable desde Usuarios. No guarda contraseñas.

Lo que depende de cómo se instale (ver el manual de instalación):

- **Sin HTTPS, contraseñas y sesiones viajan en claro por la red interna.** Para uso real, sírvelo por HTTPS.
- **Instalado en una máquina propia, no lo expongas a internet.** Acceso externo solo por VPN.
- **Publicado en Vercel sí queda en internet**: cualquiera llega a la pantalla de acceso. La protección es
  la contraseña de cada usuario y el bloqueo por intentos; exige contraseñas largas y da de baja a quien se vaya.
- Entra con los dos usuarios iniciales nada más instalar: hasta entonces su contraseña es 1234.
- La base de datos y las copias no están cifradas: quien acceda a la máquina o a las copias lo lee todo.
- En Windows el arranque automático ejecuta el portal con la cuenta SYSTEM. Si IT lo prefiere, puede
  cambiar la tarea programada a una cuenta de servicio sin privilegios con permiso sobre la carpeta.
- Actualiza Node.js y las dependencias periódicamente (`npm audit` lista los avisos conocidos).

## Operación

- **Copias de seguridad.** `npm run backup` (o `copia-seguridad.bat`) crea una copia coherente en
  `copias/` sin parar el portal y conserva las 30 últimas. Prográmala a diario y guarda la carpeta
  `copias/` fuera de la máquina. Restaurar = parar el portal, sustituir `data/comisiones.db` por
  la copia (borrando `comisiones.db-wal` y `comisiones.db-shm` si existen) y arrancar.
- **Contraseña de administrador perdida.** Desde la carpeta del portal, en la propia máquina:
  `npm run reset-password -- correo@slimstock.com` muestra una contraseña provisional.
- **Actualizar.** Parar el portal, copiar los ficheros nuevos encima **sin tocar `data/`**, volver
  a ejecutar el instalador y arrancar. La base de datos se actualiza sola.
- **HTTPS.** Para servirlo por HTTPS, ponlo detrás de un proxy inverso (IIS, nginx, Caddy) que
  envíe la cabecera `X-Forwarded-Proto: https`; así la cookie de sesión se marca como segura.
- **Datos personales.** El portal guarda nombres, correos e importes de retribución variable.
  Limita el acceso a la máquina y a las copias a Finanzas / IT.
- Variables opcionales: `PORT` (puerto, 3000 por defecto), `DATABASE_PATH`, `BACKUP_DIR`.
