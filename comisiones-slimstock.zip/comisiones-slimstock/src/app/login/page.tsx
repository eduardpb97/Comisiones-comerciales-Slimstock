'use client';
import { useState } from 'react';
import { LOGO_WHITE } from '@/components/brand';
import { go, signIn } from '@/components/client';
import { Diamonds, Field } from '@/components/ui';

export default function Login() {
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [error, setError] = useState('');
  const [busy, setBusy] = useState(false);

  const submit = async (e: React.FormEvent) => {
    e.preventDefault();
    setBusy(true);
    setError('');
    try {
      await signIn(email, password);
      go('/');
    } catch (err: any) {
      setError(err.message || 'No se ha podido iniciar sesión.');
      setBusy(false);
    }
  };

  return (
    <div className="login">
      <div className="login-brand">
        <Diamonds />
        <img src={LOGO_WHITE} alt="Slimstock" />
        <div>
          <h1><span className="script">Comisiones</span>claras.</h1>
          <p className="tagline">Deals, cobros y liquidaciones, con el detalle de cada nómina a la vista.</p>
        </div>
        <span className="small">Slimstock Ibérica · uso interno</span>
      </div>
      <div className="login-form">
        <form onSubmit={submit}>
          <div>
            <div className="eyebrow">Portal de comisiones</div>
            <h1>Entra en tu cuenta</h1>
          </div>
          <Field label="Correo electrónico">
            <input id="login-email" type="email" autoComplete="username" required autoFocus value={email} onChange={(e) => setEmail(e.target.value)} />
          </Field>
          <Field label="Contraseña">
            <input id="login-password" type="password" autoComplete="current-password" required value={password} onChange={(e) => setPassword(e.target.value)} />
          </Field>
          {error && <div className="error">{error}</div>}
          <button className="btn primary" disabled={busy}>{busy ? 'Entrando…' : 'Entrar'}</button>
          <p className="muted small">¿Has olvidado la contraseña? Pide a Finanzas que te la restablezca.</p>
        </form>
      </div>
    </div>
  );
}
