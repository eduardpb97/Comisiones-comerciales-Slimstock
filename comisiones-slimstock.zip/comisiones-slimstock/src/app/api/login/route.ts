import { NextResponse } from 'next/server';
import { login, AppError } from '@/lib/auth';

import { assertSameOrigin } from '@/lib/http';
import { ConfigError } from '@/lib/db';

export const dynamic = 'force-dynamic';

export async function POST(req: Request) {
  try {
    assertSameOrigin(req);
    const { email, password } = await req.json();
    if (typeof email !== 'string' || typeof password !== 'string') throw new AppError('Introduce tu correo y contraseña.');
    const user = await login(email, password);
    return NextResponse.json({ data: { role: user.role, mustChange: !!user.must_change_password } });
  } catch (e) {
    if (e instanceof AppError) return NextResponse.json({ error: e.message }, { status: e.status });
    if (e instanceof ConfigError) return NextResponse.json({ error: e.message }, { status: 503 });
    if (e instanceof SyntaxError) return NextResponse.json({ error: 'Petición no válida.' }, { status: 400 });
    console.error(e);
    return NextResponse.json({ error: 'No se ha podido iniciar sesión.' }, { status: 500 });
  }
}
