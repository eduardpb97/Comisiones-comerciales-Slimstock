import { NextResponse } from 'next/server';
import { currentUser, AppError } from '@/lib/auth';
import { run } from '@/lib/actions';

import { assertSameOrigin } from '@/lib/http';
import { ConfigError } from '@/lib/db';

export const dynamic = 'force-dynamic';

export async function POST(req: Request) {
  try {
    assertSameOrigin(req);
    const me = await currentUser();
    if (!me) return NextResponse.json({ error: 'Tu sesión ha caducado. Vuelve a entrar.' }, { status: 401 });
    const { action, payload } = await req.json();
    return NextResponse.json({ data: await run(me, String(action), payload) });
  } catch (e) {
    if (e instanceof AppError) return NextResponse.json({ error: e.message }, { status: e.status });
    if (e instanceof ConfigError) return NextResponse.json({ error: e.message }, { status: 503 });
    if (e instanceof SyntaxError) return NextResponse.json({ error: 'Petición no válida.' }, { status: 400 });
    console.error(e);
    return NextResponse.json({ error: 'Ha ocurrido un error inesperado. Inténtalo de nuevo.' }, { status: 500 });
  }
}
