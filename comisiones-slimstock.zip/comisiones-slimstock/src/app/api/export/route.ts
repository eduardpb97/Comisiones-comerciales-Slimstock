import { NextResponse } from 'next/server';
import { currentUser, AppError } from '@/lib/auth';
import { autoCollectGiros } from '@/lib/actions';
import { auditWorkbook, dealsWorkbook, invoicesWorkbook, linesWorkbook, settlementWorkbook } from '@/lib/excel';

export const dynamic = 'force-dynamic';

/** Descargas .xlsx. Solo Finanzas. */
export async function GET(req: Request) {
  try {
    const me = await currentUser();
    if (!me) return NextResponse.json({ error: 'Tu sesión ha caducado.' }, { status: 401 });
    if (me.role !== 'finanzas' || me.must_change_password) return NextResponse.json({ error: 'No tienes permiso.' }, { status: 403 });
    await autoCollectGiros();
    const q = new URL(req.url).searchParams;
    const year = q.get('year') ? Number(q.get('year')) : undefined;
    const type = q.get('type');
    const file =
      type === 'settlement' ? await settlementWorkbook(Number(q.get('id')))
      : type === 'deals' ? await dealsWorkbook(year)
      : type === 'invoices' ? await invoicesWorkbook(year)
      : type === 'lines' ? await linesWorkbook()
      : type === 'audit' ? await auditWorkbook()
      : null;
    if (!file) return NextResponse.json({ error: 'Exportación desconocida.' }, { status: 404 });
    return new NextResponse(new Uint8Array(file.buffer), {
      headers: {
        'Content-Type': 'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet',
        'Content-Disposition': `attachment; filename="${file.filename}"`,
        'Cache-Control': 'no-store',
      },
    });
  } catch (e) {
    if (e instanceof AppError) return NextResponse.json({ error: e.message }, { status: e.status });
    console.error(e);
    return NextResponse.json({ error: 'No se ha podido generar el Excel.' }, { status: 500 });
  }
}
