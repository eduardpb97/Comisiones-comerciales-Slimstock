'use client';
import { LOGO_WHITE } from '@/components/brand';
import { go } from '@/components/client';
import { PasswordForm } from '@/components/Profile';
import { Diamonds } from '@/components/ui';

export function FirstPassword() {
  return (
    <div className="login">
      <div className="login-brand">
        <Diamonds />
        <img src={LOGO_WHITE} alt="Slimstock" />
        <div>
          <h1><span className="script">Un último</span>paso.</h1>
          <p className="tagline">Tu contraseña actual es provisional. Elige una que solo conozcas tú para entrar al portal.</p>
        </div>
        <span className="small">Slimstock Ibérica · uso interno</span>
      </div>
      <div className="login-form">
        <div className="panel">
          <div><div className="eyebrow">Seguridad</div><h1>Elige tu contraseña</h1></div>
          <PasswordForm onDone={() => go('/')} />
        </div>
      </div>
    </div>
  );
}
