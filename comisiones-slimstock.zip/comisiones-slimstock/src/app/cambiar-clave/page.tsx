import { redirect } from 'next/navigation';
import { currentUser } from '@/lib/auth';
import { FirstPassword } from './FirstPassword';

export const dynamic = 'force-dynamic';

export default async function Page() {
  const me = await currentUser();
  if (!me) redirect('/login');
  if (!me.must_change_password) redirect('/');
  return <FirstPassword />;
}
