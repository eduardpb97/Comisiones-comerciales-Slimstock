'use client';
import { useState } from 'react';
import { act, eur, fdate, matches, useData } from '@/components/client';
import { Empty, ExportLink, Field, InvoiceStatus, Loading, METHOD, Modal, PageHead, YearSelect } from '@/components/ui';

function InvoiceForm({ options, onClose, onSaved }: { options: any; onClose: () => void; onSaved: () => void }) {
  const [f, setF] = useState({ dealId: '', number: '', concept: 'cuotas', amount: '', issueDate: options.today, dueDate: options.today, method: 'transferencia', description: '' });
  const [busy, setBusy] = useState(false);
  const set = (k: string) => (e: any) => setF({ ...f, [k]: e.target.value });
  const save = async (again: boolean) => {
    setBusy(true);
    const r = await act('invoices.create', f, 'Factura registrada.');
    setBusy(false);
    if (!r) return;
    if (again) setF({ ...f, number: '', amount: '', description: '' });
    else onSaved();
  };
  const deals = options.deals.filter((d: any) => d.status === 'activo');
  return (
    <Modal title="Registrar factura" onClose={() => { onSaved(); }} footer={
      <>
        <button className="btn" onClick={onSaved}>Cerrar</button>
        <button className="btn" onClick={() => save(true)} disabled={busy}>Guardar y añadir otra</button>
        <button className="btn primary" onClick={() => save(false)} disabled={busy}>Guardar</button>
      </>
    }>
      <Field label="Cliente / deal">
        <select id="inv-deal" value={f.dealId} onChange={set('dealId')} autoFocus>
          <option value="">Selecciona el cliente…</option>
          {deals.map((d: any) => <option key={d.id} value={d.id}>{d.client} · {d.year}</option>)}
        </select>
      </Field>
      <div className="form-grid">
        <Field label="Nº de factura"><input id="inv-number" value={f.number} onChange={set('number')} placeholder="A/2026…" /></Field>
        <Field label="Importe" hint="base imponible"><input id="inv-amount" type="number" step="0.01" value={f.amount} onChange={set('amount')} /></Field>
        <Field label="Concepto">
          <select id="inv-concept" value={f.concept} onChange={set('concept')}>
            {options.concepts.map((c: any) => <option key={c.id} value={c.id}>{c.label}</option>)}
          </select>
        </Field>
      </div>
      <div className="form-grid">
        <Field label="Fecha de factura"><input id="inv-issue" type="date" value={f.issueDate} onChange={set('issueDate')} /></Field>
        <Field label="Vencimiento"><input id="inv-due" type="date" value={f.dueDate} onChange={set('dueDate')} /></Field>
        <Field label="Método de pago">
          <select id="inv-method" value={f.method} onChange={set('method')}>
            <option value="transferencia">Transferencia bancaria</option>
            <option value="giro">Giro bancario</option>
          </select>
        </Field>
      </div>
      <div className="note">
        {f.method === 'giro'
          ? 'Giro bancario: se dará por cobrada automáticamente el día del vencimiento.'
          : 'Transferencia: queda pendiente de cobro hasta que pulses «Marcar como cobrada».'}
        {' '}El concepto decide qué parte computa para cada plan: el hosting al 25 %, y la implantación y las licencias en compra no computan en el plan ARR.
      </div>
    </Modal>
  );
}

export default function Facturas() {
  const { data: options, reload: reloadOptions } = useData<any>('admin.options');
  const [year, setYear] = useState<number | ''>('');
  const [status, setStatus] = useState('pendiente');
  const [method, setMethod] = useState('');
  const [q, setQ] = useState('');
  const [creating, setCreating] = useState(false);
  const { data: invoices, error, reload } = useData<any[]>('invoices.list', { year });
  if (!options || !invoices) return <Loading error={error} />;

  const rows = invoices.filter((i) => (!status || i.status === status) && (!method || i.method === method) && matches(q, i.client, i.number));
  const total = rows.reduce((s, i) => s + i.amount, 0);
  const paid = async (i: any) => { if (await act('invoices.markPaid', { id: i.id }, `Factura ${i.number || ''} cobrada. Su comisión pasa a la próxima liquidación.`)) reload(); };
  const revert = async (i: any) => {
    if (!window.confirm(`¿Deshacer el cobro de la factura ${i.number}? Volverá a estar pendiente de cobro${i.method === 'giro' ? ' y pasará a transferencia para que no se cobre sola otra vez' : ''}.`)) return;
    if (await act('invoices.revertPaid', { id: i.id }, 'Cobro deshecho.')) reload();
  };
  const remove = async (i: any) => {
    if (!window.confirm(`¿Eliminar la factura ${i.number} de ${i.client}?`)) return;
    if (await act('invoices.delete', { id: i.id }, 'Factura eliminada.')) reload();
  };

  return (
    <>
      <PageHead title="Facturas y cobros" sub="La comisión nace cuando la factura está cobrada. Los giros se cobran solos al vencimiento; las transferencias, cuando las marques.">
        <ExportLink href={`/api/export?type=invoices${year ? `&year=${year}` : ''}`}>Exportar a Excel</ExportLink>
        <button className="btn primary" onClick={() => setCreating(true)}>Registrar factura</button>
      </PageHead>
      <div className="card flush">
        <div className="card-head">
          <div className="toolbar">
            <div className="seg" role="group" aria-label="Estado">
              {[['pendiente', 'Pendientes'], ['cobrada', 'Cobradas'], ['', 'Todas']].map(([v, l]) => (
                <button key={v} className={status === v ? 'on' : ''} onClick={() => setStatus(v)}>{l}</button>
              ))}
            </div>
            <select id="inv-f-method" aria-label="Método de pago" value={method} onChange={(e) => setMethod(e.target.value)}>
              <option value="">Giro y transferencia</option>
              <option value="transferencia">Solo transferencia</option>
              <option value="giro">Solo giro</option>
            </select>
            <input id="inv-q" type="search" placeholder="Buscar cliente o nº…" value={q} onChange={(e) => setQ(e.target.value)} />
            <YearSelect all years={options.years} value={year} onChange={setYear} />
          </div>
          <span className="muted small">{rows.length} facturas · {eur(total)}</span>
        </div>
        {rows.length === 0 ? <Empty title="No hay facturas con estos filtros" /> : (
          <div className="table-wrap">
            <table>
              <thead>
                <tr><th>Cliente</th><th>Factura</th><th>Vencimiento</th><th>Método</th><th className="num">Importe</th><th>Comisión</th><th>Estado</th><th className="right">Acción</th></tr>
              </thead>
              <tbody>
                {rows.map((i) => (
                  <tr key={i.id}>
                    <td><b>{i.client}</b>{i.kind === 'manual' && <div className="muted small">Comisión manual</div>}</td>
                    <td className="nowrap">{i.number || '—'}<div className="muted small">{fdate(i.issue_date)}</div></td>
                    <td className="nowrap">{fdate(i.due_date)}</td>
                    <td>{METHOD[i.method]}</td>
                    <td className="num">{eur(i.amount)}</td>
                    <td>
                      {i.lines.length === 0 ? <span className="muted small">Sin comisión</span> : i.lines.map((l: any) => (
                        <div key={l.id} className="small nowrap">{l.user_name}: <b className="num">{eur(l.amount)}</b></div>
                      ))}
                    </td>
                    <td><InvoiceStatus inv={i} />{i.paid_date && <div className="muted small">el {fdate(i.paid_date)}</div>}</td>
                    <td className="right nowrap">
                      {i.status === 'pendiente' && i.method === 'transferencia' && <button className="btn ok small" onClick={() => paid(i)}>Marcar como cobrada</button>}
                      {i.status === 'pendiente' && i.method === 'giro' && <span className="muted small">Se cobra el {fdate(i.due_date)}</span>}
                      {i.status === 'cobrada' && !i.lines.some((l: any) => l.status === 'liquidada') && <button className="btn link" onClick={() => revert(i)}>Deshacer cobro</button>}
                      {i.lines.some((l: any) => l.status === 'liquidada') && <span className="pill ok">Liquidada</span>}
                      {i.status === 'pendiente' && <button className="btn link danger" onClick={() => remove(i)}>Eliminar</button>}
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        )}
      </div>
      {creating && <InvoiceForm options={options} onClose={() => setCreating(false)} onSaved={() => { setCreating(false); reload(); reloadOptions(); }} />}
    </>
  );
}
