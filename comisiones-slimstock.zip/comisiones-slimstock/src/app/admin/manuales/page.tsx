'use client';
import { useState } from 'react';
import { act, eur, fdate, pct, useData } from '@/components/client';
import { Empty, Field, InvoiceStatus, Loading, METHOD, PageHead } from '@/components/ui';

export default function Manuales() {
  const { data: options } = useData<any>('admin.options');
  const { data: rows, error, reload } = useData<any[]>('invoices.list', { kind: 'manual' });
  const blank = (today: string) => ({ user1: '', user2: '', client: '', description: '', number: '', amount: '', ratePct: '6.5', issueDate: today, dueDate: today, method: 'transferencia' });
  const [f, setF] = useState<any>(null);
  if (!options || !rows) return <Loading error={error} />;
  const form = f || blank(options.today);
  const set = (k: string) => (e: any) => setF({ ...form, [k]: e.target.value });
  const sellers = options.users.filter((u: any) => u.active);
  const amount = Number(form.amount) || 0;
  const rate = Number(form.ratePct) || 0;
  const n = form.user2 ? 2 : 1;

  const submit = async (e: React.FormEvent) => {
    e.preventDefault();
    const r = await act('manual.create', { ...form, userIds: [form.user1, form.user2].filter(Boolean) }, 'Comisión manual registrada.');
    if (r) { setF(blank(options.today)); reload(); }
  };
  const paid = async (i: any) => { if (await act('invoices.markPaid', { id: i.id }, 'Marcada como cobrada. Pasa a la próxima liquidación.')) reload(); };
  const remove = async (i: any) => {
    if (!window.confirm(`¿Eliminar la comisión manual de ${i.client}?`)) return;
    if (await act('invoices.delete', { id: i.id }, 'Comisión manual eliminada.')) reload();
  };

  return (
    <>
      <PageHead title="Comisiones manuales" sub="Para ventas que no vienen de un deal, como un presupuesto pequeño de un consultor. Siguen el mismo circuito: cobro y liquidación en nómina." />
      <div className="split">
        <form className="card stack" onSubmit={submit}>
          <h2>Nueva comisión manual</h2>
          <Field label="Consultor / comercial">
            <select id="man-user1" required value={form.user1} onChange={set('user1')}>
              <option value="">Selecciona…</option>
              {sellers.map((u: any) => <option key={u.id} value={u.id}>{u.name}</option>)}
            </select>
          </Field>
          <Field label="Compartida con" hint="opcional, al 50 %">
            <select id="man-user2" value={form.user2} onChange={set('user2')}>
              <option value="">Nadie</option>
              {sellers.filter((u: any) => String(u.id) !== form.user1).map((u: any) => <option key={u.id} value={u.id}>{u.name}</option>)}
            </select>
          </Field>
          <Field label="Cliente / concepto"><input id="man-client" required value={form.client} onChange={set('client')} /></Field>
          <div className="form-grid">
            <Field label="Importe"><input id="man-amount" type="number" step="0.01" required value={form.amount} onChange={set('amount')} /></Field>
            <Field label="% comisión"><input id="man-rate" type="number" step="0.01" min="0.01" max="100" required value={form.ratePct} onChange={set('ratePct')} /></Field>
          </div>
          <div className="form-grid">
            <Field label="Nº de factura" hint="opcional"><input id="man-number" value={form.number} onChange={set('number')} /></Field>
            <Field label="Método de pago">
              <select id="man-method" value={form.method} onChange={set('method')}>
                <option value="transferencia">Transferencia</option>
                <option value="giro">Giro bancario</option>
              </select>
            </Field>
          </div>
          <div className="form-grid">
            <Field label="Fecha"><input id="man-issue" type="date" required value={form.issueDate} onChange={set('issueDate')} /></Field>
            <Field label="Vencimiento"><input id="man-due" type="date" required value={form.dueDate} onChange={set('dueDate')} /></Field>
          </div>
          <div className="note">
            Comisión: <b>{eur((amount / n) * rate / 100)}</b>{n === 2 ? ' para cada uno' : ''} ({eur(amount / n)} × {pct(rate / 100)}).
          </div>
          <div><button className="btn primary">Registrar comisión</button></div>
        </form>

        <div className="card flush">
          <div className="card-head"><h2>Comisiones manuales registradas</h2></div>
          {rows.length === 0 ? <Empty title="Todavía no hay ninguna" /> : (
            <div className="table-wrap">
              <table>
                <thead><tr><th>Cliente / concepto</th><th>Vencimiento</th><th className="num">Importe</th><th>Comisión</th><th>Estado</th><th /></tr></thead>
                <tbody>
                  {rows.map((i) => (
                    <tr key={i.id}>
                      <td><b>{i.client}</b><div className="muted small">{i.number || 'Sin nº'} · {METHOD[i.method]}</div></td>
                      <td>{fdate(i.due_date)}</td>
                      <td className="num">{eur(i.amount)}</td>
                      <td>{i.lines.map((l: any) => <div key={l.id} className="small nowrap">{l.user_name}: <b>{eur(l.amount)}</b> ({pct(l.rate)})</div>)}</td>
                      <td><InvoiceStatus inv={i} /></td>
                      <td className="right nowrap">
                        {i.status === 'pendiente' && i.method === 'transferencia' && <button className="btn ok small" onClick={() => paid(i)}>Marcar como cobrada</button>}
                        {i.status === 'pendiente' && <button className="btn link danger" onClick={() => remove(i)}>Eliminar</button>}
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          )}
        </div>
      </div>
    </>
  );
}
