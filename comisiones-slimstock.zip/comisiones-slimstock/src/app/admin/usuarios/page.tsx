'use client';
import { useState } from 'react';
import { act, eur0, pct, useData } from '@/components/client';
import { ExportLink, Field, Loading, Modal, PageHead } from '@/components/ui';

const QUOTAS = [360000, 540000, 750000, 900000];

function UserForm({ user, plans, year, closed, onClose, onSaved }: { user: any; plans: any[]; year: number; closed: boolean; onClose: () => void; onSaved: (temp?: { name: string; password: string }) => void }) {
  const [f, setF] = useState({
    id: user?.id, email: user?.email || '', name: user?.name || '', role: user?.role || 'comercial',
    department: user?.department === 'CONSULTORIA' ? 'CONSULTORIA' : 'COMERCIAL', planId: user?.plan_id || 2, quota: user?.quota || 360000, arrTarget: user?.arr_target ?? '', active: user ? !!user.active : true,
  });
  const set = (k: string) => (e: any) => setF({ ...f, [k]: e.target.value });
  const plan = plans.find((p) => p.id === Number(f.planId));
  const save = async () => {
    const r = await act<any>('users.save', { ...f, year }, user ? 'Usuario actualizado.' : 'Usuario creado.');
    if (r) onSaved(r.temporaryPassword ? { name: f.name, password: r.temporaryPassword } : undefined);
  };
  return (
    <Modal narrow title={user ? `Editar ${user.name}` : 'Nuevo usuario'} onClose={onClose} footer={
      <><button className="btn" onClick={onClose}>Cancelar</button><button className="btn primary" onClick={save}>Guardar</button></>
    }>
      <Field label="Nombre"><input id="u-name" value={f.name} onChange={set('name')} autoFocus /></Field>
      <Field label="Correo electrónico"><input id="u-email" type="email" value={f.email} onChange={set('email')} /></Field>
      <div className="form-grid">
        <Field label="Rol">
          <select id="u-role" value={f.role} onChange={set('role')}>
            <option value="comercial">Comercial o Consultor</option>
            <option value="finanzas">Finanzas (administrador)</option>
          </select>
        </Field>
        {f.role === 'comercial' && (
          <Field label="Departamento">
            <select id="u-dept" value={f.department} onChange={(e) => setF({ ...f, department: e.target.value, planId: e.target.value === 'CONSULTORIA' && !user ? 1 : f.planId })}>
              <option value="COMERCIAL">Comercial</option>
              <option value="CONSULTORIA">Consultoría</option>
            </select>
          </Field>
        )}
      </div>
      {f.role === 'comercial' && (
        <fieldset disabled={closed}>
          <legend>Condiciones del ejercicio {year}</legend>
          {closed && <div className="note warn">El ejercicio {year} está cerrado: su plan y su objetivo quedaron fijados. Para cambiarlos, elige otro ejercicio arriba o reabre este en Ejercicios.</div>}
          <Field label="Plan de comisiones">
            <select id="u-plan" value={f.planId} onChange={set('planId')}>
              {plans.map((p) => <option key={p.id} value={p.id}>{p.name}</option>)}
            </select>
          </Field>
          {plan && <div className="note">{plan.description}</div>}
          {Number(f.planId) === 3 && (
            <Field label="Cuota anual de ARR (Q)" hint="según su tramo de salario fijo">
              <select id="u-quota" value={f.quota} onChange={set('quota')}>
                {QUOTAS.map((q) => <option key={q} value={q}>{eur0(q)}</option>)}
                {!QUOTAS.includes(Number(f.quota)) && <option value={f.quota}>{eur0(Number(f.quota))}</option>}
              </select>
            </Field>
          )}
          <Field label={Number(f.planId) === 4 ? 'Objetivo anual de ARR del equipo' : 'Objetivo anual de ARR'}
            hint={Number(f.planId) === 4 ? 'vacío = suma de los objetivos del equipo' : Number(f.planId) === 3 ? 'vacío = su cuota Q' : 'opcional'}>
            <input id="u-target" type="number" min="0" step="1000" inputMode="decimal" placeholder="360000" value={f.arrTarget} onChange={set('arrTarget')} />
          </Field>
          {user && Number(f.planId) !== user.plan_id && (
            <div className="note warn">El cambio de plan se aplica a los deals de {year} que se den de alta a partir de ahora. Los ya registrados conservan su tramo y su %.</div>
          )}
        </fieldset>
      )}
      <label className="check">
        <input id="u-active" type="checkbox" checked={f.active} onChange={(e) => setF({ ...f, active: e.target.checked })} />
        Usuario activo (puede entrar al portal)
      </label>
    </Modal>
  );
}

export default function Usuarios() {
  const [year, setYear] = useState<number | ''>('');
  const { data: list, error, reload } = useData<any>('users.list', { year });
  const users: any[] | null = list ? list.users : null;
  const { data: options } = useData<any>('admin.options');
  const [editing, setEditing] = useState<any>(undefined);
  const [temp, setTemp] = useState<{ name: string; password: string } | null>(null);
  if (!users || !options) return <Loading error={error} />;
  const closed = list.years.find((y: any) => y.year === list.year)?.status === 'cerrado';

  const reset = async (u: any) => {
    if (!window.confirm(`¿Restablecer la contraseña de ${u.name}? Se cerrarán sus sesiones y tendrá que elegir una nueva al entrar.`)) return;
    const r = await act<any>('users.resetPassword', { id: u.id });
    if (r) setTemp({ name: u.name, password: r.temporaryPassword });
  };
  const planName = (id: number) => options.plans.find((p: any) => p.id === id)?.short;

  return (
    <>
      <PageHead title="Usuarios" sub="Altas, roles, plan de comisiones de cada persona y restablecimiento de contraseñas.">
        <select id="users-year" aria-label="Ejercicio" value={list.year} onChange={(e) => setYear(Number(e.target.value))}>
          {list.years.map((y: any) => <option key={y.year} value={y.year}>Condiciones de {y.year}{y.status === 'cerrado' ? ' (cerrado)' : ''}</option>)}
        </select>
        <ExportLink href="/api/export?type=audit">Registro de actividad</ExportLink>
        <button className="btn primary" onClick={() => setEditing(null)}>Nuevo usuario</button>
      </PageHead>
      <div className="stack">
        <div className="card flush">
          <div className="table-wrap">
            <table>
              <thead><tr><th>Nombre</th><th>Correo</th><th>Rol</th><th>Plan {list.year}</th><th className="num">Objetivo ARR {list.year}</th><th>Estado</th><th /></tr></thead>
              <tbody>
                {users.map((u) => (
                  <tr key={u.id}>
                    <td><b>{u.name}</b></td>
                    <td>{u.email}</td>
                    <td>{u.role === 'finanzas' ? 'Finanzas' : u.department === 'CONSULTORIA' ? 'Consultor' : 'Comercial'}</td>
                    <td>{u.role === 'finanzas' ? '—' : u.plan_id ? <><span className="tag">{planName(u.plan_id)}</span>{u.plan_id === 3 && <span className="muted small"> Q {eur0(u.quota)}</span>}</> : <span className="pill bad">Sin plan</span>}</td>
                    <td className="num">{u.role === 'finanzas' ? '—' : u.arr_target ? eur0(u.arr_target) : u.plan_id === 3 ? <span className="muted">{eur0(u.quota)} (Q)</span> : <span className="muted">—</span>}</td>
                    <td>
                      {!u.active ? <span className="pill">Desactivado</span> : u.must_change_password ? <span className="pill warn">Contraseña provisional</span> : <span className="pill ok">Activo</span>}
                    </td>
                    <td className="right nowrap">
                      <button className="btn small" onClick={() => setEditing(u)}>Editar</button>{' '}
                      <button className="btn small" onClick={() => reset(u)}>Restablecer contraseña</button>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </div>

        <div className="card stack">
          <h2>Planes de comisiones</h2>
          <div className="grid cols-2">
            {options.plans.map((p: any) => (
              <div key={p.id}>
                <h3>{p.name}</h3>
                <p className="muted small">{p.description}</p>
                <div className="slices" style={{ marginTop: 6 }}>
                  {p.tiers.map((t: any, i: number) => (
                    <span className="tag" key={t.label}>
                      {pct(t.rate)} {p.tiers.length > 1 && (t.upTo ? `hasta ${eur0(t.upTo)}` : `desde ${eur0(p.tiers[i - 1].upTo)}`)}
                    </span>
                  ))}
                  {p.id === 3 && <span className="muted small">ejemplo con Q = 360.000 €</span>}
                </div>
              </div>
            ))}
          </div>
        </div>
      </div>

      {editing !== undefined && (
        <UserForm user={editing} plans={options.plans} year={list.year} closed={!!closed && !!editing} onClose={() => setEditing(undefined)}
          onSaved={(t) => { setEditing(undefined); if (t) setTemp(t); reload(); }} />
      )}
      {temp && (
        <Modal narrow title="Contraseña provisional" onClose={() => { setTemp(null); reload(); }} footer={<button className="btn primary" onClick={() => { setTemp(null); reload(); }}>Hecho</button>}>
          <p>Pasa esta contraseña a <b>{temp.name}</b> por un canal seguro. Solo se muestra ahora, y tendrá que cambiarla en su primer acceso.</p>
          <input id="temp-pw" readOnly value={temp.password} onFocus={(e) => e.target.select()} style={{ fontFamily: 'ui-monospace, Consolas, monospace', fontSize: 18, textAlign: 'center' }} />
        </Modal>
      )}
    </>
  );
}
