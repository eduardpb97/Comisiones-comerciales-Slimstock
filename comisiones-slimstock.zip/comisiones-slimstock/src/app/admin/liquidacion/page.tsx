'use client';
import Link from 'next/link';
import { useEffect, useMemo, useState } from 'react';
import { MONTHS, act, eur, eur0, fdate, pct, useData } from '@/components/client';
import { Empty, ExportLink, Loading, PageHead } from '@/components/ui';

export default function Liquidacion() {
  const [incentiveYear, setIncentiveYear] = useState<number | ''>('');
  const { data, error, reload } = useData<any>('settle.pending', { incentiveYear });
  const [selected, setSelected] = useState<Set<number>>(new Set());
  const [period, setPeriod] = useState<{ year: number; month: number } | null>(null);
  const [closed, setClosed] = useState<any>(null);
  const [busy, setBusy] = useState(false);

  // Al cargar, todas las comisiones cobradas quedan marcadas para la nómina.
  const ids = data ? data.lines.map((l: any) => l.id).join(',') : '';
  useEffect(() => {
    if (!data) return;
    setSelected(new Set(data.lines.map((l: any) => l.id)));
    setPeriod((p) => p || { year: Number(data.today.slice(0, 4)), month: Number(data.today.slice(5, 7)) });
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [ids]);

  const groups = useMemo(() => {
    const m = new Map<number, { name: string; department: string; lines: any[] }>();
    for (const l of data?.lines || []) {
      if (!m.has(l.user_id)) m.set(l.user_id, { name: l.user_name, department: l.department, lines: [] });
      m.get(l.user_id)!.lines.push(l);
    }
    return [...m.entries()];
  }, [data]);

  if (!data || !period) return <Loading error={error} />;

  const toggle = (id: number) => { const s = new Set(selected); s.has(id) ? s.delete(id) : s.add(id); setSelected(s); };
  const toggleGroup = (lines: any[], on: boolean) => { const s = new Set(selected); lines.forEach((l) => (on ? s.add(l.id) : s.delete(l.id))); setSelected(s); };
  const total = data.lines.filter((l: any) => selected.has(l.id)).reduce((s: number, l: any) => s + l.amount, 0);
  const label = `${MONTHS[period.month - 1]} ${period.year}`;

  const close = async () => {
    if (!window.confirm(`Vas a cerrar la liquidación de la nómina de ${label} con ${selected.size} comisiones por ${eur(total)}. Se avisará a cada comercial y no se puede deshacer. ¿Continuar?`)) return;
    setBusy(true);
    const r = await act('settle.close', { lineIds: [...selected], ...period }, 'Liquidación cerrada y comerciales notificados.');
    setBusy(false);
    if (r) { setClosed(r); reload(); }
  };
  const generate = async (userId: number) => {
    if (await act('incentive.generate', { userId, year: data.incentive.year }, 'Incentivo anual generado. Ya está en la bolsa por liquidar.')) reload();
  };
  const inc = data.incentive;
  const thisYear = Number(data.today.slice(0, 4));

  return (
    <>
      <PageHead title="Liquidación mensual" sub="Revisa las comisiones de facturas ya cobradas, marca las que entran en la nómina y cierra. El cierre avisa a cada comercial y genera el Excel para la gestoría.">
        <select id="liq-month" aria-label="Mes de la nómina" value={period.month} onChange={(e) => setPeriod({ ...period, month: Number(e.target.value) })}>
          {MONTHS.map((m, i) => <option key={m} value={i + 1}>Nómina de {m}</option>)}
        </select>
        <select id="liq-year" aria-label="Año de la nómina" value={period.year} onChange={(e) => setPeriod({ ...period, year: Number(e.target.value) })}>
          {[thisYear - 1, thisYear, thisYear + 1].map((y) => <option key={y} value={y}>{y}</option>)}
        </select>
      </PageHead>

      <div className="stack">
        {closed && (
          <div className="card spread" style={{ borderColor: 'var(--ok)' }}>
            <div>
              <h2>Liquidación de {closed.label} cerrada</h2>
              <p className="muted">{eur(closed.total)} para {closed.users} {closed.users === 1 ? 'persona' : 'personas'}. Cada una tiene ya el aviso con su desglose en el portal.</p>
            </div>
            <a className="btn primary" href={`/api/export?type=settlement&id=${closed.id}`}>↓ Exportar Excel para gestoría</a>
          </div>
        )}

        {groups.length === 0 ? (
          <div className="card"><Empty title="No hay comisiones pendientes de liquidar">Aparecerán aquí en cuanto se cobre una factura.</Empty></div>
        ) : (
          <>
            {groups.map(([userId, g]) => {
              const all = g.lines.every((l) => selected.has(l.id));
              const sum = g.lines.filter((l) => selected.has(l.id)).reduce((s, l) => s + l.amount, 0);
              return (
                <div className="card flush" key={userId}>
                  <div className="card-head">
                    <label className="check">
                      <input id={`liq-all-${userId}`} type="checkbox" checked={all} onChange={(e) => toggleGroup(g.lines, e.target.checked)} />
                      <h2>{g.name}</h2>
                      <span className="tag">{g.department === 'CONSULTORIA' ? 'Consultoría' : 'Comercial'}</span>
                    </label>
                    <span>A liquidar: <b className="num">{eur(sum)}</b></span>
                  </div>
                  <div className="table-wrap">
                    <table>
                      <thead><tr><th style={{ width: 36 }} /><th>Cliente</th><th>Factura</th><th>Cobrada el</th><th className="num">Base comisión</th><th className="num">%</th><th className="num">Comisión</th></tr></thead>
                      <tbody>
                        {g.lines.map((l) => (
                          <tr key={l.id}>
                            <td><input id={`liq-${l.id}`} type="checkbox" aria-label={`Incluir ${l.client} ${l.reference}`} checked={selected.has(l.id)} onChange={() => toggle(l.id)} /></td>
                            <td>{l.client}{l.kind !== 'factura' && <div className="muted small">{l.kind === 'manual' ? 'Comisión manual' : 'Incentivo anual de dirección'}</div>}</td>
                            <td>{l.reference}</td>
                            <td>{fdate(l.paid_date)}</td>
                            <td className="num">{eur(l.base)}</td>
                            <td className="num">{pct(l.rate)}</td>
                            <td className="num"><b>{eur(l.amount)}</b></td>
                          </tr>
                        ))}
                      </tbody>
                    </table>
                  </div>
                </div>
              );
            })}
            <div className="card spread">
              <div>
                <h2>Nómina de {label}: <span className="num">{eur(total)}</span></h2>
                <p className="muted">{selected.size} de {data.lines.length} comisiones marcadas. Las que dejes sin marcar siguen pendientes para el mes siguiente.</p>
              </div>
              <button className="btn navy" onClick={close} disabled={busy || selected.size === 0}>Cerrar liquidación y notificar a comerciales</button>
            </div>
          </>
        )}

        {inc.directors.length > 0 && (
          <div className="card stack">
            <div className="spread">
              <div>
                <h2>Incentivo anual del Director Comercial</h2>
                <p className="muted">6 % del ARR generado en el ejercicio. Se calcula cuando el ejercicio está cerrado y se abona en abril del año siguiente.</p>
              </div>
              <select id="inc-year" style={{ width: 'auto' }} aria-label="Ejercicio del incentivo" value={inc.year} onChange={(e) => setIncentiveYear(Number(e.target.value))}>
                {inc.years.map((y: number) => <option key={y} value={y}>Ejercicio {y}</option>)}
              </select>
            </div>
            {inc.directors.map((d: any) => (
              <div className="spread" key={d.id}>
                <span><b>{d.name}</b> · ARR {inc.year}: <span className="num">{eur0(inc.arr)}</span> ({inc.dealCount} deals) × 6 % = <b className="num">{eur(inc.amount)}</b></span>
                {d.generated
                  ? <span className="pill ok">Generado · {eur(d.generated.amount)}</span>
                  : inc.closed
                    ? <button className="btn" onClick={() => generate(d.id)} disabled={inc.arr <= 0}>Generar incentivo {inc.year}</button>
                    : <Link className="pill warn" href="/admin/ejercicios" style={{ textDecoration: 'none' }}>Disponible al cerrar el ejercicio {inc.year}</Link>}
              </div>
            ))}
          </div>
        )}

        <div className="card flush">
          <div className="card-head">
            <h2>Liquidaciones cerradas</h2>
            <ExportLink href="/api/export?type=lines">Histórico completo a Excel</ExportLink>
          </div>
          {data.settlements.length === 0 ? <Empty title="Aún no se ha cerrado ninguna liquidación" /> : (
            <div className="table-wrap">
              <table>
                <thead><tr><th>Nómina</th><th>Cerrada el</th><th>Por</th><th className="num">Personas</th><th className="num">Comisiones</th><th className="num">Total</th><th /></tr></thead>
                <tbody>
                  {data.settlements.map((s: any) => (
                    <tr key={s.id}>
                      <td><b>{MONTHS[s.month - 1]} {s.year}</b></td>
                      <td>{fdate(s.closed_at)}</td>
                      <td>{s.closed_by_name}</td>
                      <td className="num">{s.user_count}</td>
                      <td className="num">{s.line_count}</td>
                      <td className="num"><b>{eur(s.total)}</b></td>
                      <td className="right"><a className="btn small" href={`/api/export?type=settlement&id=${s.id}`}>↓ Excel gestoría</a></td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          )}
        </div>
      </div>
    </>
  );
}
