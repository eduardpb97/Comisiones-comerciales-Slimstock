import { currentUser } from '@/lib/auth';
import { Threads } from '@/components/Threads';

export const dynamic = 'force-dynamic';

export default async function Page() {
  const me = await currentUser();
  return <Threads role="finanzas" meId={me!.id} />;
}
