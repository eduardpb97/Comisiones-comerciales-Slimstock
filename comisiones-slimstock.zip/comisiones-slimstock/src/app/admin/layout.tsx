import { redirect } from 'next/navigation';
import { currentUser } from '@/lib/auth';
import { dbGet } from '@/lib/db';
import { Shell } from '@/components/Shell';

export const dynamic = 'force-dynamic';

export default async function AdminLayout({ children }: { children: React.ReactNode }) {
  const me = await currentUser();
  if (!me) redirect('/login');
  if (me.must_change_password) redirect('/cambiar-clave');
  if (me.role !== 'finanzas') redirect('/portal');
  const open = (await dbGet<{ n: number }>("SELECT COUNT(*) AS n FROM threads WHERE status='pendiente'"))?.n || 0;
  return (
    <Shell
      title="Comisiones · Finanzas"
      user={{ name: me.name, email: me.email }}
      nav={[
        { href: '/admin', label: 'Resumen' },
        { href: '/admin/deals', label: 'Deals' },
        { href: '/admin/facturas', label: 'Facturas y cobros' },
        { href: '/admin/liquidacion', label: 'Liquidación mensual' },
        { href: '/admin/manuales', label: 'Comisiones manuales' },
        { href: '/admin/ejercicios', label: 'Ejercicios' },
        { href: '/admin/consultas', label: 'Consultas', count: open },
        { href: '/admin/usuarios', label: 'Usuarios' },
        { href: '/admin/perfil', label: 'Mi perfil' },
      ]}
    >
      {children}
    </Shell>
  );
}
