'use client';
import { PasswordForm } from '@/components/Profile';
import { PageHead } from '@/components/ui';

export default function Perfil() {
  return (
    <>
      <PageHead title="Mi perfil" sub="Cambia tu contraseña de acceso al portal." />
      <div className="card" style={{ maxWidth: 440 }}>
        <PasswordForm />
      </div>
    </>
  );
}
