'use client';
import Link from 'next/link';
import { useState } from 'react';
import { act, eur, eur0, fdate, pct, useData } from '@/components/client';
import { Diamonds, Empty, Kpi, Loading, METHOD, PageHead, TeamAttainment, YearSelect } from '@/components/ui';

export default function Dashboard() {
  const [year, setYear] = useState<number | ''>('');
  const { data, error, reload } = useData<any>('admin.dashboard', { year });
  if (!data) return <Loading error={error} />;
  const k = data.kpis;
  const maxMonth = Math.max(1, ...data.months.map((m: any) => m.total));

  const loadDemo = async () => {
    if (await act('demo.load', {}, 'Datos de ejemplo cargados.')) reload();
  };

  return (
    <>
      <PageHead title="Resumen" sub={`Situación de cobros y comisiones a ${fdate(data.today)}.`}>
        <YearSelect years={data.years} value={data.year} onChange={setYear} />
      </PageHead>
      <div className="stack">
        {!data.fiscal.calendarOpen && (
          <div className="note warn spread">
            <span>
              <b>Estamos en {data.fiscal.calendarYear} y ese ejercicio no está abierto.</b>{' '}
              {data.fiscal.openBefore.length > 0
                ? `Sigue abierto ${data.fiscal.openBefore.join(' y ')}: los deals nuevos seguirán acumulando ahí hasta que lo cierres y abras ${data.fiscal.calendarYear}.`
                : `Ábrelo para poder registrar deals de ${data.fiscal.calendarYear}.`}
            </span>
            <Link className="btn small" href="/admin/ejercicios">Ir a Ejercicios</Link>
          </div>
        )}
        {data.fiscal.status === 'cerrado' && <div className="note">Estás viendo el ejercicio {data.year}, que está <b>cerrado</b>. Sus cifras de ventas, tramos y objetivos ya no cambian; los cobros y liquidaciones de sus facturas siguen su curso.</div>}
        {data.setup.invoices === 0 && (
          <div className="card hero welcome">
            <Diamonds />
            <h2><span className="script">Bienvenido,</span>empecemos.</h2>
            <ol className="steps">
              <li><div><span><b>Da de alta al equipo</b> y asigna a cada persona su plan y su objetivo de ARR.</span></div>
                {data.setup.users <= 1 ? <Link className="btn small" href="/admin/usuarios">Ir a Usuarios</Link> : <span className="pill ok">Hecho</span>}</li>
              <li><div><span><b>Registra el primer deal</b> firmado: el portal fija su tramo y su % de comisión.</span></div>
                {data.setup.deals === 0 ? <Link className="btn small" href="/admin/deals">Ir a Deals</Link> : <span className="pill ok">Hecho</span>}</li>
              <li><div><span><b>Registra sus facturas</b> y márcalas como cobradas cuando entre el dinero.</span></div>
                <Link className="btn small" href="/admin/facturas">Ir a Facturas</Link></li>
              <li><div><span><b>Cierra la liquidación</b> del mes y descarga el Excel para la gestoría.</span></div>
                <Link className="btn small" href="/admin/liquidacion">Ir a Liquidación</Link></li>
            </ol>
            {data.demoAllowed && k.deals_total === 0 && <div><button className="btn small" onClick={loadDemo}>Cargar datos de ejemplo</button></div>}
          </div>
        )}

        <div className="grid cols-4">
          <Kpi tone="warn" label="Facturado pendiente de cobro" value={eur0(k.pending_collection)}
            hint={`${k.pending_count} facturas${k.overdue_count ? ` · ${k.overdue_count} vencidas` : ''}`} />
          <Kpi tone="accent" label="Cobrado, listo para liquidar" value={eur(k.to_settle)}
            hint={<Link href="/admin/liquidacion">{k.to_settle_count} comisiones para la próxima nómina</Link>} />
          <Kpi tone="ok" label={`Liquidado en ${data.year}`} value={eur(k.settled_year)} hint={`${k.deal_count} deals firmados · ${eur0(k.deal_amount)}`} />
          <Kpi label="Consultas pendientes" value={k.open_threads}
            hint={k.open_threads ? <Link href="/admin/consultas">Responder</Link> : 'Todo respondido'} />
        </div>

        <TeamAttainment team={data.attainment} />

        <div className="card flush">
          <div className="card-head"><h2>Comisiones del equipo · {data.year}</h2></div>
          {data.team.length === 0 ? <Empty title="Sin comerciales activos" /> : (
            <div className="table-wrap">
              <table>
                <thead>
                  <tr>
                    <th>Comercial</th><th>Plan</th><th className="num">Acumulado anual</th><th>Tramo actual</th>
                    <th className="num">Pend. de cobro</th>
                    <th className="num">Por liquidar</th><th className="num">Liquidado {data.year}</th>
                  </tr>
                </thead>
                <tbody>
                  {data.team.map((u: any) => (
                    <tr key={u.id}>
                      <td className="nowrap"><b>{u.name}</b><div className="muted small">{u.department === 'CONSULTORIA' ? 'Consultoría' : 'Comercial'}</div></td>
                      <td>{u.plan ? <span className="tag">{u.plan.short}</span> : <span className="pill bad">Sin plan</span>}</td>
                      <td className="num">{u.plan ? eur0(u.accumulated) : '—'}<div className="muted small">{u.plan?.measure === 'ventas' ? 'ventas' : 'ARR'}</div></td>
                      <td>
                        {u.plan ? <span className="pill info">{u.progress.current.label}</span> : '—'}
                        {u.plan && u.progress.toNext !== null && <div className="muted small nowrap" style={{ marginTop: 3 }}>faltan {eur0(u.progress.toNext)} para el siguiente</div>}
                      </td>
                      <td className="num">{eur(u.pendingCollection)}</td>
                      <td className="num">{eur(u.toSettle)}</td>
                      <td className="num">{eur(u.settledInYear)}</td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          )}
        </div>

        <div className="grid cols-2">
          <div className="card">
            <h2>Comisiones liquidadas por nómina · {data.year}</h2>
            <div className="bars" role="img" aria-label={`Comisiones liquidadas cada mes de ${data.year}`}>
              {data.months.map((m: any) => (
                <div className="bar" key={m.label} title={`${m.label}: ${eur(m.total)}`}>
                  <em>{m.total ? eur0(m.total) : ''}</em>
                  <i className={m.total ? '' : 'zero'} style={{ height: `${(m.total / maxMonth) * 100}%` }} />
                  <small>{m.label}</small>
                </div>
              ))}
            </div>
          </div>
          <div className="card flush">
            <div className="card-head">
              <h2>Facturas vencidas sin cobrar</h2>
              <Link href="/admin/facturas" className="small">Ver todas</Link>
            </div>
            {data.overdue.length === 0 ? <Empty title="Ninguna factura vencida" /> : (
              <div className="table-wrap">
                <table>
                  <thead><tr><th>Cliente</th><th>Factura</th><th>Vencimiento</th><th>Método</th><th className="num">Importe</th></tr></thead>
                  <tbody>
                    {data.overdue.map((i: any) => (
                      <tr key={i.id}>
                        <td>{i.client}</td><td>{i.number}</td><td><span className="pill bad">{fdate(i.due_date)}</span></td>
                        <td>{METHOD[i.method]}</td><td className="num">{eur(i.amount)}</td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              </div>
            )}
          </div>
        </div>
      </div>
    </>
  );
}
