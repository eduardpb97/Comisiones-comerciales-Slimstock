'use client';
import { Fragment, useEffect, useState } from 'react';
import { act, eur, eur0, fdate, matches, pct, rpc, useData } from '@/components/client';
import { Empty, ExportLink, Field, Loading, Modal, PageHead, YearSelect } from '@/components/ui';

const EMPTY = { cuotaLicencias: '', cuotaUsuarios: '', cuotaHosting: '', licenciasCompra: '', implantacion: '', partnerFeePct: '' };

function Slices({ slices }: { slices: any[] }) {
  return (
    <div className="slices">
      {slices.map((s) => <span key={s.label} className="tag">{eur0(s.amount)} al {pct(s.rate)}</span>)}
    </div>
  );
}

function DealForm({ options, onClose, onSaved }: { options: any; onClose: () => void; onSaved: () => void }) {
  const openYears: number[] = options.fiscalYears.filter((y: any) => y.status === 'abierto').map((y: any) => y.year);
  // Por defecto, el ejercicio del año de la firma si está abierto; si no, el ejercicio en curso.
  const yearFor = (d: string) => (openYears.includes(Number(d.slice(0, 4))) ? Number(d.slice(0, 4)) : options.defaultYear);
  const [f, setF] = useState({ client: '', signedDate: options.today, year: yearFor(options.today), saleType: 'pago_uso', notes: '' });
  const [yearTouched, setYearTouched] = useState(false);
  const { data: yearOptions } = useData<any>('admin.options', { year: f.year });
  const [c, setC] = useState<any>(EMPTY);
  const [parts, setParts] = useState<{ userId: string; sharePct: string }[]>([{ userId: '', sharePct: '' }]);
  const [manual, setManual] = useState(false);
  const [ov, setOv] = useState({ ventas: '', arr: '', arrDireccion: '' });
  const [preview, setPreview] = useState<any>(null);
  const [hint, setHint] = useState('');
  const [busy, setBusy] = useState(false);

  const sellers = (yearOptions || options).users.filter((u: any) => u.active && u.plan_id && u.plan_id !== 4);
  const payload = {
    ...f, components: c, overrides: manual ? ov : {},
    participants: parts.filter((p) => p.userId).map((p) => ({ userId: Number(p.userId), sharePct: p.sharePct })),
  };
  const key = JSON.stringify(payload);

  // Vista previa del cálculo mientras se rellena el formulario.
  useEffect(() => {
    const p = JSON.parse(key);
    if (!p.client.trim() || !p.participants.length) { setPreview(null); setHint('Indica el cliente y al menos un comercial para ver el cálculo.'); return; }
    const t = setTimeout(() => {
      rpc('deals.preview', p).then((d) => { setPreview(d); setHint(''); }).catch((e) => { setPreview(null); setHint(e.message); });
    }, 250);
    return () => clearTimeout(t);
  }, [key]);

  const setPart = (i: number, patch: any) => setParts(parts.map((p, j) => (j === i ? { ...p, ...patch } : p)));
  const money = (k: string, label: string, hintText?: string) => (
    <Field label={label} hint={hintText}>
      <input id={`deal-${k}`} type="number" min="0" step="0.01" inputMode="decimal" value={c[k]} onChange={(e) => setC({ ...c, [k]: e.target.value })} />
    </Field>
  );
  const save = async () => {
    setBusy(true);
    const r = await act('deals.create', payload, 'Deal dado de alta.');
    setBusy(false);
    if (r) onSaved();
  };

  return (
    <Modal title="Alta de deal" onClose={onClose} footer={
      <>
        <button className="btn" onClick={onClose}>Cancelar</button>
        <button className="btn primary" onClick={save} disabled={busy || !preview}>Dar de alta y fijar tramos</button>
      </>
    }>
      <div className="form-grid">
        <Field label="Nombre del cliente" hint="clave para vincular sus facturas">
          <input id="deal-client" value={f.client} onChange={(e) => setF({ ...f, client: e.target.value })} autoFocus />
        </Field>
        <Field label="Fecha de firma">
          <input id="deal-date" type="date" value={f.signedDate} onChange={(e) => setF({ ...f, signedDate: e.target.value, year: yearTouched || !e.target.value ? f.year : yearFor(e.target.value) })} />
        </Field>
        <Field label="Ejercicio" hint="donde acumula">
          <select id="deal-year" value={f.year} onChange={(e) => { setYearTouched(true); setF({ ...f, year: Number(e.target.value) }); }}>
            {openYears.map((y) => <option key={y} value={y}>{y}</option>)}
          </select>
        </Field>
        <Field label="Tipo de venta">
          <select id="deal-type" value={f.saleType} onChange={(e) => setF({ ...f, saleType: e.target.value })}>
            <option value="pago_uso">Pago por uso (ARR)</option>
            <option value="compra">Compra de licencias</option>
          </select>
        </Field>
      </div>

      {f.signedDate && Number(f.signedDate.slice(0, 4)) !== f.year && (
        <div className="note warn">La firma es de {f.signedDate.slice(0, 4)} pero el deal acumulará en el ejercicio <b>{f.year}</b>{openYears.includes(Number(f.signedDate.slice(0, 4))) ? '' : `, porque el ejercicio ${f.signedDate.slice(0, 4)} no está abierto`}.</div>
      )}

      <fieldset>
        <legend>Importes del contrato</legend>
        <div className="form-grid">
          {f.saleType === 'pago_uso'
            ? money('cuotaLicencias', 'Cuota mensual licencias Slim4')
            : money('licenciasCompra', 'Importe de licencias (compra)')}
          {money('cuotaUsuarios', 'Cuota mensual usuarios')}
          {money('cuotaHosting', 'Cuota mensual hosting', 'si existe')}
          {money('implantacion', 'Importe de implantación')}
          <Field label="Fee al partner (%)" hint="sobre 25 cuotas">
            <input id="deal-fee" type="number" min="0" max="100" step="0.1" value={c.partnerFeePct} onChange={(e) => setC({ ...c, partnerFeePct: e.target.value })} />
          </Field>
        </div>
        <label className="check">
          <input id="deal-manual" type="checkbox" checked={manual} onChange={(e) => setManual(e.target.checked)} />
          Ajustar las bases a mano (descuentos de Discount guidelines u otros casos)
        </label>
        {manual && (
          <div className="form-grid">
            <Field label="Base de ventas" hint="planes 1 y 2"><input id="deal-ov-ventas" type="number" min="0" step="0.01" placeholder={preview ? String(preview.bases.ventas) : ''} value={ov.ventas} onChange={(e) => setOv({ ...ov, ventas: e.target.value })} /></Field>
            <Field label="ARR comercial" hint="plan 3"><input id="deal-ov-arr" type="number" min="0" step="0.01" placeholder={preview ? String(preview.bases.arr) : ''} value={ov.arr} onChange={(e) => setOv({ ...ov, arr: e.target.value })} /></Field>
            <Field label="ARR dirección" hint="plan 4"><input id="deal-ov-dir" type="number" min="0" step="0.01" placeholder={preview ? String(preview.bases.arrDireccion) : ''} value={ov.arrDireccion} onChange={(e) => setOv({ ...ov, arrDireccion: e.target.value })} /></Field>
          </div>
        )}
      </fieldset>

      <fieldset>
        <legend>Comerciales asignados (hasta 3)</legend>
        {parts.map((p, i) => (
          <div className="row" key={i}>
            <div className="grow">
              <select id={`deal-user-${i}`} aria-label={`Comercial ${i + 1}`} value={p.userId} onChange={(e) => setPart(i, { userId: e.target.value })}>
                <option value="">Selecciona comercial…</option>
                {sellers.map((u: any) => <option key={u.id} value={u.id}>{u.name} · {options.plans.find((pl: any) => pl.id === u.plan_id)?.short}</option>)}
              </select>
            </div>
            <div style={{ width: 150 }}>
              <input id={`deal-share-${i}`} aria-label={`Reparto del comercial ${i + 1} en %`} type="number" min="0" max="100" step="0.01"
                placeholder={`${(100 / parts.length).toFixed(2)} %`} value={p.sharePct} onChange={(e) => setPart(i, { sharePct: e.target.value })} />
            </div>
            {parts.length > 1 && <button className="btn link danger" onClick={() => setParts(parts.filter((_, j) => j !== i))}>Quitar</button>}
          </div>
        ))}
        <div className="spread">
          <span className="muted small">Si dejas el reparto vacío, el deal se divide a partes iguales entre los asignados.</span>
          {parts.length < 3 && <button className="btn small" onClick={() => setParts([...parts, { userId: '', sharePct: '' }])}>+ Añadir comercial</button>}
        </div>
      </fieldset>

      {preview ? (
        <div className="card flush">
          <div className="card-head">
            <h3>Cálculo que se fijará · ejercicio {preview.year}</h3>
            <span className="muted small">
              Ventas {eur0(preview.bases.ventas)} · ARR {eur0(preview.bases.arr)} · ARR dirección {eur0(preview.bases.arrDireccion)}
              {preview.partnerFee > 0 && ` · fee partner ${eur0(preview.partnerFee)}`}
            </span>
          </div>
          <div className="table-wrap">
            <table>
              <thead><tr><th>Comercial</th><th className="num">Reparto</th><th className="num">Base</th><th className="num">Acumulado previo</th><th>Tramos</th><th className="num">% efectivo</th><th className="num">Comisión</th></tr></thead>
              <tbody>
                {preview.participants.map((p: any) => (
                  <tr key={p.userId}>
                    <td><b>{p.name}</b><div className="muted small">{p.planName}</div></td>
                    <td className="num">{pct(p.sharePct / 100)}</td>
                    <td className="num">{eur(p.base)}</td>
                    <td className="num">{eur0(p.accumBefore)}</td>
                    <td><Slices slices={p.slices} /></td>
                    <td className="num"><b>{pct(p.effectiveRate)}</b></td>
                    <td className="num">{eur(p.commission)}</td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </div>
      ) : <div className="note">{hint}</div>}

      <Field label="Notas" hint="opcional">
        <input id="deal-notes" value={f.notes} onChange={(e) => setF({ ...f, notes: e.target.value })} />
      </Field>
    </Modal>
  );
}

function EditDeal({ deal, onClose, onSaved }: { deal: any; onClose: () => void; onSaved: () => void }) {
  const [f, setF] = useState({ client: deal.client, notes: deal.notes, status: deal.status });
  const save = async () => { if (await act('deals.update', { id: deal.id, ...f }, 'Deal actualizado.')) onSaved(); };
  const remove = async () => {
    if (!window.confirm(`¿Eliminar el deal de ${deal.client}?`)) return;
    if (await act('deals.delete', { id: deal.id }, 'Deal eliminado.')) onSaved();
  };
  return (
    <Modal narrow title={`Editar deal · ${deal.client}`} onClose={onClose} footer={
      <>
        {deal.invoice_count === 0 && <button className="btn link danger" onClick={remove} style={{ marginRight: 'auto' }}>Eliminar deal</button>}
        <button className="btn" onClick={onClose}>Cancelar</button>
        <button className="btn primary" onClick={save}>Guardar</button>
      </>
    }>
      <div className="note">Los importes y los tramos quedan fijados al dar de alta el deal. Si hay un error en ellos, elimina el deal (mientras no tenga facturas) y vuelve a crearlo.</div>
      <Field label="Nombre del cliente"><input id="edit-client" value={f.client} onChange={(e) => setF({ ...f, client: e.target.value })} /></Field>
      <Field label="Estado">
        <select id="edit-status" value={f.status} onChange={(e) => setF({ ...f, status: e.target.value })}>
          <option value="activo">Activo</option>
          <option value="baja">Baja (no admite más facturas)</option>
        </select>
      </Field>
      <Field label="Notas"><input id="edit-notes" value={f.notes} onChange={(e) => setF({ ...f, notes: e.target.value })} /></Field>
    </Modal>
  );
}

export default function Deals() {
  const { data: options, reload: reloadOptions } = useData<any>('admin.options');
  const [year, setYear] = useState<number | ''>('');
  const [userId, setUserId] = useState('');
  const [q, setQ] = useState('');
  const [creating, setCreating] = useState(false);
  const [editing, setEditing] = useState<any>(null);
  const { data: deals, error, reload } = useData<any[]>('deals.list', { year });
  if (!options || !deals) return <Loading error={error} />;

  const rows = deals.filter((d) => matches(q, d.client, d.notes) && (!userId || d.participants.some((p: any) => String(p.user_id) === userId)));
  const done = () => { setCreating(false); setEditing(null); reload(); reloadOptions(); };

  return (
    <>
      <PageHead title="Deals" sub="Cada deal fija, en el momento del alta, el tramo y el % de comisión de cada comercial para todas sus facturas.">
        <ExportLink href={`/api/export?type=deals${year ? `&year=${year}` : ''}`}>Exportar a Excel</ExportLink>
        <button className="btn primary" onClick={() => setCreating(true)}>Nuevo deal</button>
      </PageHead>
      <div className="card flush">
        <div className="card-head">
          <div className="toolbar">
            <input id="deals-q" type="search" placeholder="Buscar cliente…" value={q} onChange={(e) => setQ(e.target.value)} />
            <YearSelect all years={options.years} value={year} onChange={setYear} />
            <select id="deals-user" aria-label="Comercial" value={userId} onChange={(e) => setUserId(e.target.value)}>
              <option value="">Todos los comerciales</option>
              {options.users.map((u: any) => <option key={u.id} value={u.id}>{u.name}</option>)}
            </select>
          </div>
          <span className="muted small">{rows.length} deals · {eur0(rows.reduce((s, d) => s + d.total_amount, 0))}</span>
        </div>
        {rows.length === 0 ? <Empty title="No hay deals con estos filtros">Da de alta el primero con «Nuevo deal».</Empty> : (
          <div className="table-wrap">
            <table>
              <thead>
                <tr><th>Cliente</th><th>Firma</th><th className="num">Importe deal</th><th>Comercial</th><th className="num">Base</th><th>Tramos</th><th className="num">% efectivo</th><th className="num">Comisión</th><th className="num">Facturado</th><th /></tr>
              </thead>
              <tbody>
                {rows.map((d) => (
                  <Fragment key={d.id}>
                    {d.participants.map((p: any, i: number) => (
                      <tr key={p.id}>
                        {i === 0 && (
                          <>
                            <td rowSpan={d.participants.length}>
                              <b>{d.client}</b>
                              <div className="muted small">
                                {d.sale_type === 'compra' ? 'Compra' : 'Pago por uso'} · {d.year}
                                {d.status === 'baja' && <> · <span className="pill bad">Baja</span></>}
                              </div>
                            </td>
                            <td rowSpan={d.participants.length} className="nowrap">{fdate(d.signed_date)}</td>
                            <td rowSpan={d.participants.length} className="num">{eur0(d.total_amount)}<div className="muted small">ARR {eur0(d.base_arr)}</div></td>
                          </>
                        )}
                        <td>{p.user_name}<div className="muted small">{p.plan_name} · {pct(p.share_pct / 100)}</div></td>
                        <td className="num">{eur0(p.base)}</td>
                        <td><Slices slices={p.slices} /></td>
                        <td className="num"><b>{pct(p.effective_rate)}</b></td>
                        <td className="num">{eur(p.commission_total)}</td>
                        <td className="num">{eur0(p.invoiced_base)}<div className="muted small">de {eur0(p.base)}</div></td>
                        {i === 0 && <td rowSpan={d.participants.length}><button className="btn small" onClick={() => setEditing(d)}>Editar</button></td>}
                      </tr>
                    ))}
                  </Fragment>
                ))}
              </tbody>
            </table>
          </div>
        )}
      </div>
      {creating && <DealForm options={options} onClose={() => setCreating(false)} onSaved={done} />}
      {editing && <EditDeal deal={editing} onClose={() => setEditing(null)} onSaved={done} />}
    </>
  );
}
