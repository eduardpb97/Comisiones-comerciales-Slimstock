'use client';
import { useState } from 'react';
import { act, eur, eur0, fdate, useData } from '@/components/client';
import { AttainBar, Field, Loading, Modal, PageHead, pct0 } from '@/components/ui';

export default function Ejercicios() {
  const { data, error, reload } = useData<any>('years.list');
  const [closing, setClosing] = useState<any>(null);
  const [other, setOther] = useState('');
  const [busy, setBusy] = useState(false);
  if (!data) return <Loading error={error} />;

  const years: any[] = data.years;
  const max = years.length ? years[0].year : data.calendarYear;
  const next = max + 1;

  const open = async (year: number) => {
    if (await act('years.open', { year }, `Ejercicio ${year} abierto.`)) { setOther(''); reload(); }
  };
  const close = async () => {
    setBusy(true);
    const r = await act<any>('years.close', { year: closing.year });
    setBusy(false);
    if (r) {
      setClosing(null);
      reload();
      window.dispatchEvent(new CustomEvent('app-toast', { detail: { message: `Ejercicio ${r.year} cerrado.${r.opened ? ` Ejercicio ${r.next} abierto: todos los contadores empiezan en 0 €.` : ''}`, kind: 'ok' } }));
    }
  };
  const reopen = async (y: any) => {
    if (!window.confirm(`¿Reabrir el ejercicio ${y.year}? Volverá a admitir deals nuevos y cambios en planes y objetivos.`)) return;
    if (await act('years.reopen', { year: y.year }, `Ejercicio ${y.year} reabierto.`)) reload();
  };

  return (
    <>
      <PageHead title="Ejercicios" sub="Cada ejercicio tiene sus propios contadores de ventas, tramos y objetivos. Al cerrar uno, sus cifras quedan fijadas y el siguiente empieza en 0 €.">
        <button className="btn primary" onClick={() => open(next)}>Abrir ejercicio {next}</button>
      </PageHead>

      <div className="stack">
        {years.map((y) => {
          const isOpen = y.status === 'abierto';
          return (
            <div className="card flush" key={y.year}>
              <div className="card-head">
                <div className="row">
                  <h2 style={{ fontSize: 22 }}>{y.year}</h2>
                  <span className={`pill ${isOpen ? 'ok' : ''}`}>{isOpen ? 'Abierto' : 'Cerrado'}</span>
                  {y.year === data.currentYear && <span className="pill info">Ejercicio en curso</span>}
                  <span className="muted small">{isOpen ? `Abierto el ${fdate(y.opened_at)}` : `Cerrado el ${fdate(y.closed_at)}`}</span>
                </div>
                <div className="row">
                  {isOpen
                    ? <button className="btn navy" onClick={() => setClosing(y)}>Cerrar ejercicio {y.year}</button>
                    : <button className="btn small" onClick={() => reopen(y)}>Reabrir</button>}
                </div>
              </div>
              <div style={{ padding: '18px 20px' }} className="grid cols-4">
                <div><div className="eyebrow">Deals firmados</div><div className="num" style={{ fontSize: 20, fontWeight: 700, color: 'var(--ink)' }}>{y.deals}</div><div className="muted small">{eur0(y.deal_amount)}</div></div>
                <div><div className="eyebrow">ARR del equipo</div><div className="num" style={{ fontSize: 20, fontWeight: 700, color: 'var(--ink)' }}>{eur0(y.arr)}</div><div className="muted small">{y.goal ? `${pct0(y.pct)} de ${eur0(y.goal)}` : 'Sin objetivos asignados'}</div></div>
                <div><div className="eyebrow">Liquidado en nóminas de {y.year}</div><div className="num" style={{ fontSize: 20, fontWeight: 700, color: 'var(--ink)' }}>{eur(y.settled)}</div></div>
                <div><div className="eyebrow">Comisión aún por cobrar o liquidar</div><div className="num" style={{ fontSize: 20, fontWeight: 700, color: 'var(--ink)' }}>{eur(y.pending_collection + y.to_settle)}</div><div className="muted small">de facturas de deals de {y.year}</div></div>
              </div>
              {y.goal > 0 && <div style={{ padding: '0 20px 18px' }}><AttainBar achieved={y.arr} goal={y.goal} /></div>}
              {y.incentivePending && <div className="note" style={{ margin: '0 20px 18px' }}>El incentivo anual del Director Comercial de {y.year} está pendiente de generar. Hazlo en Liquidación mensual.</div>}
            </div>
          );
        })}

        <div className="card stack">
          <h2>Cómo funciona el cambio de ejercicio</h2>
          <div className="grid cols-3">
            <div><h3>1 · Cierra el ejercicio que termina</h3><p className="muted small">Deja de admitir deals nuevos y quedan fijados el plan, la cuota y el objetivo de cada persona en ese año. Se puede reabrir si hay que corregir algo.</p></div>
            <div><h3>2 · Se abre el siguiente</h3><p className="muted small">Nace con los contadores a 0 € y con los mismos planes y objetivos como punto de partida. Cámbialos en Usuarios, eligiendo el ejercicio nuevo.</p></div>
            <div><h3>3 · Lo pendiente sigue su curso</h3><p className="muted small">Las facturas de deals del año cerrado se siguen registrando, cobrando y liquidando con el % que tenían. Solo entonces puede generarse el incentivo del director.</p></div>
          </div>
          <div className="row" style={{ alignItems: 'flex-end' }}>
            <div style={{ width: 220 }}>
              <Field label="Abrir otro ejercicio" hint="p. ej. un año anterior">
                <input id="year-other" type="number" min="2015" max="2100" placeholder={String(years.length ? years[years.length - 1].year - 1 : data.calendarYear - 1)} value={other} onChange={(e) => setOther(e.target.value)} />
              </Field>
            </div>
            <button className="btn" disabled={!other} onClick={() => open(Number(other))}>Abrir</button>
            <span className="muted small">Útil para cargar deals históricos de años que el portal aún no tiene.</span>
          </div>
        </div>
      </div>

      {closing && (
        <Modal narrow title={`Cerrar el ejercicio ${closing.year}`} onClose={() => setClosing(null)} footer={
          <>
            <button className="btn" onClick={() => setClosing(null)}>Cancelar</button>
            <button className="btn navy" onClick={close} disabled={busy}>Cerrar {closing.year}{years.some((y) => y.year === closing.year + 1) ? '' : ` y abrir ${closing.year + 1}`}</button>
          </>
        }>
          <p>Se cierra con <b>{closing.deals} {closing.deals === 1 ? 'deal' : 'deals'}</b> y <b className="num">{eur0(closing.arr)}</b> de ARR{closing.goal ? <> ({pct0(closing.pct)} del objetivo del equipo)</> : null}.</p>
          <div className="note">
            <b>Qué pasa al cerrar</b>
            <ul style={{ margin: '6px 0 0', paddingLeft: 18 }}>
              <li>El ejercicio {closing.year} deja de admitir deals nuevos.</li>
              <li>Quedan fijados el plan, la cuota y el objetivo de cada persona en {closing.year}.</li>
              <li>{years.some((y) => y.year === closing.year + 1) ? `El ejercicio ${closing.year + 1} ya está abierto y sigue igual.` : `Se abre el ejercicio ${closing.year + 1} con todos los contadores a 0 € y los mismos planes y objetivos como punto de partida.`}</li>
            </ul>
          </div>
          <div className="note warn">
            <b>Qué no se pierde</b>
            <ul style={{ margin: '6px 0 0', paddingLeft: 18 }}>
              <li><span className="num">{eur(closing.pending_collection + closing.to_settle)}</span> de comisión pendiente de cobro o de liquidar siguen su curso en las próximas nóminas.</li>
              <li>Quedan <span className="num">{eur0(closing.base_to_invoice)}</span> de base por facturar de sus deals: sus facturas futuras comisionan al % ya fijado.</li>
            </ul>
          </div>
          <p className="muted small">Antes de cerrar, comprueba que están dados de alta todos los deals firmados en {closing.year}. Si se te escapa alguno, puedes reabrir el ejercicio.</p>
        </Modal>
      )}
    </>
  );
}
