'use client';
import { useEffect, useState } from 'react';
import { eur, eur0, fdate, pct, rpc, useData } from '@/components/client';
import { AttainBar, Diamonds, Empty, Kpi, Loading, PageHead, Ring, TeamAttainment, TierBar, YearSelect, pct0 } from '@/components/ui';

export default function PortalHome() {
  const [year, setYear] = useState<number | ''>('');
  const { data, error } = useData<any>('portal.home', { year });

  // Al abrir el portal, los avisos de liquidación se dan por leídos.
  useEffect(() => { rpc('notifications.read').catch(() => {}); }, []);

  if (!data) return <Loading error={error} />;
  const s = data.standing;
  if (!s) return <div className="card"><Empty title="Todavía no tienes un plan de comisiones asignado">Finanzas te lo asignará en breve.</Empty></div>;

  const next = data.nextPayroll.reduce((sum: number, l: any) => sum + l.amount, 0);
  const unit = s.plan.measure === 'ventas' ? 'vendido' : 'de ARR';
  const isDirector = !!data.director;

  return (
    <>
      <PageHead title="Mi progreso y nómina" sub={s.plan.name}>
        <YearSelect years={data.years} value={data.year} onChange={setYear} />
      </PageHead>
      <div className="stack">
        <div className="grid cols-2">
          <div className="card hero stack">
            <Diamonds />
            {isDirector ? (
              <>
                <div className="spread" style={{ flexWrap: 'nowrap', alignItems: 'flex-start' }}>
                  <div>
                    <div className="label">ARR del equipo · ejercicio {data.year}</div>
                    <div className="value">{eur0(data.team.total)}</div>
                    <div className="muted">{data.team.goal ? <>Objetivo del equipo: <b className="num">{eur0(data.team.goal)}</b></> : 'Sin objetivo de equipo definido'}</div>
                  </div>
                  {data.team.goal && <Ring value={data.team.pct} />}
                </div>
                {data.team.goal && <AttainBar achieved={data.team.total} goal={data.team.goal} />}
                <hr />
                <div>
                  Tu incentivo anual devengado: <b className="num">{eur(s.earned)}</b> (6 % de {eur0(s.accumulated)} de ARR de dirección).{' '}
                  {data.director.closed ? 'Ejercicio cerrado.' : `Se calcula cuando Finanzas cierra el ejercicio ${data.year} y se abona en abril de ${data.year + 1}.`}
                </div>
              </>
            ) : (
              <>
                <div className="spread" style={{ flexWrap: 'nowrap', alignItems: 'flex-start' }}>
                  <div>
                    <div className="label">Acumulado en el ejercicio {data.year}</div>
                    <div className="value">{eur0(s.accumulated)}</div>
                    <div className="muted">{unit} para el escalado de tu plan</div>
                  </div>
                  {s.target && <Ring value={s.target.pct} label="objetivo ARR" />}
                </div>
                {s.tiers.length > 1 && <TierBar tiers={s.tiers} accumulated={s.accumulated} />}
                {s.tiers.length > 1 ? (
                  <div>
                    Estás en el tramo <b>{s.progress.current.label}</b>.{' '}
                    {s.progress.toNext !== null
                      ? <>Te faltan <b className="num">{eur0(s.progress.toNext)}</b> para pasar a <b>{s.progress.next.label}</b>.</>
                      : 'Es el tramo más alto de tu plan.'}
                  </div>
                ) : (
                  <div>Comisión generada por tus ventas del año: <b className="num">{eur(s.earned)}</b>.</div>
                )}
                {s.target && (
                  <>
                    <hr />
                    <div className="stack" style={{ gap: 8 }}>
                      <div className="spread">
                        <div className="label">Objetivo anual de ARR</div>
                        <span className="pill info">{pct0(s.target.pct)} conseguido</span>
                      </div>
                      <AttainBar achieved={s.target.achieved} goal={s.target.goal} />
                    </div>
                  </>
                )}
              </>
            )}
          </div>

          <div className="card flush">
            <div className="card-head">
              <div>
                <div className="eyebrow">Previsión próxima nómina</div>
                <div style={{ fontSize: 34 }} className="big">{eur(next)}</div>
              </div>
              <span className="pill info">{data.nextPayroll.length} {data.nextPayroll.length === 1 ? 'factura cobrada' : 'facturas cobradas'}</span>
            </div>
            {data.nextPayroll.length === 0 ? (
              <Empty title="Nada pendiente de liquidar">Cuando un cliente pague una factura tuya, su comisión aparecerá aquí.</Empty>
            ) : (
              <div className="table-wrap">
                <table>
                  <thead><tr><th>Cliente</th><th>Factura</th><th className="num">Base</th><th className="num">%</th><th className="num">Comisión</th></tr></thead>
                  <tbody>
                    {data.nextPayroll.map((l: any) => (
                      <tr key={l.id}><td>{l.client}</td><td>{l.reference}</td><td className="num">{eur(l.base)}</td><td className="num">{pct(l.rate)}</td><td className="num"><b>{eur(l.amount)}</b></td></tr>
                    ))}
                  </tbody>
                </table>
              </div>
            )}
            <p className="muted small" style={{ padding: '12px 20px' }}>Importe bruto. Finanzas cierra la liquidación hacia el día 18 de cada mes y recibirás aquí el aviso con el desglose definitivo.</p>
          </div>
        </div>

        <div className="grid cols-3">
          <Kpi tone="warn" label="Comisión pendiente de que el cliente pague" value={eur(s.pendingCollection)} hint="Facturas emitidas y aún no cobradas" />
          <Kpi tone="ok" label={`Cobrado en nóminas de ${data.year}`} value={eur(s.settledInYear)} hint="Comisiones ya liquidadas" />
          <Kpi tone="accent" label={isDirector ? `Incentivo ${data.year} devengado` : `Comisión total de tus deals de ${data.year}`} value={eur(s.earned)} hint={isDirector ? '6 % del ARR del ejercicio' : 'Cuando todo esté facturado y cobrado'} />
        </div>

        {isDirector && <TeamAttainment team={data.team} title="Consecución de tu equipo" />}

        {isDirector && (
          <div className="card flush">
            <div className="card-head"><h2>ARR generado en {data.year}</h2><b className="num">{eur0(data.director.arr)}</b></div>
            {data.director.deals.length === 0 ? <Empty title="Sin deals con ARR en este ejercicio" /> : (
              <div className="table-wrap">
                <table>
                  <thead><tr><th>Cliente</th><th>Firma</th><th>Tipo</th><th className="num">ARR</th><th className="num">6 %</th></tr></thead>
                  <tbody>
                    {data.director.deals.map((d: any) => (
                      <tr key={d.id}><td>{d.client}</td><td>{fdate(d.signed_date)}</td><td>{d.sale_type === 'compra' ? 'Compra (mantenimiento)' : 'Pago por uso'}</td><td className="num">{eur(d.base_arr_direccion)}</td><td className="num">{eur(d.base_arr_direccion * 0.06)}</td></tr>
                    ))}
                  </tbody>
                </table>
              </div>
            )}
          </div>
        )}

        <div className="card flush">
          <div className="card-head"><h2>Avisos de liquidación</h2></div>
          {data.notifications.length === 0 ? <Empty title="Aún no has recibido ningún aviso" /> : (
            <div>
              {data.notifications.map((n: any) => (
                <div key={n.id} className="notice">
                  <div className="spread">
                    <b>{n.title}</b>
                    <span className="row">{!n.read_at && <span className="pill info">Nuevo</span>}<b className="num">{eur(n.amount)}</b></span>
                  </div>
                  <div className="muted small">Recibido el {fdate(n.created_at)}</div>
                  <div className="pre" style={{ marginTop: 6 }}>{n.body}</div>
                </div>
              ))}
            </div>
          )}
        </div>
      </div>
    </>
  );
}
