import { redirect } from 'next/navigation';
import { currentUser } from '@/lib/auth';
import { dbGet } from '@/lib/db';
import { Shell } from '@/components/Shell';

export const dynamic = 'force-dynamic';

export default async function PortalLayout({ children }: { children: React.ReactNode }) {
  const me = await currentUser();
  if (!me) redirect('/login');
  if (me.must_change_password) redirect('/cambiar-clave');
  if (me.role !== 'comercial') redirect('/admin');
  const unread = (await dbGet<{ n: number }>('SELECT COUNT(*) AS n FROM notifications WHERE user_id=? AND read_at IS NULL', [me.id]))?.n || 0;
  return (
    <Shell
      title="Mis comisiones"
      user={{ name: me.name, email: me.email }}
      nav={[
        { href: '/portal', label: 'Mi progreso y nómina', count: unread },
        { href: '/portal/deals', label: 'Mis deals y facturas' },
        { href: '/portal/historico', label: 'Histórico de liquidaciones' },
        { href: '/portal/consultas', label: 'Consultas a Finanzas' },
        { href: '/portal/perfil', label: 'Mi perfil' },
      ]}
    >
      {children}
    </Shell>
  );
}
