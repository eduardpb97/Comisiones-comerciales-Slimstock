'use client';
import { useMemo, useState } from 'react';
import { MONTHS, eur, fdate, pct, useData } from '@/components/client';
import { Empty, Kpi, Loading, PageHead, YearSelect } from '@/components/ui';

export default function Historico() {
  const [year, setYear] = useState<number | ''>('');
  const { data, error } = useData<any>('portal.history', { year });
  const groups = useMemo(() => {
    const m = new Map<number, any[]>();
    for (const l of data?.lines || []) (m.get(l.settlement_id) || m.set(l.settlement_id, []).get(l.settlement_id)!).push(l);
    return [...m.entries()].sort((a, b) => b[0] - a[0]);
  }, [data]);
  if (!data) return <Loading error={error} />;
  const total = data.lines.reduce((s: number, l: any) => s + l.amount, 0);

  return (
    <>
      <PageHead title="Histórico de liquidaciones" sub="Comisiones ya cobradas en nómina. Cambia de ejercicio para consultar años anteriores.">
        <YearSelect years={data.years} value={data.year} onChange={setYear} />
      </PageHead>
      <div className="stack">
        <div className="grid cols-3">
          <Kpi tone="ok" label={`Total cobrado en nóminas de ${data.year}`} value={eur(total)} hint={`${groups.length} ${groups.length === 1 ? 'liquidación' : 'liquidaciones'}`} />
        </div>
        {groups.length === 0 && <div className="card"><Empty title={`Sin liquidaciones en ${data.year}`} /></div>}
        {groups.map(([id, lines]) => (
          <div className="card flush" key={id}>
            <div className="card-head">
              <h2>Nómina de {MONTHS[lines[0].settlement_month - 1]} {lines[0].settlement_year}</h2>
              <b className="num">{eur(lines.reduce((s, l) => s + l.amount, 0))}</b>
            </div>
            <div className="table-wrap">
              <table>
                <thead><tr><th>Cliente</th><th>Factura</th><th>Cobrada el</th><th className="num">Base</th><th className="num">%</th><th className="num">Comisión</th></tr></thead>
                <tbody>
                  {lines.map((l) => (
                    <tr key={l.id}><td>{l.client}</td><td>{l.reference}</td><td>{fdate(l.paid_date)}</td><td className="num">{eur(l.base)}</td><td className="num">{pct(l.rate)}</td><td className="num"><b>{eur(l.amount)}</b></td></tr>
                  ))}
                </tbody>
              </table>
            </div>
          </div>
        ))}
      </div>
    </>
  );
}
