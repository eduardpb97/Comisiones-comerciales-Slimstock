'use client';
import { useState } from 'react';
import { eur, eur0, fdate, pct, useData } from '@/components/client';
import { Empty, InvoiceStatus, LineStatus, Loading, METHOD, PageHead, YearSelect } from '@/components/ui';

export default function MisDeals() {
  const [year, setYear] = useState<number | ''>('');
  const { data, error } = useData<any>('portal.deals', { year });
  if (!data) return <Loading error={error} />;
  const manual = data.invoices.filter((i: any) => i.kind === 'manual');

  return (
    <>
      <PageHead title="Mis deals y facturas" sub="Tus deals cerrados, las facturas emitidas de cada uno y si el cliente ya las ha pagado.">
        <YearSelect years={data.years} value={data.year} onChange={setYear} />
      </PageHead>
      <div className="stack">
        {data.deals.length === 0 && manual.length === 0 && <div className="card"><Empty title={`Sin deals en ${data.year}`} /></div>}
        {data.deals.map((d: any) => {
          const p = d.participants[0];
          const invoices = data.invoices.filter((i: any) => i.deal_id === d.id);
          return (
            <div className="card flush" key={d.id}>
              <div className="card-head">
                <div>
                  <h2>{d.client} {d.status === 'baja' && <span className="pill bad">Baja</span>}</h2>
                  <div className="muted small">
                    Firmado el {fdate(d.signed_date)} · {d.sale_type === 'compra' ? 'Compra de licencias' : 'Pago por uso'}
                    {d.sharedWith.length > 0 && ` · compartido con ${d.sharedWith.join(' y ')}`}
                  </div>
                </div>
                {p && (
                  <div className="right">
                    <div>Tu base: <b className="num">{eur0(p.base)}</b> ({pct(p.share_pct / 100)}) · comisión <b className="num">{eur(p.commission_total)}</b></div>
                    <div className="slices" style={{ justifyContent: 'flex-end', marginTop: 4 }}>
                      {p.slices.map((s: any) => <span className="tag" key={s.label}>{eur0(s.amount)} al {pct(s.rate)}</span>)}
                      <span className="pill info">% efectivo {pct(p.effective_rate)}</span>
                    </div>
                  </div>
                )}
              </div>
              {invoices.length === 0 ? <Empty title="Todavía no se ha emitido ninguna factura de este deal" /> : (
                <div className="table-wrap">
                  <table>
                    <thead><tr><th>Factura</th><th>Fecha</th><th>Vencimiento</th><th>Método</th><th className="num">Importe</th><th>Pago del cliente</th><th className="num">Tu comisión</th><th>Estado de tu comisión</th></tr></thead>
                    <tbody>
                      {invoices.map((i: any) => (
                        <tr key={i.id}>
                          <td>{i.number}</td><td>{fdate(i.issue_date)}</td><td>{fdate(i.due_date)}</td><td>{METHOD[i.method]}</td>
                          <td className="num">{eur(i.amount)}</td>
                          <td><InvoiceStatus inv={i} /></td>
                          <td className="num"><b>{eur(i.lines[0]?.amount)}</b></td>
                          <td>{i.lines[0] && <LineStatus status={i.lines[0].status} />}</td>
                        </tr>
                      ))}
                    </tbody>
                  </table>
                </div>
              )}
            </div>
          );
        })}
        {manual.length > 0 && (
          <div className="card flush">
            <div className="card-head"><h2>Otras comisiones (fuera de deal)</h2></div>
            <div className="table-wrap">
              <table>
                <thead><tr><th>Cliente / concepto</th><th>Vencimiento</th><th className="num">Importe</th><th>Pago del cliente</th><th className="num">Tu comisión</th><th>Estado</th></tr></thead>
                <tbody>
                  {manual.map((i: any) => (
                    <tr key={i.id}>
                      <td>{i.client}</td><td>{fdate(i.due_date)}</td><td className="num">{eur(i.amount)}</td>
                      <td><InvoiceStatus inv={i} /></td><td className="num"><b>{eur(i.lines[0]?.amount)}</b></td>
                      <td>{i.lines[0] && <LineStatus status={i.lines[0].status} />}</td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          </div>
        )}
      </div>
    </>
  );
}
