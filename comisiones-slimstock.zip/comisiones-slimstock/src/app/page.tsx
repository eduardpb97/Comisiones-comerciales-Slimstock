import { redirect } from 'next/navigation';
import { currentUser } from '@/lib/auth';

export const dynamic = 'force-dynamic';

export default async function Home() {
  const me = await currentUser();
  if (!me) redirect('/login');
  if (me.must_change_password) redirect('/cambiar-clave');
  redirect(me.role === 'finanzas' ? '/admin' : '/portal');
}
