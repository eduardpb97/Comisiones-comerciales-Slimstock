/**
 * Operaciones de negocio. Todas pasan por await run(), que comprueba en servidor
 * el rol del usuario antes de ejecutar nada.
 */
import bcrypt from 'bcryptjs';
import { dbAll, dbGet, dbRun, isCloud, tx } from './db';
import {
  AppError, SessionUser, hashPassword, validateNewPassword, temporaryPassword, endSessionsOf,
} from './auth';
import {
  PLANS, PlanId, DealComponents, EMPTY_COMPONENTS, INVOICE_CONCEPTS, InvoiceConcept, DIRECTOR_RATE,
  DEFAULT_QUOTA, MANUAL_DEFAULT_RATE, allocate, baseForMeasure, computeBases, invoiceFactor, invoiceLine,
  progress, round2, tiersFor,
} from './commission';

/* ------------------------------------------------------------------ */
/* Utilidades                                                          */
/* ------------------------------------------------------------------ */

export const MONTHS = ['Enero', 'Febrero', 'Marzo', 'Abril', 'Mayo', 'Junio', 'Julio', 'Agosto', 'Septiembre', 'Octubre', 'Noviembre', 'Diciembre'];

export function today(): string {
  return new Intl.DateTimeFormat('sv-SE', { timeZone: 'Europe/Madrid' }).format(new Date());
}
const calendarYear = () => Number(today().slice(0, 4));

function str(v: unknown, field: string, max = 300): string {
  if (typeof v !== 'string' || !v.trim()) throw new AppError(`Falta el campo «${field}».`);
  return v.trim().slice(0, max);
}
function optStr(v: unknown, max = 2000): string {
  return typeof v === 'string' ? v.trim().slice(0, max) : '';
}
function num(v: unknown, field: string): number {
  const n = typeof v === 'string' ? Number(v.replace(',', '.')) : Number(v);
  if (!Number.isFinite(n)) throw new AppError(`«${field}» debe ser un número.`);
  return n;
}
function int(v: unknown, field: string): number {
  const n = num(v, field);
  if (!Number.isInteger(n)) throw new AppError(`«${field}» no es válido.`);
  return n;
}
function date(v: unknown, field: string): string {
  if (typeof v !== 'string' || !/^\d{4}-\d{2}-\d{2}$/.test(v) || Number.isNaN(Date.parse(v))) {
    throw new AppError(`«${field}» debe ser una fecha válida.`);
  }
  return v;
}
const all = <T = any>(sql: string, ...p: any[]) => dbAll<T>(sql, p);
const one = <T = any>(sql: string, ...p: any[]) => dbGet<T>(sql, p);
const exec = (sql: string, ...p: any[]) => dbRun(sql, p);
/** Como Array.map con funciones asíncronas, pero de una en una (dentro de una transacción no se puede en paralelo). */
async function mapSeq<A, B>(items: A[], fn: (item: A, index: number) => Promise<B>): Promise<B[]> {
  const out: B[] = [];
  for (let i = 0; i < items.length; i++) out.push(await fn(items[i], i));
  return out;
}

const eur = (n: number) => new Intl.NumberFormat('es-ES', { style: 'currency', currency: 'EUR', useGrouping: 'always' } as Intl.NumberFormatOptions).format(n);
const pct = (r: number) => `${new Intl.NumberFormat('es-ES', { maximumFractionDigits: 2 }).format(r * 100)} %`;

/* ------------------------------------------------------------------ */
/* Cobros                                                              */
/* ------------------------------------------------------------------ */

async function setPaid(invoiceId: number, paidDate: string) {
  await exec("UPDATE invoices SET status='cobrada', paid_date=? WHERE id=? AND status='pendiente'", paidDate, invoiceId);
  await exec("UPDATE commission_lines SET status='por_liquidar' WHERE invoice_id=? AND status='pendiente_cobro'", invoiceId);
}

/** Los giros bancarios se dan por cobrados al llegar su vencimiento. */
export async function autoCollectGiros() {
  const due = await all<{ id: number; due_date: string }>(
    "SELECT id, due_date FROM invoices WHERE method='giro' AND status='pendiente' AND due_date <= ?", today()
  );
  if (due.length) await tx(async () => { for (const i of due) await setPaid(i.id, i.due_date); });
}

/* ------------------------------------------------------------------ */
/* Usuarios                                                            */
/* ------------------------------------------------------------------ */

const USER_FIELDS = 'id, email, name, role, department, plan_id, quota, arr_target, active, must_change_password, created_at';

/* ------------------------------------------------------------------ */
/* Ejercicios                                                          */
/* ------------------------------------------------------------------ */

type FiscalYear = { year: number; status: 'abierto' | 'cerrado'; opened_at: string; closed_at: string | null };

const fiscalYears = async () => all<FiscalYear>('SELECT year, status, opened_at, closed_at FROM fiscal_years ORDER BY year DESC');
const fiscalYear = async (year: number) => one<FiscalYear>('SELECT year, status, opened_at, closed_at FROM fiscal_years WHERE year=?', year);
const isClosed = async (year: number) => (await fiscalYear(year))?.status === 'cerrado';

/** Guarda para un ejercicio el plan, la cuota y el objetivo de quien aún no los tenga, tomándolos de `from`. */
async function materializeUserYears(year: number, from?: number) {
  if (from !== undefined) {
    await exec(`INSERT OR IGNORE INTO user_years (user_id, year, plan_id, quota, arr_target)
          SELECT user_id, ?, plan_id, quota, arr_target FROM user_years WHERE year = ?`, year, from);
  }
  await exec(`INSERT OR IGNORE INTO user_years (user_id, year, plan_id, quota, arr_target)
        SELECT id, ?, plan_id, quota, arr_target FROM users WHERE role = 'comercial'`, year);
}

/** Primera vez (o base de una versión anterior): crea los ejercicios que ya tienen datos y el año en curso. */
async function ensureFiscalYears() {
  if (await one('SELECT year FROM fiscal_years LIMIT 1')) return;
  await tx(async () => {
    const years = new Set<number>((await all<{ y: number }>(
      'SELECT DISTINCT year AS y FROM deals UNION SELECT DISTINCT year FROM invoices UNION SELECT DISTINCT year FROM settlements'
    )).map((r) => r.y));
    years.add(calendarYear());
    for (const y of [...years].sort()) {
      await exec('INSERT OR IGNORE INTO fiscal_years (year) VALUES (?)', y);
      await materializeUserYears(y);
    }
  });
}

/** Ejercicio que se muestra por defecto: el año natural si está abierto; si no, el último abierto. */
async function currentYear(): Promise<number> {
  const ys = await fiscalYears();
  const cal = calendarYear();
  if (ys.some((y) => y.year === cal && y.status === 'abierto')) return cal;
  return ys.find((y) => y.status === 'abierto')?.year ?? ys[0]?.year ?? cal;
}

async function openYear(p: any) {
  const year = int(p.year, 'Ejercicio');
  if (year < 2015 || year > 2100) throw new AppError('El ejercicio no es válido.');
  if (await fiscalYear(year)) throw new AppError(`El ejercicio ${year} ya existe.`);
  return await tx(async () => {
    // Antes de crear otro ejercicio se fijan los valores de los existentes, para que no se mezclen.
    for (const y of await fiscalYears()) await materializeUserYears(y.year);
    const previous = (await fiscalYears()).filter((y) => y.year < year)[0]?.year;
    await exec('INSERT INTO fiscal_years (year) VALUES (?)', year);
    await materializeUserYears(year, previous);
    return { year };
  });
}

async function closeYear(me: SessionUser, p: any) {
  const year = int(p.year, 'Ejercicio');
  const fy = await fiscalYear(year);
  if (!fy) throw new AppError(`El ejercicio ${year} no existe.`, 404);
  if (fy.status === 'cerrado') throw new AppError(`El ejercicio ${year} ya está cerrado.`);
  return await tx(async () => {
    await materializeUserYears(year);
    await exec("UPDATE fiscal_years SET status='cerrado', closed_at=datetime('now'), closed_by=? WHERE year=?", me.id, year);
    const next = year + 1;
    const opened = !await fiscalYear(next);
    if (opened) await openYear({ year: next });
    return { year, next, opened };
  });
}

async function reopenYear(p: any) {
  const year = int(p.year, 'Ejercicio');
  if (!await isClosed(year)) throw new AppError(`El ejercicio ${year} no está cerrado.`);
  await exec("UPDATE fiscal_years SET status='abierto', closed_at=NULL, closed_by=NULL WHERE year=?", year);
  return { year };
}

/** Usuarios con el plan, la cuota y el objetivo que tenían en un ejercicio concreto. */
const USER_YEAR_SELECT = `
  SELECT u.id, u.email, u.name, u.role, u.department, u.active, u.must_change_password, u.created_at,
    CASE WHEN y.user_id IS NULL THEN u.plan_id ELSE y.plan_id END AS plan_id,
    CASE WHEN y.user_id IS NULL THEN u.quota ELSE y.quota END AS quota,
    CASE WHEN y.user_id IS NULL THEN u.arr_target ELSE y.arr_target END AS arr_target
  FROM users u LEFT JOIN user_years y ON y.user_id = u.id AND y.year = ?`;
const usersOf = async (year: number, where = '', ...params: any[]) => all<any>(`${USER_YEAR_SELECT} ${where}`, year, ...params);
const userOf = async (year: number, id: number) => (await usersOf(year, 'WHERE u.id = ?', id))[0];

async function listUsers(p: any) {
  const year = p.year ? int(p.year, 'Ejercicio') : await currentYear();
  return { year, years: await fiscalYears(), users: await usersOf(year, 'ORDER BY u.active DESC, u.role DESC, u.name') };
}

async function saveUser(me: SessionUser, p: any) {
  const email = str(p.email, 'Correo', 200).toLowerCase();
  if (!/^[^@\s]+@[^@\s]+\.[^@\s]+$/.test(email)) throw new AppError('El correo no es válido.');
  const name = str(p.name, 'Nombre', 120);
  const role = p.role === 'finanzas' ? 'finanzas' : 'comercial';
  const department = role === 'finanzas' ? 'FINANZAS' : p.department === 'CONSULTORIA' ? 'CONSULTORIA' : 'COMERCIAL';
  const planId = role === 'finanzas' ? null : int(p.planId, 'Plan de comisiones');
  if (planId !== null && !PLANS[planId as PlanId]) throw new AppError('Plan de comisiones no válido.');
  const quota = planId === 3 ? num(p.quota || DEFAULT_QUOTA, 'Cuota anual') : null;
  if (quota !== null && quota <= 0) throw new AppError('La cuota anual debe ser mayor que cero.');
  const active = p.active === false ? 0 : 1;
  const arrTarget = role === 'finanzas' || p.arrTarget === undefined || p.arrTarget === null || p.arrTarget === '' ? null : num(p.arrTarget, 'Objetivo anual de ARR');
  if (arrTarget !== null && arrTarget < 0) throw new AppError('El objetivo anual de ARR no puede ser negativo.');

  // El plan, la cuota y el objetivo se guardan para el ejercicio elegido en la pantalla.
  const year = p.year ? int(p.year, 'Ejercicio') : await currentYear();
  const fy = await fiscalYear(year);
  if (!fy) throw new AppError(`El ejercicio ${year} no existe. Ábrelo en Ejercicios.`);
  const isCurrent = year === (await currentYear());
  const setYear = async (id: number) => {
    if (role !== 'comercial') return;
    await exec(`INSERT INTO user_years (user_id, year, plan_id, quota, arr_target) VALUES (?,?,?,?,?)
          ON CONFLICT(user_id, year) DO UPDATE SET plan_id=excluded.plan_id, quota=excluded.quota, arr_target=excluded.arr_target`,
      id, year, planId, quota, arrTarget || null);
  };

  const clash = await one('SELECT id FROM users WHERE email = ?', email);
  if (p.id) {
    const id = int(p.id, 'Usuario');
    if (clash && clash.id !== id) throw new AppError('Ya existe un usuario con ese correo.');
    if (id === me.id && (role !== 'finanzas' || !active)) {
      throw new AppError('No puedes quitarte a ti mismo el rol de Finanzas ni desactivarte.');
    }
    const before = await userOf(year, id);
    if (!before) throw new AppError('Usuario no encontrado.', 404);
    const yearChanged = role === 'comercial' && (before.plan_id !== planId || (before.quota || null) !== quota || (before.arr_target || null) !== (arrTarget || null));
    if (yearChanged && fy.status === 'cerrado') {
      throw new AppError(`El ejercicio ${year} está cerrado: su plan y su objetivo ya no se pueden cambiar. Reábrelo en Ejercicios si necesitas corregirlos.`);
    }
    await tx(async () => {
      await exec('UPDATE users SET email=?, name=?, role=?, department=?, active=? WHERE id=?', email, name, role, department, active, id);
      if (role === 'finanzas') await exec('UPDATE users SET plan_id=NULL, quota=NULL, arr_target=NULL WHERE id=?', id);
      else if (isCurrent || before.role !== 'comercial') await exec('UPDATE users SET plan_id=?, quota=?, arr_target=? WHERE id=?', planId, quota, arrTarget || null, id);
      if (yearChanged || before.role !== 'comercial') await setYear(id);
    });
    if (!active) await endSessionsOf(id);
    return { id };
  }
  if (clash) throw new AppError('Ya existe un usuario con ese correo.');
  const password = temporaryPassword();
  const r = await exec(
    'INSERT INTO users (email, name, password_hash, role, department, plan_id, quota, arr_target, active, must_change_password) VALUES (?,?,?,?,?,?,?,?,?,1)',
    email, name, hashPassword(password), role, department, planId, quota, arrTarget || null, active
  );
  const newId = Number(r.lastInsertRowid);
  // Una persona nueva parte con los mismos valores en todos los ejercicios abiertos.
  if (role === 'comercial') for (const y of (await fiscalYears()).filter((x) => x.status === 'abierto')) await materializeUserYears(y.year);
  await setYear(newId);
  return { id: newId, temporaryPassword: password };
}

async function resetPassword(p: any) {
  const id = int(p.id, 'Usuario');
  if (!await one('SELECT id FROM users WHERE id=?', id)) throw new AppError('Usuario no encontrado.', 404);
  const password = temporaryPassword();
  await exec('UPDATE users SET password_hash=?, must_change_password=1 WHERE id=?', hashPassword(password), id);
  await endSessionsOf(id);
  return { temporaryPassword: password };
}

async function changePassword(me: SessionUser, p: any) {
  const row = (await one<{ password_hash: string }>('SELECT password_hash FROM users WHERE id=?', me.id))!;
  if (typeof p.current !== 'string' || !bcrypt.compareSync(p.current, row.password_hash)) {
    throw new AppError('La contraseña actual no es correcta.');
  }
  const next = validateNewPassword(p.next);
  if (next === p.current) throw new AppError('La nueva contraseña debe ser distinta de la actual.');
  await exec('UPDATE users SET password_hash=?, must_change_password=0 WHERE id=?', hashPassword(next), me.id);
  // Cualquier otra sesión abierta con la contraseña anterior deja de valer.
  if (me.session) await endSessionsOf(me.id, me.session);
  return { ok: true };
}

/* ------------------------------------------------------------------ */
/* Deals                                                               */
/* ------------------------------------------------------------------ */

function parseComponents(c: any): DealComponents {
  const out = { ...EMPTY_COMPONENTS };
  for (const k of Object.keys(out) as (keyof DealComponents)[]) {
    const v = c && c[k] !== undefined && c[k] !== '' ? num(c[k], k) : 0;
    if (v < 0) throw new AppError('Los importes del deal no pueden ser negativos.');
    out[k] = v;
  }
  if (out.partnerFeePct > 100) throw new AppError('El fee del partner no puede superar el 100 %.');
  return out;
}

/** Acumulado anual del comercial en su plan, antes de registrar un nuevo deal. */
async function accumulated(userId: number, planId: number, year: number): Promise<number> {
  const r = await one<{ s: number | null }>(
    `SELECT SUM(dp.base) AS s FROM deal_participants dp JOIN deals d ON d.id = dp.deal_id
     WHERE dp.user_id = ? AND dp.plan_id = ? AND d.year = ?`, userId, planId, year
  );
  return round2(r?.s || 0);
}

/** Calcula bases, reparto y posición en tramos de un deal. No escribe nada. */
async function buildDeal(p: any) {
  const client = str(p.client, 'Nombre del cliente', 160);
  const signedDate = date(p.signedDate, 'Fecha de firma');
  const year = p.year ? int(p.year, 'Ejercicio') : Number(signedDate.slice(0, 4));
  if (year < 2015 || year > 2100) throw new AppError('El ejercicio no es válido.');
  const fy = await fiscalYear(year);
  if (!fy) throw new AppError(`El ejercicio ${year} no está abierto. Ábrelo en Ejercicios o elige otro ejercicio para este deal.`);
  if (fy.status === 'cerrado') throw new AppError(`El ejercicio ${year} está cerrado y no admite deals nuevos. Elige otro ejercicio, o reábrelo en Ejercicios.`);
  const saleType = p.saleType === 'compra' ? 'compra' : 'pago_uso';
  const components = parseComponents(p.components);
  const computed = computeBases(components);
  const o = p.overrides || {};
  const pick = (v: any, fallback: number, label: string) => {
    if (v === undefined || v === null || v === '') return fallback;
    const n = num(v, label);
    if (n < 0) throw new AppError(`«${label}» no puede ser negativo.`);
    return round2(n);
  };
  const bases = {
    ventas: pick(o.ventas, computed.ventas, 'Base de ventas'),
    arr: pick(o.arr, computed.arr, 'ARR comercial'),
    arrDireccion: pick(o.arrDireccion, computed.arrDireccion, 'ARR dirección'),
  };
  if (bases.ventas <= 0 && bases.arr <= 0) throw new AppError('Indica los importes del deal: ahora mismo su base es 0 €.');

  const raw: any[] = Array.isArray(p.participants) ? p.participants : [];
  if (raw.length < 1 || raw.length > 3) throw new AppError('Asigna entre 1 y 3 comerciales al deal.');
  const ids = raw.map((x) => int(x.userId, 'Comercial'));
  if (new Set(ids).size !== ids.length) throw new AppError('Un comercial no puede aparecer dos veces en el mismo deal.');

  const shares = raw.map((x) => (x.sharePct === undefined || x.sharePct === null || x.sharePct === '' ? 100 / raw.length : num(x.sharePct, 'Reparto')));
  if (shares.some((s) => s <= 0 || s > 100)) throw new AppError('El reparto de cada comercial debe estar entre 0 y 100 %.');
  if (shares.reduce((a, b) => a + b, 0) > 100.01) throw new AppError('El reparto entre comerciales supera el 100 %.');

  const participants = await mapSeq(ids, async (userId, i) => {
    const u = await userOf(year, userId);
    if (!u || u.role !== 'comercial' || !u.active) throw new AppError('El comercial seleccionado no existe o está desactivado.');
    if (!u.plan_id) throw new AppError(`${u.name} no tiene plan de comisiones asignado.`);
    const plan = PLANS[u.plan_id as PlanId];
    if (!plan.perInvoice) {
      throw new AppError(`${u.name} tiene el plan de Director Comercial: comisiona sobre todo el ARR del año y no se asigna a deals.`);
    }
    const base = round2(baseForMeasure(bases, plan.measure) * (shares[i] / 100));
    const accumBefore = await accumulated(userId, plan.id, year);
    const a = allocate(tiersFor(plan.id, u.quota), accumBefore, base);
    return {
      userId, name: u.name as string, planId: plan.id, planName: plan.short, measure: plan.measure,
      sharePct: shares[i], base, accumBefore, accumAfter: round2(accumBefore + base),
      slices: a.slices, commission: a.commission, effectiveRate: a.effectiveRate,
    };
  });

  return {
    client, year, signedDate, saleType, components, bases, partnerFee: computed.partnerFee,
    totalAmount: round2(bases.ventas + computed.partnerFee), notes: optStr(p.notes), participants,
  };
}

async function createDeal(p: any) {
  return await tx(async () => {
    const d = await buildDeal(p);
    const r = await exec(
      `INSERT INTO deals (client, year, signed_date, sale_type, components, total_amount, base_ventas, base_arr, base_arr_direccion, notes)
       VALUES (?,?,?,?,?,?,?,?,?,?)`,
      d.client, d.year, d.signedDate, d.saleType, JSON.stringify(d.components), d.totalAmount,
      d.bases.ventas, d.bases.arr, d.bases.arrDireccion, d.notes
    );
    const dealId = Number(r.lastInsertRowid);
    for (const x of d.participants) {
      await exec(
        `INSERT INTO deal_participants (deal_id, user_id, share_pct, plan_id, base, accum_before, slices, commission_total, effective_rate)
         VALUES (?,?,?,?,?,?,?,?,?)`,
        dealId, x.userId, x.sharePct, x.planId, x.base, x.accumBefore, JSON.stringify(x.slices), x.commission, x.effectiveRate
      );
    }
    return { id: dealId };
  });
}

async function updateDeal(p: any) {
  const id = int(p.id, 'Deal');
  const deal = await one<any>('SELECT * FROM deals WHERE id=?', id);
  if (!deal) throw new AppError('Deal no encontrado.', 404);
  const client = str(p.client, 'Nombre del cliente', 160);
  const status = p.status === 'baja' ? 'baja' : 'activo';
  await tx(async () => {
    await exec('UPDATE deals SET client=?, notes=?, status=? WHERE id=?', client, optStr(p.notes), status, id);
    if (client !== deal.client) {
      await exec('UPDATE invoices SET client=? WHERE deal_id=?', client, id);
      await exec('UPDATE commission_lines SET client=? WHERE deal_id=?', client, id);
    }
  });
  return { id };
}

async function deleteDeal(p: any) {
  const id = int(p.id, 'Deal');
  if (await one('SELECT id FROM invoices WHERE deal_id=? LIMIT 1', id)) {
    throw new AppError('Este deal ya tiene facturas. Elimina antes sus facturas o márcalo como baja.');
  }
  await exec('DELETE FROM deal_participants WHERE deal_id=?', id);
  await exec('DELETE FROM deals WHERE id=?', id);
  return { ok: true };
}

/** Deals con participantes y totales de facturación. userId limita a un comercial. */
export async function listDeals(filter: { year?: number; userId?: number } = {}) {
  const where: string[] = [];
  const params: any[] = [];
  if (filter.year) { where.push('d.year = ?'); params.push(filter.year); }
  if (filter.userId) { where.push('d.id IN (SELECT deal_id FROM deal_participants WHERE user_id = ?)'); params.push(filter.userId); }
  const deals = await all<any>(
    `SELECT d.*,
       (SELECT COALESCE(SUM(amount),0) FROM invoices i WHERE i.deal_id = d.id) AS invoiced,
       (SELECT COALESCE(SUM(amount),0) FROM invoices i WHERE i.deal_id = d.id AND i.status='cobrada') AS collected,
       (SELECT COUNT(*) FROM invoices i WHERE i.deal_id = d.id) AS invoice_count
     FROM deals d ${where.length ? 'WHERE ' + where.join(' AND ') : ''}
     ORDER BY d.signed_date DESC, d.id DESC`, ...params
  );
  if (!deals.length) return [];
  const ids = deals.map((d) => d.id);
  const marks = ids.map(() => '?').join(',');
  const parts = await all<any>(
    `SELECT dp.*, u.name AS user_name,
       (SELECT COALESCE(SUM(base),0) FROM commission_lines l WHERE l.deal_id = dp.deal_id AND l.user_id = dp.user_id) AS invoiced_base,
       (SELECT COALESCE(SUM(amount),0) FROM commission_lines l WHERE l.deal_id = dp.deal_id AND l.user_id = dp.user_id AND l.status='liquidada') AS settled
     FROM deal_participants dp JOIN users u ON u.id = dp.user_id
     WHERE dp.deal_id IN (${marks}) ORDER BY dp.id`, ...ids
  );
  return deals.map((d) => ({
    ...d,
    components: JSON.parse(d.components),
    participants: parts
      .filter((x) => x.deal_id === d.id)
      .map((x) => ({ ...x, slices: JSON.parse(x.slices), plan_name: PLANS[x.plan_id as PlanId]?.short })),
  }));
}

/* ------------------------------------------------------------------ */
/* Facturas y comisiones manuales                                      */
/* ------------------------------------------------------------------ */

async function createInvoice(p: any) {
  return await tx(async () => {
    const dealId = int(p.dealId, 'Cliente / deal');
    const deal = await one<any>('SELECT * FROM deals WHERE id=?', dealId);
    if (!deal) throw new AppError('Selecciona el cliente / deal de la factura.');
    if (deal.status === 'baja') throw new AppError('Este deal está dado de baja y no admite nuevas facturas.');
    const number = str(p.number, 'Nº de factura', 60);
    const concept = (INVOICE_CONCEPTS.find((c) => c.id === p.concept)?.id || 'cuotas') as InvoiceConcept;
    const issueDate = date(p.issueDate, 'Fecha de factura');
    const dueDate = date(p.dueDate, 'Vencimiento');
    const amount = round2(num(p.amount, 'Importe'));
    if (amount === 0) throw new AppError('El importe de la factura no puede ser 0 €.');
    const method = p.method === 'giro' ? 'giro' : 'transferencia';

    const r = await exec(
      `INSERT INTO invoices (kind, deal_id, client, number, concept, description, year, issue_date, due_date, amount, method)
       VALUES ('factura',?,?,?,?,?,?,?,?,?,?)`,
      dealId, deal.client, number, concept, optStr(p.description, 300), deal.year, issueDate, dueDate, amount, method
    );
    const invoiceId = Number(r.lastInsertRowid);

    const parts = await all<any>('SELECT * FROM deal_participants WHERE deal_id=?', dealId);
    for (const dp of parts) {
      const prev = (await one<{ b: number; a: number }>(
        'SELECT COALESCE(SUM(base),0) AS b, COALESCE(SUM(amount),0) AS a FROM commission_lines WHERE deal_id=? AND user_id=?',
        dealId, dp.user_id
      ))!;
      const line = invoiceLine({
        invoiceAmount: amount,
        factor: invoiceFactor(dp.plan_id, concept),
        sharePct: dp.share_pct,
        participantBase: dp.base,
        participantCommission: dp.commission_total,
        effectiveRate: dp.effective_rate,
        alreadyBase: round2(prev.b),
        alreadyCommission: round2(prev.a),
      });
      if (line.base === 0) continue;
      await exec(
        `INSERT INTO commission_lines (kind, invoice_id, deal_id, user_id, year, client, reference, base, rate, amount)
         VALUES ('factura',?,?,?,?,?,?,?,?,?)`,
        invoiceId, dealId, dp.user_id, deal.year, deal.client, number, line.base, line.rate, line.amount
      );
    }
    if (method === 'giro' && dueDate <= today()) await setPaid(invoiceId, dueDate);
    return { id: invoiceId };
  });
}

async function createManual(p: any) {
  return await tx(async () => {
    const client = str(p.client, 'Cliente / concepto', 160);
    const ids: number[] = (Array.isArray(p.userIds) ? p.userIds : []).filter((x: any) => x !== '' && x != null).map((x: any) => int(x, 'Vendedor'));
    if (ids.length < 1 || ids.length > 2) throw new AppError('Selecciona uno o dos vendedores.');
    if (new Set(ids).size !== ids.length) throw new AppError('El segundo vendedor debe ser distinto del primero.');
    const amount = round2(num(p.amount, 'Importe'));
    if (amount === 0) throw new AppError('El importe no puede ser 0 €.');
    const ratePct = p.ratePct === undefined || p.ratePct === '' ? MANUAL_DEFAULT_RATE * 100 : num(p.ratePct, 'Porcentaje');
    if (ratePct <= 0 || ratePct > 100) throw new AppError('El porcentaje debe estar entre 0 y 100.');
    const issueDate = date(p.issueDate, 'Fecha');
    const dueDate = date(p.dueDate || p.issueDate, 'Vencimiento');
    const method = p.method === 'giro' ? 'giro' : 'transferencia';
    const year = Number(issueDate.slice(0, 4));
    const number = optStr(p.number, 60);

    const r = await exec(
      `INSERT INTO invoices (kind, deal_id, client, number, concept, description, year, issue_date, due_date, amount, method)
       VALUES ('manual',NULL,?,?,'manual',?,?,?,?,?,?)`,
      client, number, optStr(p.description, 300), year, issueDate, dueDate, amount, method
    );
    const invoiceId = Number(r.lastInsertRowid);
    for (const userId of ids) {
      const u = await one<any>("SELECT id FROM users WHERE id=? AND role='comercial' AND active=1", userId);
      if (!u) throw new AppError('El vendedor seleccionado no existe o está desactivado.');
      const base = round2(amount / ids.length);
      await exec(
        `INSERT INTO commission_lines (kind, invoice_id, deal_id, user_id, year, client, reference, base, rate, amount)
         VALUES ('manual',?,NULL,?,?,?,?,?,?,?)`,
        invoiceId, userId, year, client, number || 'Manual', base, ratePct / 100, round2(base * ratePct / 100)
      );
    }
    if (method === 'giro' && dueDate <= today()) await setPaid(invoiceId, dueDate);
    return { id: invoiceId };
  });
}

async function markPaid(p: any) {
  const id = int(p.id, 'Factura');
  const inv = await one<any>('SELECT * FROM invoices WHERE id=?', id);
  if (!inv) throw new AppError('Factura no encontrada.', 404);
  if (inv.status === 'cobrada') return { ok: true };
  const paid = p.paidDate ? date(p.paidDate, 'Fecha de cobro') : today();
  await tx(async () => await setPaid(id, paid));
  return { ok: true };
}

async function hasSettledLines(invoiceId: number) {
  return !!await one("SELECT id FROM commission_lines WHERE invoice_id=? AND status='liquidada' LIMIT 1", invoiceId);
}

async function revertPaid(p: any) {
  const id = int(p.id, 'Factura');
  const inv = await one<any>('SELECT * FROM invoices WHERE id=?', id);
  if (!inv) throw new AppError('Factura no encontrada.', 404);
  if (await hasSettledLines(id)) throw new AppError('Esta factura ya está incluida en una liquidación cerrada y no se puede deshacer el cobro.');
  await tx(async () => {
    // Un giro devuelto pasa a transferencia para que no vuelva a darse por cobrado solo.
    await exec("UPDATE invoices SET status='pendiente', paid_date=NULL, method='transferencia' WHERE id=?", id);
    await exec("UPDATE commission_lines SET status='pendiente_cobro' WHERE invoice_id=?", id);
  });
  return { ok: true };
}

async function deleteInvoice(p: any) {
  const id = int(p.id, 'Factura');
  if (await hasSettledLines(id)) throw new AppError('Esta factura ya está incluida en una liquidación cerrada y no se puede eliminar.');
  // Se borran primero sus comisiones: no se depende de que la base de datos lo haga en cascada.
  await exec('DELETE FROM commission_lines WHERE invoice_id=?', id);
  await exec('DELETE FROM invoices WHERE id=?', id);
  return { ok: true };
}

/** Facturas (y líneas manuales) con el desglose de comisión por comercial. */
export async function listInvoices(filter: { year?: number; userId?: number; kind?: string } = {}) {
  const where: string[] = [];
  const params: any[] = [];
  if (filter.year) { where.push('i.year = ?'); params.push(filter.year); }
  if (filter.kind) { where.push('i.kind = ?'); params.push(filter.kind); }
  if (filter.userId) { where.push('i.id IN (SELECT invoice_id FROM commission_lines WHERE user_id = ?)'); params.push(filter.userId); }
  const invoices = await all<any>(
    `SELECT i.* FROM invoices i ${where.length ? 'WHERE ' + where.join(' AND ') : ''}
     ORDER BY CASE i.status WHEN 'pendiente' THEN 0 ELSE 1 END, i.due_date DESC, i.id DESC`, ...params
  );
  if (!invoices.length) return [];
  const lines = await all<any>(
    `SELECT l.id, l.invoice_id, l.user_id, l.base, l.rate, l.amount, l.status, u.name AS user_name
     FROM commission_lines l JOIN users u ON u.id = l.user_id
     WHERE l.invoice_id IS NOT NULL ${filter.userId ? 'AND l.user_id = ?' : ''}`,
    ...(filter.userId ? [filter.userId] : [])
  );
  const byInvoice = new Map<number, any[]>();
  for (const l of lines) (byInvoice.get(l.invoice_id) || byInvoice.set(l.invoice_id, []).get(l.invoice_id)!).push(l);
  const t = today();
  return invoices.map((i) => ({ ...i, overdue: i.status === 'pendiente' && i.due_date < t, lines: byInvoice.get(i.id) || [] }));
}

/* ------------------------------------------------------------------ */
/* Liquidación mensual                                                 */
/* ------------------------------------------------------------------ */

const LINE_SELECT = `
  SELECT l.id, l.kind, l.user_id, l.year, l.client, l.reference, l.base, l.rate, l.amount, l.status, l.settlement_id,
         u.name AS user_name, u.email AS user_email, u.department,
         i.issue_date, i.due_date, i.paid_date, i.method, i.amount AS invoice_amount, i.description,
         s.year AS settlement_year, s.month AS settlement_month
  FROM commission_lines l
  JOIN users u ON u.id = l.user_id
  LEFT JOIN invoices i ON i.id = l.invoice_id
  LEFT JOIN settlements s ON s.id = l.settlement_id`;

/** Líneas de comisión. userId limita a un comercial. */
export async function listLines(filter: { status?: string; userId?: number; settlementId?: number; settlementYear?: number } = {}) {
  const where: string[] = [];
  const params: any[] = [];
  if (filter.status) { where.push('l.status = ?'); params.push(filter.status); }
  if (filter.userId) { where.push('l.user_id = ?'); params.push(filter.userId); }
  if (filter.settlementId) { where.push('l.settlement_id = ?'); params.push(filter.settlementId); }
  if (filter.settlementYear) { where.push('s.year = ?'); params.push(filter.settlementYear); }
  return await all<any>(
    `${LINE_SELECT} ${where.length ? 'WHERE ' + where.join(' AND ') : ''}
     ORDER BY u.name, COALESCE(i.paid_date, l.created_at), l.id`, ...params
  );
}

async function closeSettlement(me: SessionUser, p: any) {
  const ids: number[] = (Array.isArray(p.lineIds) ? p.lineIds : []).map((x: any) => int(x, 'Línea'));
  if (!ids.length) throw new AppError('Selecciona al menos una comisión para liquidar.');
  const year = int(p.year, 'Año de la nómina');
  const month = int(p.month, 'Mes de la nómina');
  if (month < 1 || month > 12) throw new AppError('El mes de la nómina no es válido.');

  return await tx(async () => {
    const marks = ids.map(() => '?').join(',');
    const lines = await all<any>(`${LINE_SELECT} WHERE l.id IN (${marks}) AND l.status = 'por_liquidar' ORDER BY l.client, l.id`, ...ids);
    if (lines.length !== ids.length) {
      throw new AppError('Alguna de las comisiones seleccionadas ya no está pendiente de liquidar. Recarga la página.');
    }
    const total = round2(lines.reduce((s, l) => s + l.amount, 0));
    const r = await exec('INSERT INTO settlements (year, month, total, closed_by) VALUES (?,?,?,?)', year, month, total, me.id);
    const settlementId = Number(r.lastInsertRowid);
    await exec(`UPDATE commission_lines SET status='liquidada', settlement_id=? WHERE id IN (${marks})`, settlementId, ...ids);

    const label = `${MONTHS[month - 1]} ${year}`;
    const byUser = new Map<number, any[]>();
    for (const l of lines) (byUser.get(l.user_id) || byUser.set(l.user_id, []).get(l.user_id)!).push(l);
    for (const [userId, ls] of byUser) {
      const sum = round2(ls.reduce((s, l) => s + l.amount, 0));
      const body = ls
        .map((l) => `${l.client} · ${l.reference || 'Sin nº'} · base ${eur(l.base)} × ${pct(l.rate)} = ${eur(l.amount)}`)
        .join('\n');
      await exec('INSERT INTO notifications (user_id, settlement_id, title, body, amount) VALUES (?,?,?,?,?)',
        userId, settlementId, `Liquidación de comisiones · nómina de ${label}`, body, sum);
    }
    return { id: settlementId, total, users: byUser.size, label };
  });
}

async function listSettlements() {
  return await all<any>(
    `SELECT s.*, u.name AS closed_by_name,
       (SELECT COUNT(*) FROM commission_lines l WHERE l.settlement_id = s.id) AS line_count,
       (SELECT COUNT(DISTINCT user_id) FROM commission_lines l WHERE l.settlement_id = s.id) AS user_count
     FROM settlements s JOIN users u ON u.id = s.closed_by ORDER BY s.id DESC`
  );
}

/* Incentivo anual del Director Comercial (Plan 4) */

async function directorArr(year: number) {
  const deals = await all<any>(
    'SELECT id, client, signed_date, sale_type, base_arr_direccion, status FROM deals WHERE year=? AND base_arr_direccion > 0 ORDER BY signed_date, id', year
  );
  const arr = round2(deals.reduce((s, d) => s + d.base_arr_direccion, 0));
  return { deals, arr, amount: round2(arr * DIRECTOR_RATE) };
}

async function incentiveStatus(year: number) {
  const directors = (await usersOf(year, "WHERE u.role='comercial' AND u.active=1 ORDER BY u.name")).filter((u) => u.plan_id === 4).map((u) => ({ id: u.id, name: u.name }));
  const { arr, amount, deals } = await directorArr(year);
  return {
    year, arr, amount, dealCount: deals.length,
    /** El ARR se toma del cierre definitivo del ejercicio: hay que cerrarlo en «Ejercicios». */
    closed: await isClosed(year),
    years: (await fiscalYears()).map((y) => y.year),
    directors: await mapSeq(directors, async (d) => ({
      ...d,
      generated: (await one<any>("SELECT id, amount, status FROM commission_lines WHERE kind='incentivo' AND user_id=? AND year=?", d.id, year)) || null,
    })),
  };
}

async function generateIncentive(p: any) {
  const userId = int(p.userId, 'Director');
  const year = int(p.year, 'Ejercicio');
  return await tx(async () => {
    const u = await userOf(year, userId);
    if (!u || !u.active || u.plan_id !== 4) throw new AppError(`El usuario no tenía el plan de Director Comercial en ${year}.`);
    if (!await isClosed(year)) throw new AppError(`El incentivo de ${year} se calcula con el cierre definitivo del ejercicio. Cierra antes el ejercicio ${year} en Ejercicios.`);
    if (await one("SELECT id FROM commission_lines WHERE kind='incentivo' AND user_id=? AND year=?", userId, year)) {
      throw new AppError(`El incentivo anual de ${year} ya está generado.`);
    }
    const { arr, amount } = await directorArr(year);
    if (arr <= 0) throw new AppError(`No hay ARR registrado en ${year}.`);
    await exec(
      `INSERT INTO commission_lines (kind, invoice_id, deal_id, user_id, year, client, reference, base, rate, amount, status)
       VALUES ('incentivo',NULL,NULL,?,?,?,?,?,?,?,'por_liquidar')`,
      userId, year, `Incentivo anual ARR ${year}`, `ARR ${year}`, arr, DIRECTOR_RATE, amount
    );
    return { amount };
  });
}

/* ------------------------------------------------------------------ */
/* Paneles                                                             */
/* ------------------------------------------------------------------ */

async function availableYears(userId?: number): Promise<number[]> {
  const rows = await all<{ y: number }>(
    userId
      ? `SELECT DISTINCT year AS y FROM commission_lines WHERE user_id = ${Number(userId)}
         UNION SELECT DISTINCT d.year FROM deals d JOIN deal_participants dp ON dp.deal_id = d.id WHERE dp.user_id = ${Number(userId)}
         UNION SELECT DISTINCT s.year FROM settlements s JOIN commission_lines l ON l.settlement_id = s.id WHERE l.user_id = ${Number(userId)}`
      : 'SELECT DISTINCT year AS y FROM deals UNION SELECT DISTINCT year FROM invoices UNION SELECT DISTINCT year FROM settlements'
  );
  const set = new Set(rows.map((r) => r.y));
  for (const y of await fiscalYears()) set.add(y.year);
  set.add(await currentYear());
  return [...set].sort((a, b) => b - a);
}

/* Objetivo anual de ARR y consecución */

/** Objetivo anual de ARR de un comercial. En el plan ARR, si no se indica otro, es su cuota Q. */
function goalOf(u: any): number | null {
  if (u.arr_target && u.arr_target > 0) return u.arr_target;
  return u.plan_id === 3 ? u.quota || DEFAULT_QUOTA : null;
}

const ratio = (achieved: number, goal: number | null) => (goal && goal > 0 ? achieved / goal : null);

/** ARR comercial que cada persona aporta en el ejercicio: su parte de cada deal firmado. */
async function arrContributions(year: number, userId?: number) {
  return await all<any>(
    `SELECT dp.user_id, d.id AS deal_id, d.client, d.signed_date, ROUND(d.base_arr * dp.share_pct / 100.0, 2) AS arr
     FROM deal_participants dp JOIN deals d ON d.id = dp.deal_id
     WHERE d.year = ? AND d.base_arr > 0 ${userId ? 'AND dp.user_id = ?' : ''}
     ORDER BY d.signed_date, d.id`, ...(userId ? [year, userId] : [year])
  );
}

/**
 * Consecución de objetivos del equipo comercial: quién aporta qué ARR y cuánto
 * lleva cada uno de su objetivo. teamGoal sustituye a la suma de objetivos individuales.
 */
async function teamAttainment(year: number, teamGoal?: number | null) {
  const rows = await arrContributions(year);
  const users = (await usersOf(year, "WHERE u.role='comercial'")).filter((u) => u.plan_id !== 4);
  const members = users
    .map((u) => {
      const deals = rows.filter((r) => r.user_id === u.id);
      const achieved = round2(deals.reduce((s, r) => s + r.arr, 0));
      const goal = goalOf(u);
      return {
        id: u.id, name: u.name, department: u.department, active: u.active,
        plan: u.plan_id ? PLANS[u.plan_id as PlanId].short : null,
        goal, achieved, pct: ratio(achieved, goal),
        deals: deals.map((r) => ({ id: r.deal_id, client: r.client, signed_date: r.signed_date, arr: r.arr })),
      };
    })
    .filter((m) => (m.active && m.goal) || m.achieved > 0)
    .sort((a, b) => b.achieved - a.achieved);
  const total = round2(members.reduce((s, m) => s + m.achieved, 0));
  const goalSum = round2(members.reduce((s, m) => s + (m.goal || 0), 0));
  const goal = teamGoal && teamGoal > 0 ? teamGoal : goalSum || null;
  return {
    year, total, goal, pct: ratio(total, goal),
    members: members.map((m) => ({ ...m, share: total > 0 ? m.achieved / total : 0 })),
  };
}

/**
 * Situación de varios comerciales en un ejercicio: acumulado, tramo y comisiones.
 * Hace las mismas pocas consultas sea cual sea el número de personas.
 */
async function standings(users: any[], year: number) {
  const by = (rows: any[]) => new Map<number, any>(rows.map((r) => [r.user_id, r]));
  const accum = await all<any>(
    `SELECT dp.user_id, dp.plan_id, SUM(dp.base) AS base, SUM(dp.commission_total) AS commission
     FROM deal_participants dp JOIN deals d ON d.id = dp.deal_id WHERE d.year = ? GROUP BY dp.user_id, dp.plan_id`, year
  );
  const sums = by(await all<any>(
    `SELECT l.user_id,
       COALESCE(SUM(CASE WHEN l.status='pendiente_cobro' THEN l.amount END),0) AS pending_collection,
       COALESCE(SUM(CASE WHEN l.status='por_liquidar' THEN l.amount END),0) AS to_settle
     FROM commission_lines l GROUP BY l.user_id`
  ));
  const settled = by(await all<any>(
    `SELECT l.user_id, COALESCE(SUM(l.amount),0) AS s FROM commission_lines l JOIN settlements s ON s.id = l.settlement_id
     WHERE s.year = ? GROUP BY l.user_id`, year
  ));
  const arr = by(await all<any>(
    `SELECT dp.user_id, SUM(ROUND(d.base_arr * dp.share_pct / 100.0, 2)) AS arr
     FROM deal_participants dp JOIN deals d ON d.id = dp.deal_id WHERE d.year = ? AND d.base_arr > 0 GROUP BY dp.user_id`, year
  ));
  const director = users.some((u) => u.plan_id === 4) ? (await directorArr(year)).arr : 0;

  return users.map((u) => {
    const plan = u.plan_id ? PLANS[u.plan_id as PlanId] : null;
    if (!plan) return null;
    const tiers = tiersFor(plan.id, u.quota);
    const mine = accum.filter((r) => r.user_id === u.id);
    const accumulatedBase = plan.perInvoice ? round2(mine.find((r) => r.plan_id === plan.id)?.base || 0) : director;
    const earned = plan.perInvoice ? mine.reduce((t, r) => t + r.commission, 0) : accumulatedBase * DIRECTOR_RATE;
    const arrAchieved = plan.perInvoice ? round2(arr.get(u.id)?.arr || 0) : null;
    const goal = plan.perInvoice ? goalOf(u) : null;
    return {
      /** Objetivo anual de ARR y consecución (null si no tiene objetivo). */
      target: goal && arrAchieved !== null ? { goal, achieved: arrAchieved, pct: ratio(arrAchieved, goal), remaining: round2(Math.max(0, goal - arrAchieved)) } : null,
      plan: { id: plan.id, name: plan.name, short: plan.short, measure: plan.measure, perInvoice: plan.perInvoice, description: plan.description },
      tiers, quota: plan.id === 3 ? u.quota || DEFAULT_QUOTA : null,
      accumulated: accumulatedBase,
      progress: progress(tiers, accumulatedBase),
      /** Comisión total que generan los deals del año cuando se facture y cobre todo. */
      earned: round2(earned),
      pendingCollection: round2(sums.get(u.id)?.pending_collection || 0),
      toSettle: round2(sums.get(u.id)?.to_settle || 0),
      settledInYear: round2(settled.get(u.id)?.s || 0),
    };
  });
}
const standing = async (u: any, year: number) => (await standings([u], year))[0];

/** Resumen de cada ejercicio para la pantalla «Ejercicios». */
async function listYears() {
  const cal = calendarYear();
  return {
    calendarYear: cal, currentYear: await currentYear(),
    years: await mapSeq(await fiscalYears(), async (fy) => {
      const t = await teamAttainment(fy.year);
      const k = (await one<any>(
        `SELECT
          (SELECT COUNT(*) FROM deals WHERE year = ?) AS deals,
          (SELECT COALESCE(SUM(total_amount),0) FROM deals WHERE year = ?) AS deal_amount,
          (SELECT COALESCE(SUM(total),0) FROM settlements WHERE year = ?) AS settled,
          (SELECT COALESCE(SUM(amount),0) FROM commission_lines WHERE year = ? AND status = 'pendiente_cobro') AS pending_collection,
          (SELECT COALESCE(SUM(amount),0) FROM commission_lines WHERE year = ? AND status = 'por_liquidar') AS to_settle,
          (SELECT COALESCE(SUM(dp.base - (SELECT COALESCE(SUM(l.base),0) FROM commission_lines l WHERE l.deal_id = dp.deal_id AND l.user_id = dp.user_id)),0)
             FROM deal_participants dp JOIN deals d ON d.id = dp.deal_id WHERE d.year = ? AND d.status = 'activo') AS base_to_invoice`,
        fy.year, fy.year, fy.year, fy.year, fy.year, fy.year
      ))!;
      return {
        ...fy, ...k, arr: t.total, goal: t.goal, pct: t.pct, people: t.members.length,
        incentivePending: fy.status === 'cerrado' && (await incentiveStatus(fy.year)).directors.some((d: any) => !d.generated) && (await directorArr(fy.year)).arr > 0,
      };
    }),
  };
}

async function adminDashboard(p: any) {
  const year = p.year ? int(p.year, 'Ejercicio') : await currentYear();
  const k = await one<any>(
    `SELECT
      (SELECT COALESCE(SUM(amount),0) FROM invoices WHERE status='pendiente') AS pending_collection,
      (SELECT COUNT(*) FROM invoices WHERE status='pendiente') AS pending_count,
      (SELECT COUNT(*) FROM invoices WHERE status='pendiente' AND due_date < ?) AS overdue_count,
      (SELECT COALESCE(SUM(amount),0) FROM commission_lines WHERE status='por_liquidar') AS to_settle,
      (SELECT COUNT(*) FROM commission_lines WHERE status='por_liquidar') AS to_settle_count,
      (SELECT COALESCE(SUM(total),0) FROM settlements WHERE year = ?) AS settled_year,
      (SELECT COUNT(*) FROM threads WHERE status='pendiente') AS open_threads,
      (SELECT COUNT(*) FROM deals WHERE year = ?) AS deal_count,
      (SELECT COALESCE(SUM(total_amount),0) FROM deals WHERE year = ?) AS deal_amount,
      (SELECT COUNT(*) FROM deals) AS deals_total`, today(), year, year, year
  );
  const users = await usersOf(year, "WHERE u.role='comercial' AND u.active=1 ORDER BY u.name");
  const cal = calendarYear();
  const byMonth = await all<any>('SELECT month, SUM(total) AS total FROM settlements WHERE year=? GROUP BY month', year);
  return {
    year, years: await availableYears(), today: today(), kpis: k,
    fiscal: {
      status: (await fiscalYear(year))?.status || null,
      calendarYear: cal,
      /** false = el año natural aún no existe como ejercicio: toca cerrar el anterior y abrir el nuevo. */
      calendarOpen: !!await fiscalYear(cal),
      openBefore: (await fiscalYears()).filter((y) => y.status === 'abierto' && y.year < cal).map((y) => y.year),
    },
    demoAllowed: demoAllowed(),
    setup: { users: (await one<any>("SELECT COUNT(*) AS n FROM users WHERE role='comercial' AND active=1"))!.n, deals: k.deals_total, invoices: (await one<any>('SELECT COUNT(*) AS n FROM invoices'))!.n },
    team: (await standings(users, year)).map((st, i) => ({ id: users[i].id, name: users[i].name, department: users[i].department, ...st })),
    attainment: await teamAttainment(year),
    months: MONTHS.map((m, i) => ({ label: m.slice(0, 3), total: round2(byMonth.find((b) => b.month === i + 1)?.total || 0) })),
    overdue: await all<any>("SELECT id, client, number, amount, due_date, method FROM invoices WHERE status='pendiente' AND due_date < ? ORDER BY due_date LIMIT 8", today()),
  };
}

async function portalHome(me: SessionUser, p: any) {
  const year = p.year ? int(p.year, 'Ejercicio') : await currentYear();
  const u = await userOf(year, me.id);
  const s = await standing(u, year);
  const isDirector = s?.plan.id === 4;
  return {
    year, years: await availableYears(me.id), today: today(), standing: s,
    nextPayroll: await listLines({ status: 'por_liquidar', userId: me.id }),
    notifications: await all<any>('SELECT * FROM notifications WHERE user_id=? ORDER BY id DESC LIMIT 12', me.id),
    fiscalStatus: (await fiscalYear(year))?.status || null,
    director: isDirector ? { ...(await directorArr(year)), closed: await isClosed(year) } : null,
    // El director ve la consecución de todo su equipo; el resto, solo la suya.
    team: isDirector ? await teamAttainment(year, u.arr_target) : null,
  };
}

async function portalDeals(me: SessionUser, p: any) {
  const year = p.year ? int(p.year, 'Ejercicio') : await currentYear();
  const deals = (await listDeals({ year, userId: me.id })).map((d) => ({
    ...d,
    // El comercial solo ve su propia parte del deal.
    participants: d.participants.filter((x: any) => x.user_id === me.id),
    sharedWith: d.participants.filter((x: any) => x.user_id !== me.id).map((x: any) => x.user_name),
  }));
  const invoices = (await listInvoices({ userId: me.id })).filter((i) => i.year === year);
  return { year, years: await availableYears(me.id), deals, invoices };
}

async function portalHistory(me: SessionUser, p: any) {
  const year = p.year ? int(p.year, 'Ejercicio') : await currentYear();
  return { year, years: await availableYears(me.id), lines: await listLines({ status: 'liquidada', userId: me.id, settlementYear: year }) };
}

/* ------------------------------------------------------------------ */
/* Buzón de consultas                                                  */
/* ------------------------------------------------------------------ */

async function listThreads(me: SessionUser) {
  const mine = me.role === 'finanzas' ? '' : 'WHERE t.user_id = ?';
  return await all<any>(
    `SELECT t.*, u.name AS user_name,
       (SELECT body FROM thread_messages m WHERE m.thread_id = t.id ORDER BY m.id DESC LIMIT 1) AS last_body
     FROM threads t JOIN users u ON u.id = t.user_id ${mine}
     ORDER BY CASE t.status WHEN 'pendiente' THEN 0 ELSE 1 END, t.updated_at DESC`,
    ...(me.role === 'finanzas' ? [] : [me.id])
  );
}

async function getThread(me: SessionUser, p: any) {
  const id = int(p.id, 'Consulta');
  const t = await one<any>('SELECT t.*, u.name AS user_name FROM threads t JOIN users u ON u.id = t.user_id WHERE t.id=?', id);
  if (!t || (me.role !== 'finanzas' && t.user_id !== me.id)) throw new AppError('Consulta no encontrada.', 404);
  const messages = await all<any>(
    'SELECT m.*, u.name AS author_name, u.role AS author_role FROM thread_messages m JOIN users u ON u.id = m.author_id WHERE m.thread_id=? ORDER BY m.id', id
  );
  return { ...t, messages };
}

async function createThread(me: SessionUser, p: any) {
  if (me.role !== 'comercial') throw new AppError('Las consultas las abre el comercial o consultor.');
  const subject = str(p.subject, 'Asunto', 160);
  const body = str(p.body, 'Mensaje', 4000);
  return await tx(async () => {
    const r = await exec('INSERT INTO threads (user_id, subject) VALUES (?,?)', me.id, subject);
    const id = Number(r.lastInsertRowid);
    await exec('INSERT INTO thread_messages (thread_id, author_id, body) VALUES (?,?,?)', id, me.id, body);
    return { id };
  });
}

async function replyThread(me: SessionUser, p: any) {
  const t = await getThread(me, p);
  const body = str(p.body, 'Mensaje', 4000);
  await tx(async () => {
    await exec('INSERT INTO thread_messages (thread_id, author_id, body) VALUES (?,?,?)', t.id, me.id, body);
    await exec("UPDATE threads SET status=?, updated_at=datetime('now') WHERE id=?", me.role === 'finanzas' ? 'respondida' : 'pendiente', t.id);
  });
  return { ok: true };
}

/* ------------------------------------------------------------------ */
/* Datos de ejemplo                                                    */
/* ------------------------------------------------------------------ */

/** Los datos de ejemplo solo existen si se arranca el portal con DEMO_DATA=1 (formación o pruebas). */
const demoAllowed = () => process.env.DEMO_DATA === '1';

/** Carga un juego de datos ficticio para enseñar el portal. Solo con la base vacía. */
async function loadDemo(me: SessionUser) {
  if (!demoAllowed()) throw new AppError('Los datos de ejemplo no están habilitados en esta instalación.', 403);
  if (await one('SELECT id FROM deals LIMIT 1')) throw new AppError('Los datos de ejemplo solo se pueden cargar con el portal vacío.');
  // El ejemplo se fecha en el último ejercicio con noviembre ya iniciado, para que
  // haya facturas cobradas, liquidadas y pendientes sea cual sea el día en que se cargue.
  const y = Number(today().slice(5, 7)) >= 11 ? calendarYear() : calendarYear() - 1;
  const d = (month: number, day: number, year = y) => `${year}-${String(month).padStart(2, '0')}-${String(day).padStart(2, '0')}`;
  const hash = hashPassword(temporaryPassword());
  const mk = async (email: string, name: string, department: string, plan: number, quota: number | null, target: number | null = null) => {
    const ex = await one<any>('SELECT id FROM users WHERE email=?', email);
    if (ex) return ex.id as number;
    return Number((await exec(
      "INSERT INTO users (email, name, password_hash, role, department, plan_id, quota, arr_target, must_change_password) VALUES (?,?,?,'comercial',?,?,?,?,1)",
      email, name, hash, department, plan, quota, target)).lastInsertRowid);
  };
  const tiered = (await one<any>("SELECT id FROM users WHERE role='comercial' AND plan_id=2 AND active=1 ORDER BY id"))?.id
    ?? await mk('demo.escalado@slimstock.com', 'Demo Escalado', 'COMERCIAL', 2, null, 360000);
  await exec('UPDATE users SET arr_target = COALESCE(arr_target, 360000) WHERE id = ?', tiered);
  const arrUser = await mk('demo.arr@slimstock.com', 'Demo ARR', 'COMERCIAL', 3, 360000, 360000);
  const junior = await mk('demo.junior@slimstock.com', 'Demo Junior', 'COMERCIAL', 3, 360000, 240000);
  const fixed = await mk('demo.consultor@slimstock.com', 'Demo Consultor', 'CONSULTORIA', 1, null);
  const demoYears = async () => { for (const yy of [y - 1, y]) { await exec('INSERT OR IGNORE INTO fiscal_years (year) VALUES (?)', yy); await exec('DELETE FROM user_years WHERE year = ?', yy); await materializeUserYears(yy); } };
  await mk('demo.director@slimstock.com', 'Demo Director', 'COMERCIAL', 4, null);

  await demoYears();
  const deal = async (client: string, signed: string, components: Partial<DealComponents>, participants: number[], saleType = 'pago_uso') =>
    (await createDeal({ client, signedDate: signed, saleType, components: { ...EMPTY_COMPONENTS, ...components }, participants: participants.map((userId) => ({ userId })) })).id;
  const inv = async (dealId: number, number: string, concept: string, amount: number, issue: string, due: string, method: string, paid?: string) => {
    const id = (await createInvoice({ dealId, number, concept, amount, issueDate: issue, dueDate: due, method })).id;
    if (paid && method === 'transferencia') await markPaid({ id, paidDate: paid });
    return id;
  };

  // Ejercicio anterior: da contenido al histórico y al incentivo anual del director.
  const p1 = await deal('Ejemplo Ferretera del Norte', d(3, 12, y - 1), { cuotaLicencias: 2400, cuotaUsuarios: 300, implantacion: 28000 }, [tiered, arrUser]);
  const p2 = await deal('Ejemplo Farma Levante', d(9, 20, y - 1), { licenciasCompra: 90000, implantacion: 40000, cuotaUsuarios: 400 }, [tiered], 'compra');
  await inv(p1, `A/${y - 1}0112`, 'implantacion', 28000, d(4, 1, y - 1), d(4, 30, y - 1), 'transferencia', d(5, 6, y - 1));
  await inv(p1, `A/${y - 1}0240`, 'cuotas', 16200, d(7, 1, y - 1), d(7, 25, y - 1), 'giro');
  await inv(p2, `A/${y - 1}0398`, 'licencias', 90000, d(10, 1, y - 1), d(10, 30, y - 1), 'transferencia', d(11, 4, y - 1));
  await closeSettlement(me, { lineIds: (await listLines({ status: 'por_liquidar' })).map((l) => l.id), year: y - 1, month: 11 });

  // Ejercicio en curso.
  const a = await deal('Ejemplo Distribuciones Atlas', d(1, 22), { cuotaLicencias: 4200, cuotaUsuarios: 500, cuotaHosting: 600, implantacion: 45000 }, [tiered]);
  const b = await deal('Ejemplo Grupo Moda Sur', d(3, 9), { cuotaLicencias: 3800, cuotaUsuarios: 400, implantacion: 38000, partnerFeePct: 10 }, [tiered, arrUser]);
  const c = await deal('Ejemplo Recambios Ebro', d(5, 14), { cuotaLicencias: 6500, cuotaUsuarios: 700, implantacion: 52000 }, [arrUser]);
  const e = await deal('Ejemplo Bodegas Duero', d(6, 30), { licenciasCompra: 120000, implantacion: 48000, cuotaUsuarios: 600 }, [tiered], 'compra');
  await deal('Ejemplo Logística Pirineo', d(8, 18), { cuotaLicencias: 5200, cuotaUsuarios: 600, implantacion: 36000 }, [junior]);
  const f = await deal('Ejemplo Alimentación Cantábrica', d(9, 3), { cuotaLicencias: 7200, cuotaUsuarios: 800, cuotaHosting: 900, implantacion: 60000 }, [tiered, arrUser, fixed]);

  await inv(a, `A/${y}0031`, 'implantacion', 45000, d(2, 1), d(2, 28), 'transferencia', d(3, 4));
  await inv(a, `A/${y}0077`, 'cuotas', 14100, d(4, 1), d(4, 25), 'giro');
  await inv(a, `A/${y}0190`, 'cuotas', 14100, d(7, 1), d(7, 25), 'giro');
  await inv(b, `A/${y}0102`, 'implantacion', 38000, d(4, 10), d(5, 10), 'transferencia', d(5, 19));
  await inv(b, `A/${y}0166`, 'cuotas', 12600, d(6, 1), d(6, 25), 'giro');
  await inv(c, `A/${y}0180`, 'implantacion', 52000, d(6, 2), d(7, 2), 'transferencia', d(7, 15));
  await inv(c, `A/${y}0233`, 'cuotas', 21600, d(8, 1), d(8, 25), 'giro');
  await inv(e, `A/${y}0251`, 'licencias', 120000, d(7, 15), d(8, 15), 'transferencia', d(9, 2));
  await closeSettlement(me, { lineIds: (await listLines({ status: 'por_liquidar' })).map((l) => l.id), year: y, month: 9 });

  // Cobradas y pendientes de liquidar en la próxima nómina.
  await inv(a, `A/${y}0305`, 'cuotas', 14100, d(10, 1), d(10, 25), 'giro');
  await inv(c, `A/${y}0318`, 'cuotas', 21600, d(10, 1), d(10, 25), 'giro');
  await inv(e, `A/${y}0322`, 'implantacion', 24000, d(10, 5), d(11, 5), 'transferencia', today());
  await inv(f, `A/${y}0330`, 'implantacion', 30000, d(10, 10), d(11, 10), 'transferencia', today());
  // Pendientes de cobro.
  await inv(f, `A/${y}0351`, 'cuotas', 24000, d(11, 1), d(12, 1), 'transferencia');
  await inv(b, `A/${y}0356`, 'cuotas', 12600, d(11, 3), d(11, 12), 'transferencia');
  await inv(e, `A/${y}0360`, 'implantacion', 24000, d(11, 10), d(12, 10), 'transferencia');
  await inv(a, `A/${y}0371`, 'cuotas', 14100, d(12, 1), d(12, 25), 'giro');

  await createManual({ userIds: [fixed], client: 'Ejemplo Taller Auditoría de stock', description: 'Presupuesto de consultoría', amount: 6800, issueDate: d(10, 20), dueDate: d(11, 20), method: 'transferencia', number: `A/${y}0340` });

  const t = Number((await exec('INSERT INTO threads (user_id, subject) VALUES (?,?)', tiered, 'Duda sobre el tramo de Bodegas Duero')).lastInsertRowid);
  await exec('INSERT INTO thread_messages (thread_id, author_id, body) VALUES (?,?,?)', t, tiered,
    'Hola, veo que el deal de Bodegas Duero tiene un % mixto. ¿Me confirmáis cómo se ha repartido entre tramos? Gracias.');
  await autoCollectGiros();
  return { ok: true };
}

/* ------------------------------------------------------------------ */
/* Enrutado de acciones                                                */
/* ------------------------------------------------------------------ */

type Handler = (me: SessionUser, p: any) => Promise<any>;
const F = 'finanzas' as const;
const C = 'comercial' as const;

const ACTIONS: Record<string, { roles: readonly string[]; fn: Handler }> = {
  // Finanzas
  'admin.dashboard': { roles: [F], fn: async (_, p) => await adminDashboard(p) },
  'admin.options': {
    roles: [F],
    fn: async (_, p) => ({
      today: today(), years: await availableYears(), concepts: INVOICE_CONCEPTS,
      defaultYear: await currentYear(), fiscalYears: await fiscalYears(),
      plans: Object.values(PLANS).map((pl) => ({ ...pl, tiers: tiersFor(pl.id, DEFAULT_QUOTA) })),
      users: await usersOf(p.year ? int(p.year, 'Ejercicio') : await currentYear(), "WHERE u.role='comercial' ORDER BY u.name"),
      deals: await all("SELECT id, client, year, status FROM deals ORDER BY year DESC, client"),
    }),
  },
  'users.list': { roles: [F], fn: async (_, p) => await listUsers(p) },
  'years.list': { roles: [F], fn: async () => await listYears() },
  'years.open': { roles: [F], fn: async (_, p) => await openYear(p) },
  'years.close': { roles: [F], fn: async (me, p) => await closeYear(me, p) },
  'years.reopen': { roles: [F], fn: async (_, p) => await reopenYear(p) },
  'users.save': { roles: [F], fn: async (me, p) => await saveUser(me, p) },
  'users.resetPassword': { roles: [F], fn: async (_, p) => await resetPassword(p) },
  'deals.list': { roles: [F], fn: async (_, p) => await listDeals({ year: p.year ? int(p.year, 'Ejercicio') : undefined }) },
  'deals.preview': { roles: [F], fn: async (_, p) => await buildDeal(p) },
  'deals.create': { roles: [F], fn: async (_, p) => await createDeal(p) },
  'deals.update': { roles: [F], fn: async (_, p) => await updateDeal(p) },
  'deals.delete': { roles: [F], fn: async (_, p) => await deleteDeal(p) },
  'invoices.list': { roles: [F], fn: async (_, p) => await listInvoices({ year: p.year ? int(p.year, 'Ejercicio') : undefined, kind: p.kind }) },
  'invoices.create': { roles: [F], fn: async (_, p) => await createInvoice(p) },
  'invoices.markPaid': { roles: [F], fn: async (_, p) => await markPaid(p) },
  'invoices.revertPaid': { roles: [F], fn: async (_, p) => await revertPaid(p) },
  'invoices.delete': { roles: [F], fn: async (_, p) => await deleteInvoice(p) },
  'manual.create': { roles: [F], fn: async (_, p) => await createManual(p) },
  'settle.pending': {
    roles: [F],
    fn: async (_, p) => ({
      today: today(), lines: await listLines({ status: 'por_liquidar' }), settlements: await listSettlements(),
      incentive: await incentiveStatus(p.incentiveYear ? int(p.incentiveYear, 'Ejercicio') : ((await fiscalYears()).find((y) => y.status === 'cerrado')?.year ?? (await currentYear()) - 1)),
    }),
  },
  'settle.close': { roles: [F], fn: async (me, p) => await closeSettlement(me, p) },
  'settle.lines': { roles: [F], fn: async (_, p) => await listLines({ settlementId: int(p.id, 'Liquidación') }) },
  'incentive.generate': { roles: [F], fn: async (_, p) => await generateIncentive(p) },
  'demo.load': { roles: [F], fn: async (me) => await tx(async () => await loadDemo(me)) },
  // Portal del comercial
  'portal.home': { roles: [C], fn: async (me, p) => await portalHome(me, p) },
  'portal.deals': { roles: [C], fn: async (me, p) => await portalDeals(me, p) },
  'portal.history': { roles: [C], fn: async (me, p) => await portalHistory(me, p) },
  'notifications.read': { roles: [C], fn: async (me) => { await exec("UPDATE notifications SET read_at=datetime('now') WHERE user_id=? AND read_at IS NULL", me.id); return { ok: true }; } },
  'threads.create': { roles: [C], fn: async (me, p) => await createThread(me, p) },
  // Ambos roles
  'threads.list': { roles: [F, C], fn: async (me) => await listThreads(me) },
  'threads.get': { roles: [F, C], fn: async (me, p) => await getThread(me, p) },
  'threads.reply': { roles: [F, C], fn: async (me, p) => await replyThread(me, p) },
  'profile.changePassword': { roles: [F, C], fn: async (me, p) => await changePassword(me, p) },
};

/* Registro de actividad: quién cambió qué y cuándo. Nunca guarda contraseñas. */
const READ_ONLY = /\.(list|get|dashboard|options|pending|home|deals|history|preview|lines|read)$/;
async function audit(me: SessionUser, action: string, payload: any) {
  let detail = '';
  try {
    const p = { ...(payload || {}) };
    for (const k of ['current', 'next', 'password']) delete p[k];
    detail = JSON.stringify(p).slice(0, 1500);
  } catch { /* sin detalle */ }
  await exec('INSERT INTO audit_log (user_id, user_name, action, detail) VALUES (?,?,?,?)', me.id, me.name, action, detail);
}

export async function listAudit(limit = 5000) {
  return await all<any>('SELECT id, at, user_name, action, detail FROM audit_log ORDER BY id DESC LIMIT ?', limit);
}

export async function run(me: SessionUser, action: string, payload: any) {
  const a = ACTIONS[action];
  if (!a) throw new AppError('Acción desconocida.', 404);
  if (!a.roles.includes(me.role)) throw new AppError('No tienes permiso para esta acción.', 403);
  if (me.must_change_password && action !== 'profile.changePassword') {
    throw new AppError('Debes cambiar tu contraseña antes de continuar.', 403);
  }
  await ensureFiscalYears();
  await autoCollectGiros();
  if (READ_ONLY.test(action)) return a.fn(me, payload || {});
  // Todo cambio va en una transacción: o se guarda entero, con su apunte en el registro, o no se guarda nada.
  return tx(async () => {
    const result = await a.fn(me, payload || {});
    await audit(me, action, payload);
    return result;
  });
}
