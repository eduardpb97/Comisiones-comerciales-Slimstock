import { AppError } from './auth';

/**
 * Rechaza peticiones que no vengan del propio portal: exige JSON y, si el navegador
 * indica el origen, que coincida con la dirección por la que se está sirviendo.
 * Evita que otra web abierta en el mismo navegador actúe en nombre del usuario (CSRF).
 */
export function assertSameOrigin(req: Request) {
  const type = req.headers.get('content-type') || '';
  if (!type.toLowerCase().startsWith('application/json')) throw new AppError('Petición no válida.', 415);
  const origin = req.headers.get('origin');
  if (!origin) return;
  const host = (req.headers.get('x-forwarded-host') || req.headers.get('host') || '').toLowerCase();
  let originHost = '';
  try { originHost = new URL(origin).host.toLowerCase(); } catch { /* origen ilegible */ }
  if (!originHost || originHost !== host) throw new AppError('Petición rechazada: origen no permitido.', 403);
}
