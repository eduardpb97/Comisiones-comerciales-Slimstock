import ExcelJS from 'exceljs';
import { MONTHS, listAudit, listDeals, listInvoices, listLines } from './actions';
import { dbGet } from './db';
import { AppError } from './auth';
import { INVOICE_CONCEPTS } from './commission';

const NAVY = 'FF002D4D';
const EUR = '#,##0.00 "€"';
const PCT = '0.00%';

type Col = { header: string; key: string; width: number; fmt?: string };

const STATUS: Record<string, string> = {
  pendiente_cobro: 'Pendiente de cobro', por_liquidar: 'Cobrada, por liquidar', liquidada: 'Liquidada',
  pendiente: 'Pendiente de cobro', cobrada: 'Cobrada',
};
const METHOD: Record<string, string> = { giro: 'Giro bancario', transferencia: 'Transferencia' };
const KIND: Record<string, string> = { factura: 'Comisión', manual: 'Comisión manual', incentivo: 'Incentivo anual' };

const asDate = (iso?: string | null) => (iso ? new Date(`${iso.slice(0, 10)}T00:00:00Z`) : null);

function sheet(wb: ExcelJS.Workbook, name: string, title: string, cols: Col[], rows: any[], totals: string[] = []) {
  const ws = wb.addWorksheet(name, { views: [{ state: 'frozen', ySplit: 3 }] });
  ws.columns = cols.map((c) => ({ key: c.key, width: c.width }));
  ws.getCell('A1').value = title;
  ws.getCell('A1').font = { bold: true, size: 14, color: { argb: NAVY } };
  const head = ws.getRow(3);
  cols.forEach((c, i) => {
    const cell = head.getCell(i + 1);
    cell.value = c.header;
    cell.font = { bold: true, color: { argb: 'FFFFFFFF' } };
    cell.fill = { type: 'pattern', pattern: 'solid', fgColor: { argb: NAVY } };
    cell.alignment = { vertical: 'middle', wrapText: true };
  });
  head.height = 22;
  for (const r of rows) {
    const row = ws.addRow(cols.map((c) => r[c.key] ?? null));
    cols.forEach((c, i) => {
      const cell = row.getCell(i + 1);
      if (c.fmt) cell.numFmt = c.fmt;
      if (cell.value instanceof Date) cell.numFmt = 'dd/mm/yyyy';
    });
  }
  if (rows.length && totals.length) {
    const first = 4;
    const last = 3 + rows.length;
    const row = ws.addRow([]);
    row.getCell(1).value = 'TOTAL';
    cols.forEach((c, i) => {
      if (!totals.includes(c.key)) return;
      const letter = ws.getColumn(i + 1).letter;
      const cell = row.getCell(i + 1);
      // Fórmula real para que la gestoría pueda auditar el total; se incluye el valor ya calculado.
      cell.value = { formula: `SUM(${letter}${first}:${letter}${last})`, result: Math.round(rows.reduce((s, r) => s + (Number(r[c.key]) || 0), 0) * 100) / 100 };
      cell.numFmt = c.fmt || EUR;
    });
    row.font = { bold: true };
    row.eachCell((cell) => { cell.border = { top: { style: 'thin', color: { argb: NAVY } } }; });
  }
  if (rows.length) ws.autoFilter = { from: { row: 3, column: 1 }, to: { row: 3, column: cols.length } };
  return ws;
}

const lineRow = (l: any) => ({
  department: l.department, user: l.user_name, email: l.user_email, kind: KIND[l.kind] || l.kind, client: l.client, reference: l.reference,
  year: l.year, due: asDate(l.due_date), paid: asDate(l.paid_date), method: METHOD[l.method] || '',
  invoice_amount: l.invoice_amount, base: l.base, rate: l.rate, amount: l.amount, status: STATUS[l.status],
  payroll: l.settlement_month ? `${MONTHS[l.settlement_month - 1]} ${l.settlement_year}` : '',
});

const LINE_COLS: Col[] = [
  { header: 'Departamento', key: 'department', width: 15 },
  { header: 'Trabajador', key: 'user', width: 24 },
  { header: 'Tipo', key: 'kind', width: 17 },
  { header: 'Cliente', key: 'client', width: 34 },
  { header: 'Factura', key: 'reference', width: 16 },
  { header: 'Ejercicio', key: 'year', width: 10 },
  { header: 'Vencimiento', key: 'due', width: 13 },
  { header: 'Fecha de cobro', key: 'paid', width: 14 },
  { header: 'Método de pago', key: 'method', width: 16 },
  { header: 'Importe factura', key: 'invoice_amount', width: 16, fmt: EUR },
  { header: 'Base comisión', key: 'base', width: 16, fmt: EUR },
  { header: '% Comisión', key: 'rate', width: 12, fmt: PCT },
  { header: 'Importe a liquidar', key: 'amount', width: 18, fmt: EUR },
];

async function toBuffer(wb: ExcelJS.Workbook): Promise<Buffer> {
  wb.creator = 'Portal de comisiones Slimstock';
  wb.created = new Date();
  return Buffer.from(await wb.xlsx.writeBuffer());
}

/** Excel para la gestoría laboral: resumen por trabajador + detalle por factura. */
export async function settlementWorkbook(id: number) {
  const s = await dbGet<any>('SELECT * FROM settlements WHERE id=?', [id]);
  if (!s) throw new AppError('Liquidación no encontrada.', 404);
  const lines = await listLines({ settlementId: id });
  const label = `${MONTHS[s.month - 1]} ${s.year}`;
  const wb = new ExcelJS.Workbook();

  const byUser = new Map<string, any>();
  for (const l of lines) {
    const u = byUser.get(l.user_email) || { department: l.department, user: l.user_name, email: l.user_email, count: 0, amount: 0 };
    u.count += 1;
    u.amount = Math.round((u.amount + l.amount) * 100) / 100;
    byUser.set(l.user_email, u);
  }
  sheet(wb, 'Resumen nómina', `Comisiones e incentivos a incluir en la nómina de ${label}`, [
    { header: 'Departamento', key: 'department', width: 16 },
    { header: 'Trabajador', key: 'user', width: 28 },
    { header: 'Correo', key: 'email', width: 32 },
    { header: 'Nº de líneas', key: 'count', width: 13 },
    { header: 'Importe bruto a liquidar', key: 'amount', width: 24, fmt: EUR },
  ], [...byUser.values()], ['amount']);

  sheet(wb, 'Detalle', `Detalle de la liquidación · nómina de ${label}`, LINE_COLS, lines.map(lineRow), ['amount']);
  return { buffer: await toBuffer(wb), filename: `Liquidacion_comisiones_${s.year}-${String(s.month).padStart(2, '0')}_${id}.xlsx` };
}

export async function dealsWorkbook(year?: number) {
  const rows: any[] = [];
  for (const d of await listDeals({ year })) {
    for (const p of d.participants) {
      rows.push({
        year: d.year, signed: asDate(d.signed_date), client: d.client,
        type: d.sale_type === 'compra' ? 'Compra de licencias' : 'Pago por uso', status: d.status === 'baja' ? 'Baja' : 'Activo',
        total: d.total_amount, arr: d.base_arr, arr_dir: d.base_arr_direccion,
        user: p.user_name, plan: p.plan_name, share: p.share_pct / 100, base: p.base, accum: p.accum_before,
        tiers: p.slices.map((s: any) => `${s.label}: ${s.amount.toFixed(2)} €`).join(' | '),
        rate: p.effective_rate, commission: p.commission_total, invoiced: p.invoiced_base,
        pending_base: Math.round((p.base - p.invoiced_base) * 100) / 100, settled: p.settled,
      });
    }
  }
  const wb = new ExcelJS.Workbook();
  sheet(wb, 'Deals', `Deals${year ? ` · ejercicio ${year}` : ''}`, [
    { header: 'Ejercicio', key: 'year', width: 10 },
    { header: 'Fecha firma', key: 'signed', width: 13 },
    { header: 'Cliente', key: 'client', width: 34 },
    { header: 'Tipo de venta', key: 'type', width: 18 },
    { header: 'Estado', key: 'status', width: 10 },
    { header: 'Importe deal', key: 'total', width: 16, fmt: EUR },
    { header: 'ARR comercial', key: 'arr', width: 16, fmt: EUR },
    { header: 'ARR dirección', key: 'arr_dir', width: 16, fmt: EUR },
    { header: 'Comercial', key: 'user', width: 24 },
    { header: 'Plan', key: 'plan', width: 20 },
    { header: 'Reparto', key: 'share', width: 10, fmt: PCT },
    { header: 'Base comercial', key: 'base', width: 16, fmt: EUR },
    { header: 'Acumulado previo', key: 'accum', width: 17, fmt: EUR },
    { header: 'Reparto por tramos', key: 'tiers', width: 48 },
    { header: '% efectivo', key: 'rate', width: 11, fmt: PCT },
    { header: 'Comisión total', key: 'commission', width: 16, fmt: EUR },
    { header: 'Base facturada', key: 'invoiced', width: 16, fmt: EUR },
    { header: 'Base pendiente de facturar', key: 'pending_base', width: 18, fmt: EUR },
    { header: 'Comisión liquidada', key: 'settled', width: 17, fmt: EUR },
  ], rows, ['base', 'commission', 'invoiced', 'pending_base', 'settled']);
  return { buffer: await toBuffer(wb), filename: `Deals${year ? `_${year}` : ''}.xlsx` };
}

export async function invoicesWorkbook(year?: number) {
  const concept = (id: string) => INVOICE_CONCEPTS.find((c) => c.id === id)?.label || 'Comisión manual';
  const rows = (await listInvoices({ year })).map((i) => ({
    year: i.year, client: i.client, number: i.number, kind: i.kind === 'manual' ? 'Manual' : 'Factura de deal', concept: concept(i.concept),
    issue: asDate(i.issue_date), due: asDate(i.due_date), method: METHOD[i.method], amount: i.amount,
    status: STATUS[i.status], paid: asDate(i.paid_date),
    commission: Math.round(i.lines.reduce((s: number, l: any) => s + l.amount, 0) * 100) / 100,
    users: i.lines.map((l: any) => l.user_name).join(', '),
  }));
  const wb = new ExcelJS.Workbook();
  sheet(wb, 'Facturas', `Facturas y cobros${year ? ` · ejercicio ${year}` : ''}`, [
    { header: 'Ejercicio', key: 'year', width: 10 },
    { header: 'Cliente', key: 'client', width: 34 },
    { header: 'Factura', key: 'number', width: 16 },
    { header: 'Origen', key: 'kind', width: 15 },
    { header: 'Concepto', key: 'concept', width: 38 },
    { header: 'Fecha factura', key: 'issue', width: 13 },
    { header: 'Vencimiento', key: 'due', width: 13 },
    { header: 'Método de pago', key: 'method', width: 16 },
    { header: 'Importe', key: 'amount', width: 16, fmt: EUR },
    { header: 'Estado', key: 'status', width: 20 },
    { header: 'Fecha de cobro', key: 'paid', width: 14 },
    { header: 'Comisión generada', key: 'commission', width: 17, fmt: EUR },
    { header: 'Comerciales', key: 'users', width: 34 },
  ], rows, ['amount', 'commission']);
  return { buffer: await toBuffer(wb), filename: `Facturas_y_cobros${year ? `_${year}` : ''}.xlsx` };
}

/** Todas las líneas de comisión, con su estado y la nómina en la que se liquidaron. */
export async function linesWorkbook() {
  const wb = new ExcelJS.Workbook();
  sheet(wb, 'Comisiones', 'Comisiones e incentivos · histórico completo', [
    ...LINE_COLS,
    { header: 'Estado', key: 'status', width: 22 },
    { header: 'Nómina', key: 'payroll', width: 18 },
  ], (await listLines()).map(lineRow), ['amount']);
  return { buffer: await toBuffer(wb), filename: 'Comisiones_historico.xlsx' };
}

/** Registro de actividad: los últimos 5.000 cambios hechos en el portal. */
export async function auditWorkbook() {
  const wb = new ExcelJS.Workbook();
  sheet(wb, 'Actividad', 'Registro de actividad del portal', [
    { header: 'Fecha y hora (UTC)', key: 'at', width: 21 },
    { header: 'Usuario', key: 'user_name', width: 26 },
    { header: 'Acción', key: 'action', width: 26 },
    { header: 'Detalle', key: 'detail', width: 110 },
  ], await listAudit());
  return { buffer: await toBuffer(wb), filename: 'Registro_de_actividad.xlsx' };
}
