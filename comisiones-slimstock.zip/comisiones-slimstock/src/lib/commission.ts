/**
 * Motor de cálculo de comisiones. Funciones puras, sin acceso a base de datos.
 *
 * Fuente de las reglas:
 *  - Plan 1: porcentaje fijo 6,50 % (hoja "COMISIONES EVA" del Excel de liquidación).
 *  - Plan 2: contrato de cláusulas particulares "Comerciales (old)", cláusula SEXTA.
 *  - Plan 3: contrato de cláusulas particulares "Comerciales (new)", cláusula SEXTA.
 *  - Plan 4: anexo "Director/a Comercial".
 *
 * Si cambia un contrato, este es el único fichero de cálculo que hay que tocar.
 */

export type PlanId = 1 | 2 | 3 | 4;

/** Qué magnitud acumula cada plan para el escalado. */
export type Measure = 'ventas' | 'arr' | 'arr_direccion';

export type Tier = {
  label: string;
  /** Límite superior del tramo en acumulado anual. null = sin tope. */
  upTo: number | null;
  rate: number;
};

export type Plan = {
  id: PlanId;
  name: string;
  short: string;
  measure: Measure;
  /** true = comisión por factura cobrada; false = liquidación anual única. */
  perInvoice: boolean;
  description: string;
};

export const PLANS: Record<PlanId, Plan> = {
  1: {
    id: 1,
    name: 'Plan 1 · Fijo 6,50 %',
    short: 'Fijo 6,50 %',
    measure: 'ventas',
    perInvoice: true,
    description: '6,50 % fijo sobre la venta, sin escalado.',
  },
  2: {
    id: 2,
    name: 'Plan 2 · Escalado 2 % / 10 % / 13,33 %',
    short: 'Escalado por tramos',
    measure: 'ventas',
    perInvoice: true,
    description: '2 % hasta 225.000 €, 10 % hasta 375.000 € y 13,33 % en adelante, sobre el acumulado anual de ventas.',
  },
  3: {
    id: 3,
    name: 'Plan 3 · Nuevo sistema ARR',
    short: 'ARR por cuota',
    measure: 'arr',
    perInvoice: true,
    description: 'Escalado sobre el ARR acumulado según la cuota anual Q: 5 % hasta Q/3, 10 % hasta Q/2, 25 % hasta Q y 35 % por encima.',
  },
  4: {
    id: 4,
    name: 'Plan 4 · Director Comercial',
    short: 'Director 6 % ARR',
    measure: 'arr_direccion',
    perInvoice: false,
    description: '6 % sobre todo el ARR generado en el año. Se calcula al cierre del ejercicio y se abona en abril.',
  },
};

/** Cuota anual Q según salario fijo bruto (contrato nuevo, cláusula SEXTA.1). */
export const QUOTA_TABLE = [
  { label: 'Salario de 30.000 € a 60.000 €', quota: 360000 },
  { label: 'Salario de 60.000,01 € a 90.000 €', quota: 540000 },
  { label: 'Salario de 90.000,01 € a 125.000 €', quota: 750000 },
  { label: 'Salario superior a 125.000 €', quota: 900000 },
];

export const DEFAULT_QUOTA = 360000;
export const MANUAL_DEFAULT_RATE = 0.065;
export const DIRECTOR_RATE = 0.06;

export function round2(n: number): number {
  return Math.round((n + Number.EPSILON) * 100) / 100;
}

export function tiersFor(planId: PlanId, quota?: number | null): Tier[] {
  switch (planId) {
    case 1:
      return [{ label: 'Fijo 6,50 %', upTo: null, rate: 0.065 }];
    case 2:
      return [
        { label: 'Tramo 2 %', upTo: 225000, rate: 0.02 },
        { label: 'Tramo 10 %', upTo: 375000, rate: 0.1 },
        { label: 'Tramo 13,33 %', upTo: null, rate: 0.1333 },
      ];
    case 3: {
      const q = quota && quota > 0 ? quota : DEFAULT_QUOTA;
      return [
        { label: 'Entry 5 %', upTo: round2(q / 3), rate: 0.05 },
        { label: 'Build 10 %', upTo: round2(q / 2), rate: 0.1 },
        { label: 'Core 25 %', upTo: q, rate: 0.25 },
        { label: 'Accel. 35 %', upTo: null, rate: 0.35 },
      ];
    }
    case 4:
      return [{ label: 'Director 6 %', upTo: null, rate: DIRECTOR_RATE }];
  }
}

export type Slice = { label: string; rate: number; amount: number; commission: number };

export type Allocation = {
  slices: Slice[];
  commission: number;
  /** % efectivo del deal: comisión total / base. Es el que heredan sus facturas. */
  effectiveRate: number;
};

/**
 * Posiciona una base en la escala a partir del acumulado anual previo.
 * Cada euro devenga el % del tramo en el que cae, así que un deal que cruza
 * un umbral se reparte entre los dos tramos.
 */
export function allocate(tiers: Tier[], accumBefore: number, base: number): Allocation {
  const slices: Slice[] = [];
  let cursor = Math.max(0, accumBefore);
  let remaining = Math.max(0, base);
  for (const tier of tiers) {
    if (remaining <= 0) break;
    const room = tier.upTo === null ? Infinity : tier.upTo - cursor;
    if (room <= 0) continue;
    const amount = round2(Math.min(remaining, room));
    if (amount > 0) {
      slices.push({ label: tier.label, rate: tier.rate, amount, commission: round2(amount * tier.rate) });
      cursor += amount;
      remaining = round2(remaining - amount);
    }
  }
  const commission = round2(slices.reduce((s, x) => s + x.commission, 0));
  // Con un solo tramo el % es exactamente el del tramo; si cruza un umbral, el % mixto resultante.
  const effectiveRate = slices.length === 1 ? slices[0].rate : base > 0 ? commission / base : 0;
  return { slices, commission, effectiveRate };
}

/** Situación del comercial en la escala, para la barra de progreso. */
export function progress(tiers: Tier[], accumulated: number) {
  const idx = tiers.findIndex((t) => t.upTo === null || accumulated < t.upTo);
  const current = tiers[idx === -1 ? tiers.length - 1 : idx];
  const next = idx >= 0 && idx < tiers.length - 1 ? tiers[idx + 1] : null;
  return {
    current,
    next,
    /** Importe que falta para saltar al siguiente tramo; null si ya está en el último. */
    toNext: current.upTo === null ? null : round2(current.upTo - accumulated),
  };
}

/* ------------------------------------------------------------------ */
/* Bases de un deal                                                    */
/* ------------------------------------------------------------------ */

export type DealComponents = {
  /** Cuota mensual de pago por uso de licencias Slim4. */
  cuotaLicencias: number;
  /** Cuota mensual de licencias de usuario (operativas y de visualización). */
  cuotaUsuarios: number;
  /** Cuota mensual de hosting. */
  cuotaHosting: number;
  /** Importe de licencias en modalidad compra. */
  licenciasCompra: number;
  /** Importe de la implantación. */
  implantacion: number;
  /** % de fee al partner sobre las primeras 25 cuotas de pago por uso (0-100). */
  partnerFeePct: number;
};

export const EMPTY_COMPONENTS: DealComponents = {
  cuotaLicencias: 0,
  cuotaUsuarios: 0,
  cuotaHosting: 0,
  licenciasCompra: 0,
  implantacion: 0,
  partnerFeePct: 0,
};

export type DealBases = {
  /** Base de los planes 1 y 2 (contrato antiguo): 25 cuotas + licencias + implantación + 25 % hosting. */
  ventas: number;
  /** Base del plan 3 (contrato nuevo): 12 cuotas + 25 % de 12 cuotas de hosting. */
  arr: number;
  /** Base del plan 4 (anexo director): 12 cuotas + 43,75 % de licencias compradas + 12 cuotas de hosting. */
  arrDireccion: number;
  /** Fee total al partner sobre 25 cuotas. */
  partnerFee: number;
};

export function computeBases(c: DealComponents): DealBases {
  const cuotas = c.cuotaLicencias + c.cuotaUsuarios;
  const partnerFee = round2(cuotas * (c.partnerFeePct / 100) * 25);
  const ventas = c.licenciasCompra + c.implantacion + 25 * cuotas + 0.25 * 25 * c.cuotaHosting - partnerFee;
  const arr = 12 * cuotas + 0.25 * 12 * c.cuotaHosting - partnerFee * (12 / 25);
  const arrDireccion = 12 * cuotas + 0.4375 * c.licenciasCompra + 12 * c.cuotaHosting;
  return {
    ventas: round2(Math.max(0, ventas)),
    arr: round2(Math.max(0, arr)),
    arrDireccion: round2(Math.max(0, arrDireccion)),
    partnerFee,
  };
}

export function baseForMeasure(bases: { ventas: number; arr: number; arrDireccion: number }, m: Measure): number {
  return m === 'ventas' ? bases.ventas : m === 'arr' ? bases.arr : bases.arrDireccion;
}

/** Reparto por defecto de un deal compartido: a partes iguales. */
export function equalShares(n: number): number[] {
  if (n <= 0) return [];
  if (n === 1) return [100];
  if (n === 2) return [50, 50];
  const s = round2(100 / n);
  return Array.from({ length: n }, () => s);
}

/* ------------------------------------------------------------------ */
/* Facturas                                                            */
/* ------------------------------------------------------------------ */

export type InvoiceConcept = 'cuotas' | 'licencias' | 'implantacion' | 'hosting' | 'no_comisionable';

export const INVOICE_CONCEPTS: { id: InvoiceConcept; label: string }[] = [
  { id: 'cuotas', label: 'Cuotas de pago por uso (licencias / usuarios)' },
  { id: 'licencias', label: 'Licencias en compra' },
  { id: 'implantacion', label: 'Implantación' },
  { id: 'hosting', label: 'Hosting' },
  { id: 'no_comisionable', label: 'No comisionable (mantenimiento, gastos de visita…)' },
];

/**
 * Parte de una factura que computa como base de comisión según el plan.
 * Planes 1 y 2 comisionan licencias, cuotas e implantación; el plan 3 solo
 * lo recurrente. El hosting computa al 25 % en todos.
 */
export function invoiceFactor(planId: PlanId, concept: InvoiceConcept): number {
  if (concept === 'no_comisionable') return 0;
  if (concept === 'hosting') return 0.25;
  if (planId === 3) return concept === 'cuotas' ? 1 : 0;
  if (planId === 4) return 0;
  return 1;
}

/**
 * Comisión de una factura para un participante. La base comisionable nunca
 * supera lo que queda por facturar de la base del deal, y la última factura
 * ajusta céntimos para que el total coincida con la comisión del deal.
 */
export function invoiceLine(args: {
  invoiceAmount: number;
  factor: number;
  sharePct: number;
  participantBase: number;
  participantCommission: number;
  effectiveRate: number;
  alreadyBase: number;
  alreadyCommission: number;
}): { base: number; amount: number; rate: number } {
  const remaining = round2(Math.max(0, args.participantBase - args.alreadyBase));
  const wanted = round2(args.invoiceAmount * args.factor * (args.sharePct / 100));
  // Abono (factura rectificativa negativa): devuelve base y comisión al mismo %.
  if (wanted < 0) return { base: wanted, amount: round2(wanted * args.effectiveRate), rate: args.effectiveRate };
  const base = Math.min(wanted, remaining);
  if (base <= 0) return { base: 0, amount: 0, rate: args.effectiveRate };
  const exhausts = round2(remaining - base) <= 0;
  const amount = exhausts
    ? round2(Math.max(0, args.participantCommission - args.alreadyCommission))
    : round2(base * args.effectiveRate);
  return { base, amount, rate: args.effectiveRate };
}
