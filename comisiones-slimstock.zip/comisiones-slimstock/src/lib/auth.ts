import bcrypt from 'bcryptjs';
import crypto from 'node:crypto';
import { cookies, headers } from 'next/headers';
import { dbGet, dbRun } from './db';

export const SESSION_COOKIE = 'comisiones_session';
const SESSION_DAYS = 7;
export const MIN_PASSWORD_LENGTH = 8;

export type Role = 'finanzas' | 'comercial';

export type SessionUser = {
  id: number;
  email: string;
  name: string;
  role: Role;
  department: string;
  plan_id: number | null;
  quota: number | null;
  must_change_password: number;
  /** Huella de la sesión actual. */
  session?: string;
};

export class AppError extends Error {
  status: number;
  constructor(message: string, status = 400) {
    super(message);
    this.status = status;
  }
}

/*
 * Límite de intentos de acceso: 5 fallos por correo y 30 por dirección de red cada 15 minutos.
 * El segundo frena a quien prueba una contraseña contra muchos correos distintos.
 * Se guarda en la base de datos para que valga igual con uno o con varios servidores.
 */
const MAX_ATTEMPTS = 5;
const MAX_ATTEMPTS_IP = 30;
const WINDOW_MS = 15 * 60 * 1000;
// Hash de relleno: se compara aunque el correo no exista, para que la respuesta tarde lo mismo.
const DUMMY_HASH = bcrypt.hashSync('no-existe', 10);

async function blocked(key: string, max: number, now: number) {
  const a = await dbGet<{ n: number; until_ms: number }>('SELECT n, until_ms FROM login_attempts WHERE key = ?', [key]);
  return !!a && a.until_ms > now && a.n >= max;
}
async function fail(key: string, now: number) {
  // Si la ventana anterior ya venció, empieza una nueva; si no, suma un fallo.
  await dbRun(
    `INSERT INTO login_attempts (key, n, until_ms) VALUES (?, 1, ?)
     ON CONFLICT(key) DO UPDATE SET
       n = CASE WHEN login_attempts.until_ms <= ? THEN 1 ELSE login_attempts.n + 1 END,
       until_ms = CASE WHEN login_attempts.until_ms <= ? THEN excluded.until_ms ELSE login_attempts.until_ms END`,
    [key, now + WINDOW_MS, now, now]
  );
}

/** En la base de datos se guarda solo la huella de la sesión: una copia robada no sirve para entrar. */
const sessionId = (token: string) => crypto.createHash('sha256').update(token).digest('hex');

export function hashPassword(pw: string): string {
  return bcrypt.hashSync(pw, 10);
}

export async function login(email: string, password: string): Promise<SessionUser> {
  const key = email.trim().toLowerCase().slice(0, 200);
  const now = Date.now();
  const h = await headers();
  // La dirección de red solo se conoce detrás de un proxy; sin él, el límite es solo por correo.
  const ip = (h.get('x-forwarded-for') || '').split(',')[0].trim();
  const ipKey = ip ? 'ip:' + ip.slice(0, 60) : '';
  if ((await blocked(key, MAX_ATTEMPTS, now)) || (ipKey && (await blocked(ipKey, MAX_ATTEMPTS_IP, now)))) {
    throw new AppError('Demasiados intentos. Vuelve a probar en 15 minutos.', 429);
  }
  const row = await dbGet<any>('SELECT * FROM users WHERE email = ?', [key]);
  const matches = bcrypt.compareSync(password.slice(0, 200), row ? row.password_hash : DUMMY_HASH);
  const ok = !!row && row.active === 1 && matches;
  if (!ok) {
    await fail(key, now);
    if (ipKey) await fail(ipKey, now);
    throw new AppError('Correo o contraseña incorrectos.', 401);
  }
  await dbRun('DELETE FROM login_attempts WHERE key = ? OR until_ms <= ?', [key, now]);

  const token = crypto.randomBytes(32).toString('hex');
  const expires = new Date(now + SESSION_DAYS * 86400000);
  await dbRun('DELETE FROM sessions WHERE expires_at < ?', [new Date(now).toISOString()]);
  await dbRun('INSERT INTO sessions (token, user_id, expires_at) VALUES (?,?,?)', [sessionId(token), row.id, expires.toISOString()]);

  const https = h.get('x-forwarded-proto') === 'https';
  (await cookies()).set(SESSION_COOKIE, token, {
    httpOnly: true,
    sameSite: 'lax',
    secure: https,
    path: '/',
    expires,
  });
  return toSessionUser(row);
}

export async function logout(): Promise<void> {
  const jar = await cookies();
  const token = jar.get(SESSION_COOKIE)?.value;
  if (token) await dbRun('DELETE FROM sessions WHERE token = ?', [sessionId(token)]);
  jar.delete(SESSION_COOKIE);
}

function toSessionUser(row: any): SessionUser {
  return {
    id: row.id,
    email: row.email,
    name: row.name,
    role: row.role,
    department: row.department,
    plan_id: row.plan_id,
    quota: row.quota,
    must_change_password: row.must_change_password,
  };
}

/** Usuario de la sesión actual, o null. Se comprueba en servidor en cada petición. */
export async function currentUser(): Promise<SessionUser | null> {
  const token = (await cookies()).get(SESSION_COOKIE)?.value;
  if (!token) return null;
  const row = await dbGet<any>(
    `SELECT u.* FROM sessions s JOIN users u ON u.id = s.user_id
       WHERE s.token = ? AND s.expires_at > ? AND u.active = 1`,
    [sessionId(token), new Date().toISOString()]
  );
  return row ? { ...toSessionUser(row), session: sessionId(token) } : null;
}

/** Cierra las sesiones de un usuario; `exceptToken` conserva la sesión desde la que se pide. */
export async function endSessionsOf(userId: number, exceptToken?: string) {
  if (exceptToken) await dbRun('DELETE FROM sessions WHERE user_id = ? AND token <> ?', [userId, exceptToken]);
  else await dbRun('DELETE FROM sessions WHERE user_id = ?', [userId]);
}

export function validateNewPassword(pw: unknown): string {
  if (typeof pw !== 'string' || pw.length < MIN_PASSWORD_LENGTH) {
    throw new AppError(`La contraseña debe tener al menos ${MIN_PASSWORD_LENGTH} caracteres.`);
  }
  return pw;
}

/** Contraseña temporal legible para los reseteos que hace Finanzas. */
export function temporaryPassword(): string {
  const alphabet = 'ABCDEFGHJKLMNPQRSTUVWXYZabcdefghijkmnpqrstuvwxyz23456789';
  const bytes = crypto.randomBytes(10);
  return Array.from(bytes, (b) => alphabet[b % alphabet.length]).join('');
}
