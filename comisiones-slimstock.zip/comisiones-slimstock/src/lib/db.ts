import bcrypt from 'bcryptjs';
import { AsyncLocalStorage } from 'node:async_hooks';

/**
 * Acceso a datos. El portal funciona con dos bases de datos, según dónde se instale:
 *
 *  - LOCAL (máquina propia): SQLite integrado en Node.js, en el fichero data/comisiones.db.
 *  - NUBE (Vercel): Turso, un SQLite alojado al que se llega por internet. Se activa cuando
 *    existen las variables TURSO_DATABASE_URL y TURSO_AUTH_TOKEN.
 *
 * El resto del código no sabe cuál se usa: solo llama a dbAll / dbGet / dbRun / tx.
 */

const SCHEMA = `
CREATE TABLE IF NOT EXISTS users (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  email TEXT NOT NULL UNIQUE COLLATE NOCASE,
  name TEXT NOT NULL,
  password_hash TEXT NOT NULL,
  role TEXT NOT NULL CHECK (role IN ('finanzas','comercial')),
  department TEXT NOT NULL DEFAULT 'COMERCIAL',
  plan_id INTEGER,
  quota REAL,
  arr_target REAL,
  active INTEGER NOT NULL DEFAULT 1,
  must_change_password INTEGER NOT NULL DEFAULT 0,
  created_at TEXT NOT NULL DEFAULT (datetime('now'))
);

-- Ejercicios: se abren y se cierran desde la pantalla «Ejercicios».
CREATE TABLE IF NOT EXISTS fiscal_years (
  year INTEGER PRIMARY KEY,
  status TEXT NOT NULL DEFAULT 'abierto' CHECK (status IN ('abierto','cerrado')),
  opened_at TEXT NOT NULL DEFAULT (datetime('now')),
  closed_at TEXT,
  closed_by INTEGER REFERENCES users(id)
);

-- Plan, cuota Q y objetivo de ARR de cada comercial en cada ejercicio.
CREATE TABLE IF NOT EXISTS user_years (
  user_id INTEGER NOT NULL REFERENCES users(id) ON DELETE CASCADE,
  year INTEGER NOT NULL,
  plan_id INTEGER,
  quota REAL,
  arr_target REAL,
  PRIMARY KEY (user_id, year)
);

CREATE TABLE IF NOT EXISTS audit_log (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  at TEXT NOT NULL DEFAULT (datetime('now')),
  user_id INTEGER,
  user_name TEXT NOT NULL,
  action TEXT NOT NULL,
  detail TEXT NOT NULL DEFAULT ''
);

-- Intentos de acceso fallidos (en base de datos para que el límite valga en cualquier servidor).
CREATE TABLE IF NOT EXISTS login_attempts (
  key TEXT PRIMARY KEY,
  n INTEGER NOT NULL,
  until_ms INTEGER NOT NULL
);

CREATE TABLE IF NOT EXISTS sessions (
  token TEXT PRIMARY KEY,
  user_id INTEGER NOT NULL REFERENCES users(id) ON DELETE CASCADE,
  expires_at TEXT NOT NULL
);

CREATE TABLE IF NOT EXISTS deals (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  client TEXT NOT NULL,
  year INTEGER NOT NULL,
  signed_date TEXT NOT NULL,
  sale_type TEXT NOT NULL,
  components TEXT NOT NULL,
  total_amount REAL NOT NULL,
  base_ventas REAL NOT NULL,
  base_arr REAL NOT NULL,
  base_arr_direccion REAL NOT NULL,
  notes TEXT NOT NULL DEFAULT '',
  status TEXT NOT NULL DEFAULT 'activo',
  created_at TEXT NOT NULL DEFAULT (datetime('now'))
);
CREATE INDEX IF NOT EXISTS deals_year ON deals(year);

CREATE TABLE IF NOT EXISTS deal_participants (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  deal_id INTEGER NOT NULL REFERENCES deals(id) ON DELETE CASCADE,
  user_id INTEGER NOT NULL REFERENCES users(id),
  share_pct REAL NOT NULL,
  plan_id INTEGER NOT NULL,
  base REAL NOT NULL,
  accum_before REAL NOT NULL,
  slices TEXT NOT NULL,
  commission_total REAL NOT NULL,
  effective_rate REAL NOT NULL
);
CREATE INDEX IF NOT EXISTS dp_deal ON deal_participants(deal_id);
CREATE INDEX IF NOT EXISTS dp_user ON deal_participants(user_id);

-- kind: 'factura' (vinculada a un deal) | 'manual' (comisión fuera de deal)
CREATE TABLE IF NOT EXISTS invoices (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  kind TEXT NOT NULL DEFAULT 'factura',
  deal_id INTEGER REFERENCES deals(id),
  client TEXT NOT NULL,
  number TEXT NOT NULL DEFAULT '',
  concept TEXT NOT NULL DEFAULT 'cuotas',
  description TEXT NOT NULL DEFAULT '',
  year INTEGER NOT NULL,
  issue_date TEXT NOT NULL,
  due_date TEXT NOT NULL,
  amount REAL NOT NULL,
  method TEXT NOT NULL CHECK (method IN ('giro','transferencia')),
  status TEXT NOT NULL DEFAULT 'pendiente' CHECK (status IN ('pendiente','cobrada')),
  paid_date TEXT,
  created_at TEXT NOT NULL DEFAULT (datetime('now'))
);
CREATE INDEX IF NOT EXISTS inv_deal ON invoices(deal_id);
CREATE INDEX IF NOT EXISTS inv_status ON invoices(status);

-- Una línea por comercial y factura. status sigue a la factura:
-- pendiente_cobro -> por_liquidar (factura cobrada) -> liquidada (incluida en nómina)
-- kind 'incentivo' = incentivo anual del Director Comercial (sin factura).
CREATE TABLE IF NOT EXISTS commission_lines (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  kind TEXT NOT NULL DEFAULT 'factura',
  invoice_id INTEGER REFERENCES invoices(id) ON DELETE CASCADE,
  deal_id INTEGER REFERENCES deals(id),
  user_id INTEGER NOT NULL REFERENCES users(id),
  year INTEGER NOT NULL,
  client TEXT NOT NULL,
  reference TEXT NOT NULL DEFAULT '',
  base REAL NOT NULL,
  rate REAL NOT NULL,
  amount REAL NOT NULL,
  status TEXT NOT NULL DEFAULT 'pendiente_cobro' CHECK (status IN ('pendiente_cobro','por_liquidar','liquidada')),
  settlement_id INTEGER REFERENCES settlements(id),
  created_at TEXT NOT NULL DEFAULT (datetime('now'))
);
CREATE INDEX IF NOT EXISTS cl_user ON commission_lines(user_id);
CREATE INDEX IF NOT EXISTS cl_status ON commission_lines(status);
CREATE INDEX IF NOT EXISTS cl_invoice ON commission_lines(invoice_id);
CREATE INDEX IF NOT EXISTS cl_deal_user ON commission_lines(deal_id, user_id);
CREATE INDEX IF NOT EXISTS cl_settlement ON commission_lines(settlement_id);
CREATE INDEX IF NOT EXISTS cl_year ON commission_lines(year);

CREATE TABLE IF NOT EXISTS settlements (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  year INTEGER NOT NULL,
  month INTEGER NOT NULL,
  total REAL NOT NULL,
  closed_by INTEGER NOT NULL REFERENCES users(id),
  closed_at TEXT NOT NULL DEFAULT (datetime('now'))
);

CREATE TABLE IF NOT EXISTS notifications (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  user_id INTEGER NOT NULL REFERENCES users(id),
  settlement_id INTEGER REFERENCES settlements(id),
  title TEXT NOT NULL,
  body TEXT NOT NULL,
  amount REAL NOT NULL DEFAULT 0,
  read_at TEXT,
  created_at TEXT NOT NULL DEFAULT (datetime('now'))
);

CREATE TABLE IF NOT EXISTS threads (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  user_id INTEGER NOT NULL REFERENCES users(id),
  subject TEXT NOT NULL,
  status TEXT NOT NULL DEFAULT 'pendiente' CHECK (status IN ('pendiente','respondida')),
  created_at TEXT NOT NULL DEFAULT (datetime('now')),
  updated_at TEXT NOT NULL DEFAULT (datetime('now'))
);

CREATE TABLE IF NOT EXISTS thread_messages (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  thread_id INTEGER NOT NULL REFERENCES threads(id) ON DELETE CASCADE,
  author_id INTEGER NOT NULL REFERENCES users(id),
  body TEXT NOT NULL,
  created_at TEXT NOT NULL DEFAULT (datetime('now'))
);
`;

export type RunResult = { lastInsertRowid: number; changes: number };
type Runner = {
  all(sql: string, params: any[]): Promise<any[]>;
  run(sql: string, params: any[]): Promise<RunResult>;
  exec(sql: string): Promise<void>;
};
type Driver = Runner & {
  kind: 'local' | 'nube';
  /** Abre una transacción de escritura y devuelve cómo ejecutar dentro de ella y cómo cerrarla. */
  begin(): Promise<{ runner: Runner; commit(): Promise<void>; rollback(): Promise<void> }>;
};

const clean = (params: any[]) => params.map((v) => (v === undefined ? null : typeof v === 'boolean' ? (v ? 1 : 0) : v));

/* ------------------------------ LOCAL ------------------------------ */

async function localDriver(): Promise<Driver> {
  const { DatabaseSync } = await import('node:sqlite');
  const fs = await import('node:fs');
  const path = await import('node:path');
  const file = process.env.DATABASE_PATH || path.join(process.cwd(), 'data', 'comisiones.db');
  fs.mkdirSync(path.dirname(file), { recursive: true });
  const d = new DatabaseSync(file);
  d.exec('PRAGMA journal_mode = WAL');
  d.exec('PRAGMA foreign_keys = ON');
  d.exec('PRAGMA busy_timeout = 5000');

  // Una sola conexión: las transacciones se ejecutan de una en una y, mientras hay una
  // abierta, el resto de consultas espera. Así nadie lee datos a medio guardar.
  let busy = false;
  const waiting: (() => void)[] = [];
  const acquire = async () => { while (busy) await new Promise<void>((r) => waiting.push(r)); busy = true; };
  const release = () => { busy = false; const next = waiting.shift(); if (next) next(); };
  const idle = async () => { while (busy) await new Promise<void>((r) => waiting.push(r)); const next = waiting.shift(); if (next) next(); };

  const raw: Runner = {
    async all(sql, params) { return d.prepare(sql).all(...clean(params)) as any[]; },
    async run(sql, params) { const r = d.prepare(sql).run(...clean(params)); return { lastInsertRowid: Number(r.lastInsertRowid), changes: Number(r.changes) }; },
    async exec(sql) { d.exec(sql); },
  };
  return {
    kind: 'local',
    async all(sql, params) { await idle(); return raw.all(sql, params); },
    async run(sql, params) { await idle(); return raw.run(sql, params); },
    async exec(sql) { await idle(); return raw.exec(sql); },
    async begin() {
      await acquire();
      try { d.exec('BEGIN IMMEDIATE'); } catch (e) { release(); throw e; }
      return {
        runner: raw,
        async commit() { try { d.exec('COMMIT'); } finally { release(); } },
        async rollback() { try { d.exec('ROLLBACK'); } finally { release(); } },
      };
    },
  };
}

/* ------------------------------- NUBE ------------------------------ */

async function cloudDriver(url: string, authToken: string | undefined): Promise<Driver> {
  // «file:» solo se usa en las pruebas automáticas, para ejercitar este mismo código sin red.
  const mod: any = url.startsWith('file:') ? await import('@libsql/client') : await import('@libsql/client/web');
  const client = mod.createClient({ url, authToken });
  const rows = (r: any) => r.rows.map((row: any) => Object.fromEntries(r.columns.map((c: string, i: number) => [c, row[i]])));
  const result = (r: any): RunResult => ({ lastInsertRowid: r.lastInsertRowid === undefined ? 0 : Number(r.lastInsertRowid), changes: r.rowsAffected });
  // Solo para pruebas: simula el retardo de red de cada consulta a una base de datos remota.
  const lag = Number(process.env.DB_TEST_LATENCY_MS || 0);
  const wait = () => (lag ? new Promise((r) => setTimeout(r, lag)) : null);
  const wrap = (h: any): Runner => ({
    async all(sql, params) { await wait(); return rows(await h.execute({ sql, args: clean(params) })); },
    async run(sql, params) { await wait(); return result(await h.execute({ sql, args: clean(params) })); },
    async exec(sql) { await h.executeMultiple(sql); },
  });
  const base = wrap(client);
  if (url.startsWith('file:')) await client.execute('PRAGMA busy_timeout = 5000');
  return {
    kind: 'nube',
    ...base,
    async begin() {
      // Si otra petición está escribiendo, se reintenta unas cuantas veces antes de rendirse.
      let t: any;
      for (let attempt = 0; ; attempt++) {
        try { t = await client.transaction('write'); break; } catch (e: any) {
          if (attempt >= 6 || !/busy|locked/i.test(String(e?.message || e?.code))) throw e;
          await new Promise((r) => setTimeout(r, 40 * 2 ** attempt + Math.random() * 40));
        }
      }
      const runner = wrap(t);
      return { runner, async commit() { await t.commit(); }, async rollback() { try { await t.rollback(); } finally { t.close(); } } };
    },
  };
}

/* --------------------------- Puesta en marcha ----------------------- */

/** Usuarios iniciales de una instalación local. La contraseña debe cambiarse en el primer acceso. */
const SEED_USERS = [
  { email: 'e.pinteno@slimstock.com', name: 'E. Pinteño', role: 'finanzas', department: 'FINANZAS', plan_id: null, arr_target: null },
  { email: 'e.abellan@slimstock.com', name: 'E. Abellán', role: 'comercial', department: 'COMERCIAL', plan_id: 2, arr_target: 360000 },
];
const SEED_PASSWORD = '1234';

export const isCloud = () => !!process.env.TURSO_DATABASE_URL;

/** Error de configuración: su mensaje se puede enseñar tal cual a quien está instalando. */
export class ConfigError extends Error {}

async function start(): Promise<Driver> {
  const url = process.env.TURSO_DATABASE_URL;
  if (!url && process.env.VERCEL) {
    throw new ConfigError('Falta conectar la base de datos: en Vercel, añade Turso desde la pestaña Storage del proyecto y vuelve a desplegar.');
  }
  const driver = url ? await cloudDriver(url, process.env.TURSO_AUTH_TOKEN) : await localDriver();
  await driver.exec(SCHEMA);
  // Migración: objetivo anual de ARR por comercial (bases creadas con la versión 1.0).
  const cols = await driver.all('PRAGMA table_info(users)', []);
  if (!cols.some((c) => c.name === 'arr_target')) await driver.exec('ALTER TABLE users ADD COLUMN arr_target REAL');

  const count = (await driver.all('SELECT COUNT(*) AS n FROM users', []))[0].n;
  if (count === 0) {
    const adminEmail = (process.env.ADMIN_EMAIL || '').trim().toLowerCase();
    const adminPassword = process.env.ADMIN_PASSWORD || '';
    const insert = 'INSERT OR IGNORE INTO users (email, name, password_hash, role, department, plan_id, arr_target, must_change_password) VALUES (?,?,?,?,?,?,?,1)';
    if (adminEmail || driver.kind === 'nube') {
      // En internet no hay contraseñas por defecto: el primer administrador sale de la configuración.
      if (!/^[^@\s]+@[^@\s]+\.[^@\s]+$/.test(adminEmail) || adminPassword.length < 12) {
        throw new ConfigError('Falta configurar el primer administrador: define las variables ADMIN_EMAIL y ADMIN_PASSWORD (12 caracteres o más) y vuelve a desplegar.');
      }
      await driver.run(insert, [adminEmail, adminEmail.split('@')[0], bcrypt.hashSync(adminPassword, 10), 'finanzas', 'FINANZAS', null, null]);
    } else {
      const hash = bcrypt.hashSync(SEED_PASSWORD, 10);
      for (const u of SEED_USERS) await driver.run(insert, [u.email, u.name, hash, u.role, u.department, u.plan_id, u.arr_target]);
    }
  }
  return driver;
}

// Una sola conexión por proceso (también entre recargas en desarrollo).
const g = globalThis as unknown as { __comisionesDriver?: Promise<Driver> };
function driver(): Promise<Driver> {
  if (!g.__comisionesDriver) {
    g.__comisionesDriver = start().catch((e) => { g.__comisionesDriver = undefined; throw e; });
  }
  return g.__comisionesDriver;
}

/** Transacción en curso de la petición actual, si la hay. */
const current = new AsyncLocalStorage<{ runner: Runner; depth: number }>();
const runner = async (): Promise<Runner> => current.getStore()?.runner ?? (await driver());

export async function dbAll<T = any>(sql: string, params: any[] = []): Promise<T[]> { return (await runner()).all(sql, params) as Promise<T[]>; }
export async function dbGet<T = any>(sql: string, params: any[] = []): Promise<T | undefined> { return (await dbAll<T>(sql, params))[0]; }
export async function dbRun(sql: string, params: any[] = []): Promise<RunResult> { return (await runner()).run(sql, params); }

/**
 * Ejecuta fn dentro de una transacción: o se guarda todo o no se guarda nada.
 * Las llamadas anidadas usan puntos de guardado.
 */
export async function tx<T>(fn: () => Promise<T>): Promise<T> {
  const outer = current.getStore();
  if (outer) {
    const name = `sp${outer.depth}`;
    await outer.runner.run(`SAVEPOINT ${name}`, []);
    try {
      const result = await current.run({ runner: outer.runner, depth: outer.depth + 1 }, fn);
      await outer.runner.run(`RELEASE ${name}`, []);
      return result;
    } catch (e) {
      await outer.runner.run(`ROLLBACK TO ${name}`, []);
      await outer.runner.run(`RELEASE ${name}`, []);
      throw e;
    }
  }
  const t = await (await driver()).begin();
  let result: T;
  try {
    result = await current.run({ runner: t.runner, depth: 0 }, fn);
  } catch (e) {
    await t.rollback();
    throw e;
  }
  await t.commit();
  return result;
}
