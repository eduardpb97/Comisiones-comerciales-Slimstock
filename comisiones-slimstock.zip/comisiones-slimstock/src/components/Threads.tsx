'use client';
import { useEffect, useState } from 'react';
import { act, fdate, rpc, useData } from './client';
import { Empty, Field, Loading, PageHead } from './ui';

/** Buzón de consultas. El comercial abre consultas; Finanzas las responde. */
export function Threads({ role, meId }: { role: 'finanzas' | 'comercial'; meId: number }) {
  const { data: threads, error, reload } = useData<any[]>('threads.list');
  const [openId, setOpenId] = useState<number | null>(null);
  const [thread, setThread] = useState<any>(null);
  const [reply, setReply] = useState('');
  const [draft, setDraft] = useState({ subject: '', body: '' });
  const [composing, setComposing] = useState(false);

  useEffect(() => {
    if (openId === null) return setThread(null);
    rpc('threads.get', { id: openId }).then(setThread).catch(() => setThread(null));
  }, [openId]);

  useEffect(() => {
    if (threads && threads.length && openId === null && !composing) setOpenId(threads[0].id);
  }, [threads, openId, composing]);

  const send = async () => {
    if (!reply.trim() || !thread) return;
    const r = await act('threads.reply', { id: thread.id, body: reply }, role === 'finanzas' ? 'Respuesta enviada.' : 'Mensaje enviado.');
    if (r) {
      setReply('');
      setThread(await rpc('threads.get', { id: thread.id }));
      reload();
    }
  };
  const create = async (e: React.FormEvent) => {
    e.preventDefault();
    const r = await act<{ id: number }>('threads.create', draft, 'Consulta enviada a Finanzas.');
    if (r) {
      setDraft({ subject: '', body: '' });
      setComposing(false);
      await reload();
      setOpenId(r.id);
    }
  };

  return (
    <>
      <PageHead
        title={role === 'finanzas' ? 'Consultas de comerciales' : 'Consultas a Finanzas'}
        sub={role === 'finanzas' ? 'Dudas que envían los comerciales y consultores sobre sus comisiones.' : 'Envía a Finanzas cualquier duda sobre tus comisiones. La respuesta llega a este mismo buzón.'}
      >
        {role === 'comercial' && <button className="btn primary" onClick={() => { setComposing(true); setOpenId(null); }}>Nueva consulta</button>}
      </PageHead>
      {!threads ? <Loading error={error} /> : (
        <div className="split">
          <div className="card flush thread-list">
            {threads.length === 0 && <Empty title="Sin consultas">{role === 'finanzas' ? 'Cuando un comercial escriba, aparecerá aquí.' : 'Todavía no has enviado ninguna.'}</Empty>}
            {threads.map((t) => (
              <button key={t.id} className={t.id === openId ? 'on' : ''} onClick={() => { setComposing(false); setOpenId(t.id); }}>
                <div className="spread">
                  <b>{t.subject}</b>
                  <span className={`pill ${t.status === 'pendiente' ? 'warn' : 'ok'}`}>{t.status === 'pendiente' ? 'Pendiente' : 'Respondida'}</span>
                </div>
                <p>{role === 'finanzas' ? `${t.user_name} · ` : ''}{t.last_body}</p>
              </button>
            ))}
          </div>
          <div className="card">
            {composing ? (
              <form className="stack" onSubmit={create}>
                <h2>Nueva consulta</h2>
                <Field label="Asunto"><input id="thread-subject" required maxLength={160} value={draft.subject} onChange={(e) => setDraft({ ...draft, subject: e.target.value })} /></Field>
                <Field label="Mensaje"><textarea id="thread-body" required value={draft.body} onChange={(e) => setDraft({ ...draft, body: e.target.value })} /></Field>
                <div className="row">
                  <button className="btn primary">Enviar a Finanzas</button>
                  <button type="button" className="btn" onClick={() => setComposing(false)}>Cancelar</button>
                </div>
              </form>
            ) : thread ? (
              <div className="stack">
                <div>
                  <h2>{thread.subject}</h2>
                  <p className="muted small">{thread.user_name} · abierta el {fdate(thread.created_at)}</p>
                </div>
                {thread.messages.map((m: any) => (
                  <div key={m.id} className={`msg${m.author_id === meId ? ' mine' : ''}`}>
                    <small>{m.author_role === 'finanzas' ? 'Finanzas' : m.author_name} · {fdate(m.created_at)}</small>
                    {m.body}
                  </div>
                ))}
                <Field label={role === 'finanzas' ? 'Respuesta' : 'Añadir mensaje'}>
                  <textarea id="thread-reply" value={reply} onChange={(e) => setReply(e.target.value)} />
                </Field>
                <div><button className="btn primary" onClick={send} disabled={!reply.trim()}>{role === 'finanzas' ? 'Responder' : 'Enviar'}</button></div>
              </div>
            ) : (
              <Empty title="Selecciona una consulta" />
            )}
          </div>
        </div>
      )}
    </>
  );
}
