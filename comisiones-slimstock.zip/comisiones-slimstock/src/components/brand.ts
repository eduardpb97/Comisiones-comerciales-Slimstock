/** Logotipos (en /public). La demo en un solo HTML los sustituye por imágenes incrustadas. */
export const LOGO = '/logo.png';
export const LOGO_WHITE = '/logo-white.png';
