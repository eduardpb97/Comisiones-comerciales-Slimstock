'use client';
import { useState } from 'react';
import { rpc } from './client';
import { Field } from './ui';

/** Cambio de contraseña del propio usuario. */
export function PasswordForm({ onDone, intro }: { onDone?: () => void; intro?: string }) {
  const [f, setF] = useState({ current: '', next: '', repeat: '' });
  const [error, setError] = useState('');
  const [ok, setOk] = useState(false);
  const [busy, setBusy] = useState(false);
  const submit = async (e: React.FormEvent) => {
    e.preventDefault();
    setOk(false);
    if (f.next !== f.repeat) return setError('Las dos contraseñas nuevas no coinciden.');
    setBusy(true);
    try {
      await rpc('profile.changePassword', { current: f.current, next: f.next });
      setError('');
      setOk(true);
      setF({ current: '', next: '', repeat: '' });
      onDone?.();
    } catch (err: any) {
      setError(err.message);
    } finally {
      setBusy(false);
    }
  };
  return (
    <form className="stack" onSubmit={submit}>
      {intro && <p className="muted">{intro}</p>}
      <Field label="Contraseña actual">
        <input id="pw-current" type="password" autoComplete="current-password" required value={f.current} onChange={(e) => setF({ ...f, current: e.target.value })} />
      </Field>
      <Field label="Nueva contraseña" hint="mínimo 8 caracteres">
        <input id="pw-next" type="password" autoComplete="new-password" required minLength={8} value={f.next} onChange={(e) => setF({ ...f, next: e.target.value })} />
      </Field>
      <Field label="Repite la nueva contraseña">
        <input id="pw-repeat" type="password" autoComplete="new-password" required minLength={8} value={f.repeat} onChange={(e) => setF({ ...f, repeat: e.target.value })} />
      </Field>
      {error && <div className="error">{error}</div>}
      {ok && <div className="note">Contraseña cambiada.</div>}
      <div><button className="btn primary" disabled={busy}>Cambiar contraseña</button></div>
    </form>
  );
}
