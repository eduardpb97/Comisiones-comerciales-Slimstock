'use client';
import { useCallback, useEffect, useRef, useState } from 'react';

/** Llama a una acción del servidor. Lanza Error con un mensaje listo para mostrar. */
export async function rpc<T = any>(action: string, payload?: any): Promise<T> {
  let res: Response;
  try {
    res = await fetch('/api/rpc', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ action, payload }),
    });
  } catch {
    throw new Error('No hay conexión con el servidor. Comprueba la red e inténtalo de nuevo.');
  }
  const json = await res.json().catch(() => ({}));
  if (res.status === 401) {
    go('/login');
    throw new Error(json.error || 'Sesión caducada.');
  }
  if (!res.ok) throw new Error(json.error || 'Ha ocurrido un error.');
  return json.data as T;
}

/** Cambia de página recargando: así el servidor vuelve a comprobar la sesión. */
export function go(path: string) { window.location.href = path; }

export async function signIn(email: string, password: string): Promise<void> {
  const res = await fetch('/api/login', {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify({ email, password }),
  });
  const json = await res.json().catch(() => ({}));
  if (!res.ok) throw new Error(json.error || 'No se ha podido iniciar sesión.');
}

export async function signOut(): Promise<void> {
  await fetch('/api/logout', { method: 'POST' }).catch(() => {});
  go('/login');
}

/** Carga datos de una acción y permite recargarlos. */
export function useData<T = any>(action: string, payload: any = {}) {
  const [data, setData] = useState<T | null>(null);
  const [error, setError] = useState('');
  const key = JSON.stringify(payload);
  const seq = useRef(0);
  const reload = useCallback(async () => {
    const n = ++seq.current;
    try {
      const d = await rpc<T>(action, JSON.parse(key));
      if (n === seq.current) { setData(d); setError(''); }
    } catch (e: any) {
      if (n === seq.current) setError(e.message);
    }
  }, [action, key]);
  useEffect(() => { reload(); }, [reload]);
  return { data, error, reload };
}

// useGrouping 'always': en español los miles de 4 cifras no llevan punto por defecto (5921,87 €).
const EUR = new Intl.NumberFormat('es-ES', { style: 'currency', currency: 'EUR', useGrouping: 'always' } as Intl.NumberFormatOptions);
const EUR0 = new Intl.NumberFormat('es-ES', { style: 'currency', currency: 'EUR', maximumFractionDigits: 0, useGrouping: 'always' } as Intl.NumberFormatOptions);
const PCT = new Intl.NumberFormat('es-ES', { maximumFractionDigits: 2 });

export const eur = (n: number | null | undefined) => EUR.format(n || 0);
export const eur0 = (n: number | null | undefined) => EUR0.format(n || 0);
export const pct = (rate: number | null | undefined) => `${PCT.format((rate || 0) * 100)} %`;
export const fdate = (iso?: string | null) => (iso ? `${iso.slice(8, 10)}/${iso.slice(5, 7)}/${iso.slice(0, 4)}` : '—');
export const MONTHS = ['Enero', 'Febrero', 'Marzo', 'Abril', 'Mayo', 'Junio', 'Julio', 'Agosto', 'Septiembre', 'Octubre', 'Noviembre', 'Diciembre'];

export function toast(message: string, kind: 'ok' | 'bad' = 'ok') {
  window.dispatchEvent(new CustomEvent('app-toast', { detail: { message, kind } }));
}

/** Ejecuta una acción mostrando el resultado o el error en un aviso. */
export async function act<T = any>(action: string, payload: any, okMessage?: string): Promise<T | null> {
  try {
    const r = await rpc<T>(action, payload);
    if (okMessage) toast(okMessage);
    return r;
  } catch (e: any) {
    toast(e.message, 'bad');
    return null;
  }
}

export const matches = (q: string, ...fields: (string | null | undefined)[]) => {
  const needle = q.trim().toLowerCase();
  return !needle || fields.some((f) => (f || '').toLowerCase().includes(needle));
};
