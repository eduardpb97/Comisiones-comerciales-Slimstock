'use client';
import { ReactNode, useEffect, useState } from 'react';
import { eur0 } from './client';

export function Modal({ title, onClose, children, footer, narrow }: { title: string; onClose: () => void; children: ReactNode; footer?: ReactNode; narrow?: boolean }) {
  useEffect(() => {
    const onKey = (e: KeyboardEvent) => e.key === 'Escape' && onClose();
    window.addEventListener('keydown', onKey);
    return () => window.removeEventListener('keydown', onKey);
  }, [onClose]);
  return (
    <div className="overlay" role="dialog" aria-modal="true" aria-label={title}>
      <div className={`modal${narrow ? ' narrow' : ''}`}>
        <div className="modal-head">
          <h2>{title}</h2>
          <button className="x" onClick={onClose} aria-label="Cerrar">×</button>
        </div>
        <div className="modal-body">{children}</div>
        {footer && <div className="modal-foot">{footer}</div>}
      </div>
    </div>
  );
}

export function Field({ label, hint, children }: { label: string; hint?: string; children: ReactNode }) {
  return (
    <label className="field">
      <span>{label}{hint && <span className="hint"> · {hint}</span>}</span>
      {children}
    </label>
  );
}

export function Kpi({ label, value, hint, tone }: { label: string; value: ReactNode; hint?: ReactNode; tone?: 'accent' | 'ok' | 'warn' }) {
  return (
    <div className={`card kpi ${tone || ''}`}>
      <span className="label">{label}</span>
      <span className="value">{value}</span>
      {hint && <span className="hint">{hint}</span>}
    </div>
  );
}

export function PageHead({ title, sub, children }: { title: string; sub?: string; children?: ReactNode }) {
  return (
    <div className="page-head">
      <div>
        <h1>{title}</h1>
        {sub && <p>{sub}</p>}
      </div>
      {children && <div className="toolbar">{children}</div>}
    </div>
  );
}

export function YearSelect({ years, value, onChange, all }: { years: number[]; value: number | ''; onChange: (y: number | '') => void; all?: boolean }) {
  return (
    <select aria-label="Ejercicio" value={value} onChange={(e) => onChange(e.target.value ? Number(e.target.value) : '')}>
      {all && <option value="">Todos los ejercicios</option>}
      {years.map((y) => <option key={y} value={y}>Ejercicio {y}</option>)}
    </select>
  );
}

export function Loading({ error }: { error?: string }) {
  return error ? <div className="error">{error}</div> : <div className="empty">Cargando…</div>;
}

export function Empty({ title, children }: { title: string; children?: ReactNode }) {
  return <div className="empty"><b>{title}</b>{children}</div>;
}

const LINE_STATUS: Record<string, [string, string]> = {
  pendiente_cobro: ['Pendiente de cobro', 'warn'],
  por_liquidar: ['Cobrada · próxima nómina', 'info'],
  liquidada: ['Liquidada', 'ok'],
};
export function LineStatus({ status }: { status: string }) {
  const [label, tone] = LINE_STATUS[status] || [status, ''];
  return <span className={`pill ${tone}`}>{label}</span>;
}

export function InvoiceStatus({ inv }: { inv: { status: string; overdue?: boolean } }) {
  if (inv.status === 'cobrada') return <span className="pill ok">Cobrada</span>;
  if (inv.overdue) return <span className="pill bad">Vencida sin cobrar</span>;
  return <span className="pill warn">Pendiente de cobro</span>;
}

export const METHOD: Record<string, string> = { giro: 'Giro bancario', transferencia: 'Transferencia' };

type Tier = { label: string; upTo: number | null; rate: number };

/** Barra de progreso anual sobre la escala de tramos del plan. */
export function TierBar({ tiers, accumulated }: { tiers: Tier[]; accumulated: number }) {
  const finite = tiers.filter((t) => t.upTo !== null) as (Tier & { upTo: number })[];
  if (!finite.length) return null;
  const lastCap = finite[finite.length - 1].upTo;
  // El último tramo no tiene tope: se dibuja con un ancho fijo que crece si el acumulado lo supera.
  const max = Math.max(lastCap * 1.3, accumulated * 1.08);
  let from = 0;
  const segs = tiers.map((t) => {
    const to = t.upTo ?? max;
    const seg = { ...t, from, to, width: ((to - from) / max) * 100 };
    from = to;
    return seg;
  });
  const fill = Math.min(100, (accumulated / max) * 100);
  return (
    <div className="tiers">
      <div className="tier-track">
        <div className="tier-fill" style={{ width: `${fill}%` }} />
        {segs.map((s) => (
          <div key={s.label} className={`tier-seg${accumulated >= (s.from + s.to) / 2 ? ' done' : ''}`} style={{ width: `${s.width}%` }}>
            <span>{s.label}</span>
          </div>
        ))}
      </div>
      <div className="tier-marks">
        <span style={{ left: 0 }}>0 €</span>
        {finite.map((t) => <span key={t.label} style={{ left: `${(t.upTo / max) * 100}%` }}>{eur0(t.upTo)}</span>)}
      </div>
    </div>
  );
}

export function Toaster() {
  const [items, setItems] = useState<{ id: number; message: string; kind: string }[]>([]);
  useEffect(() => {
    const on = (e: Event) => {
      const d = (e as CustomEvent).detail;
      const id = Date.now() + Math.random();
      setItems((x) => [...x, { id, ...d }]);
      setTimeout(() => setItems((x) => x.filter((i) => i.id !== id)), d.kind === 'bad' ? 7000 : 3500);
    };
    window.addEventListener('app-toast', on);
    return () => window.removeEventListener('app-toast', on);
  }, []);
  return (
    <div className="toasts" aria-live="polite">
      {items.map((t) => <div key={t.id} className={`toast ${t.kind}`}>{t.message}</div>)}
    </div>
  );
}

export function ExportLink({ href, children }: { href: string; children: ReactNode }) {
  return <a className="btn" href={href}>↓ {children}</a>;
}

/* ------------------------------------------------------------------ */
/* Marca y consecución de objetivos                                    */
/* ------------------------------------------------------------------ */

/** Rombos decorativos del logotipo. El contenedor necesita position: relative. */
export function Diamonds() {
  return <span className="diamonds" aria-hidden="true"><i /><i /><i /><i /></span>;
}

const P0 = new Intl.NumberFormat('es-ES', { maximumFractionDigits: 0 });
export const pct0 = (r: number | null | undefined) => (r === null || r === undefined ? '—' : `${P0.format(r * 100)} %`);

/** Anillo de consecución: porcentaje sobre el objetivo. */
export function Ring({ value, size = 132, label = 'del objetivo' }: { value: number | null; size?: number; label?: string }) {
  const stroke = 12;
  const r = (size - stroke) / 2;
  const c = 2 * Math.PI * r;
  const v = Math.max(0, Math.min(1, value || 0));
  return (
    <div className="ring" style={{ width: size, height: size }} role="img" aria-label={`${pct0(value)} ${label}`}>
      <svg width={size} height={size} viewBox={`0 0 ${size} ${size}`}>
        <circle className="ring-bg" cx={size / 2} cy={size / 2} r={r} fill="none" strokeWidth={stroke} />
        <circle className={`ring-fg${(value || 0) >= 1 ? ' done' : ''}`} cx={size / 2} cy={size / 2} r={r} fill="none" strokeWidth={stroke}
          strokeDasharray={`${c * v} ${c}`} />
      </svg>
      <div className="ring-label"><div><b>{pct0(value)}</b><small>{label}</small></div></div>
    </div>
  );
}

/**
 * Barra de consecución. La escala llega al 125 % del objetivo para que se vea
 * cuándo se supera; el rombo marca el 100 %.
 */
export function AttainBar({ achieved, goal, meta = true }: { achieved: number; goal: number | null; meta?: boolean }) {
  if (!goal) return <span className="muted small">Sin objetivo asignado</span>;
  const ratio = achieved / goal;
  const scale = Math.max(1.25, ratio * 1.05);
  return (
    <div className="attain">
      <div className="attain-track" role="img" aria-label={`${pct0(ratio)} del objetivo`}>
        <div className={`attain-fill${ratio >= 1 ? ' done' : ''}${achieved <= 0 ? ' none' : ''}`} style={{ width: `${Math.min(100, (ratio / scale) * 100)}%` }} />
        <span className="attain-goal" style={{ left: `${(1 / scale) * 100}%` }} title="Objetivo" />
      </div>
      {meta && (
        <div className="attain-meta">
          <span>{eur0(achieved)} de {eur0(goal)}</span>
          <span>{ratio >= 1 ? `Objetivo superado en ${eur0(achieved - goal)}` : `Faltan ${eur0(goal - achieved)}`}</span>
        </div>
      )}
    </div>
  );
}

// Space, Sky, Denim, Stone, Frost y Cobalt del brandbook para distinguir a cada persona; siempre van con su nombre al lado.
const SERIES = ['#002d4d', '#0099e6', '#004373', '#819aa6', '#7cd4f7', '#184ff2', '#597180'];

type Member = { id: number; name: string; department: string; plan: string | null; goal: number | null; achieved: number; pct: number | null; share: number; deals: { id: number; client: string; signed_date: string; arr: number }[] };
export type Team = { year: number; total: number; goal: number | null; pct: number | null; members: Member[] };

/** Consecución del equipo: total, quién aporta qué y el avance de cada persona. */
export function TeamAttainment({ team, title = 'Consecución de objetivos de ARR' }: { team: Team; title?: string }) {
  const contributors = team.members.filter((m) => m.achieved > 0);
  return (
    <div className="card flush">
      <div className="card-head">
        <div>
          <h2>{title} · {team.year}</h2>
          <p className="muted small">ARR comercial firmado en el ejercicio. En los deals compartidos, cada persona suma su parte.</p>
        </div>
        <div className="right">
          <div className="eyebrow">Total equipo</div>
          <div style={{ fontSize: 22 }} className="big">
            {eur0(team.total)}{team.goal ? <span className="muted" style={{ fontSize: 14, fontWeight: 500 }}> de {eur0(team.goal)} · {pct0(team.pct)}</span> : null}
          </div>
        </div>
      </div>
      {team.members.length === 0 ? <Empty title="Sin objetivos ni ARR en este ejercicio">Asigna el objetivo anual de cada comercial en Usuarios.</Empty> : (
        <>
          {contributors.length > 0 && (
            <div style={{ padding: '18px 20px', borderBottom: '1px solid var(--rule-soft)' }} className="stack">
              <div className="eyebrow">Quién aporta el ARR del equipo</div>
              <div className="contrib" role="img" aria-label="Reparto del ARR del equipo por persona">
                {contributors.map((m) => {
                  const i = team.members.indexOf(m);
                  return <div key={m.id} style={{ width: `${m.share * 100}%`, background: SERIES[i % SERIES.length] }} title={`${m.name}: ${eur0(m.achieved)}`}>{m.share >= 0.09 ? pct0(m.share) : ''}</div>;
                })}
              </div>
              <div className="legend">
                {contributors.map((m) => {
                  const i = team.members.indexOf(m);
                  return <span key={m.id}><i className="swatch" style={{ background: SERIES[i % SERIES.length] }} />{m.name} · <b className="num">{eur0(m.achieved)}</b> ({pct0(m.share)})</span>;
                })}
              </div>
            </div>
          )}
          {team.members.map((m, i) => (
            <div className="member" key={m.id}>
              <div className="who-name">
                <i className="swatch" style={{ background: SERIES[i % SERIES.length] }} />
                <div><b>{m.name}</b><div className="muted small">{m.plan || 'Sin plan'}{m.department === 'CONSULTORIA' ? ' · Consultoría' : ''}</div></div>
              </div>
              <AttainBar achieved={m.achieved} goal={m.goal} />
              <div className="fig"><b>{pct0(m.pct)}</b><span className="muted small">consecución</span></div>
              <div className="fig"><b>{pct0(m.share)}</b><span className="muted small">del total</span></div>
              {m.deals.length > 0 && (
                <details>
                  <summary>{m.deals.length} {m.deals.length === 1 ? 'deal' : 'deals'} · ver qué aporta</summary>
                  <ul>{m.deals.map((d) => <li key={d.id}><span>{d.client}</span><b className="num">{eur0(d.arr)}</b></li>)}</ul>
                </details>
              )}
            </div>
          ))}
        </>
      )}
    </div>
  );
}
