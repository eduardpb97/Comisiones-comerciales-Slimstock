'use client';
import Link from 'next/link';
import { usePathname } from 'next/navigation';
import { ReactNode } from 'react';
import { LOGO_WHITE } from './brand';
import { signOut } from './client';
import { Diamonds, Toaster } from './ui';

export type NavItem = { href: string; label: string; count?: number };

// Iconos de línea, 24×24. La clave es el último tramo de la ruta.
const ICONS: Record<string, string> = {
  admin: 'M4 13h6V4H4zm10 7h6v-9h-6zM4 20h6v-4H4zm10-12h6V4h-6z',
  portal: 'M4 19V9m5 10V5m5 14v-7m5 7V8',
  deals: 'M4 7h16v12H4zM9 7V5h6v2M4 12h16',
  facturas: 'M7 3h10v18l-2.5-2-2.5 2-2.5-2L7 21zM10 8h4m-4 4h4',
  liquidacion: 'M4 6h16v13H4zM4 10h16M8 3v4m8-4v4m-7 8 2 2 4-4',
  manuales: 'M4 20h4L19 9l-4-4L4 16zM13 7l4 4',
  consultas: 'M4 5h16v11H9l-5 4z',
  ejercicios: 'M5 5h14v15H5zM5 10h14M9 3v4m6-4v4m-6 8h2m2 0h2',
  usuarios: 'M9 11a3.5 3.5 0 1 0 0-7 3.5 3.5 0 0 0 0 7zm-6 9c0-3.3 2.7-5.5 6-5.5s6 2.2 6 5.5M16 4.5a3.5 3.5 0 0 1 0 6.5m2 4c1.8.7 3 2.300 3 5',
  perfil: 'M12 12a4 4 0 1 0 0-8 4 4 0 0 0 0 8zm-7 8c0-3.500 3.100-6 7-6s7 2.500 7 6',
  historico: 'M12 7v5l3 2M4 12a8 8 0 1 0 2.300-5.600M4 4v4h4',
};

const initials = (name: string) => name.split(/\s+/).map((w) => w[0]).join('').replace(/[^A-Za-zÀ-ÿ]/g, '').slice(0, 2).toUpperCase();

export function Shell({ title, user, nav, children, footer }: { title: string; user: { name: string; email: string }; nav: NavItem[]; children: ReactNode; footer?: ReactNode }) {
  const path = usePathname();
  const root = nav[0].href;
  return (
    <div className="shell">
      <aside className="side">
        <Diamonds />
        <div className="brand">
          <img src={LOGO_WHITE} alt="Slimstock" />
          <span>{title}</span>
        </div>
        <nav className="nav" aria-label="Secciones">
          {nav.map((n) => {
            const on = n.href === root ? path === root : path.startsWith(n.href);
            const icon = ICONS[n.href.split('/').pop() || ''] || ICONS.admin;
            return (
              <Link key={n.href} href={n.href} className={on ? 'on' : ''} aria-current={on ? 'page' : undefined}>
                <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.800" strokeLinecap="round" strokeLinejoin="round" aria-hidden="true"><path d={icon} /></svg>
                <span className="lbl">{n.label}</span>
                {!!n.count && <span className="count">{n.count}</span>}
              </Link>
            );
          })}
        </nav>
        <div className="who">
          <div className="me">
            <span className="avatar" aria-hidden="true">{initials(user.name)}</span>
            <div style={{ minWidth: 0 }}>
              <b>{user.name}</b>
              <div className="mail">{user.email}</div>
            </div>
          </div>
          {footer || <button onClick={() => signOut()}>Cerrar sesión</button>}
        </div>
      </aside>
      <main className="main">{children}</main>
      <Toaster />
    </div>
  );
}
