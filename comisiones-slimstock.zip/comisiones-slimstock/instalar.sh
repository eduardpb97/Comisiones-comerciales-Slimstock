#!/usr/bin/env bash
# Instalador para Linux. Uso: ./instalar.sh
set -euo pipefail
cd "$(dirname "$0")"
echo "== Portal de comisiones Slimstock · Instalador =="
if ! command -v node >/dev/null 2>&1; then
  echo "[X] No se ha encontrado Node.js. Instala Node.js 22 LTS (https://nodejs.org) y vuelve a ejecutar."; exit 1
fi
MAJOR=$(node -p "process.versions.node.split('.')[0]")
if [ "$MAJOR" -lt 22 ]; then echo "[X] Hace falta Node.js 22 LTS o superior (tienes $(node -v))."; exit 1; fi
echo "[1/3] Node.js $(node -v) detectado."
echo "[2/3] Descargando dependencias..."
npm ci --no-audit --no-fund
echo "[3/3] Preparando el portal..."
npm run build
echo
echo "Instalación completada."
echo "  - Arrancar ahora:               ./iniciar.sh"
echo "  - Arranque automático (systemd): sudo ./inicio-automatico.sh"
