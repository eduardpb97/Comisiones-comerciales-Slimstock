@echo off
title Abrir puerto - Portal de comisiones Slimstock
net session >nul 2>nul
if errorlevel 1 (
  echo Ejecuta este fichero como administrador: boton derecho ^> Ejecutar como administrador.
  pause
  exit /b 1
)
if "%PORT%"=="" set PORT=3000
netsh advfirewall firewall delete rule name="Portal Comisiones Slimstock" >nul 2>nul
netsh advfirewall firewall add rule name="Portal Comisiones Slimstock" dir=in action=allow protocol=TCP localport=%PORT% profile=domain,private
echo.
echo Puerto %PORT% abierto para la red interna ^(perfiles de dominio y privado^).
echo.
pause
