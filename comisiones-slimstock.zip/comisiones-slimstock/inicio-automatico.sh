#!/usr/bin/env bash
# Crea un servicio systemd para que el portal arranque con la máquina. Uso: sudo ./inicio-automatico.sh
set -euo pipefail
[ "$(id -u)" -eq 0 ] || { echo "Ejecuta este script con sudo."; exit 1; }
DIR="$(cd "$(dirname "$0")" && pwd)"
RUN_AS="${SUDO_USER:-root}"
NPM="$(command -v npm)"
cat > /etc/systemd/system/comisiones-slimstock.service <<UNIT
[Unit]
Description=Portal de comisiones Slimstock
After=network.target

[Service]
Type=simple
User=$RUN_AS
WorkingDirectory=$DIR
Environment=PORT=${PORT:-3000}
Environment=NODE_OPTIONS=--max-old-space-size=512
Environment=PATH=$(dirname "$NPM"):/usr/local/bin:/usr/bin:/bin
ExecStart=$NPM start
Restart=always
RestartSec=5

[Install]
WantedBy=multi-user.target
UNIT
systemctl daemon-reload
systemctl enable --now comisiones-slimstock
echo "Servicio creado y en marcha. Estado: systemctl status comisiones-slimstock"
